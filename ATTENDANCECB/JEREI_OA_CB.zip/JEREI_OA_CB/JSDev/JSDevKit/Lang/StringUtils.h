//
//  StringUtils.h
//  JSDevKit
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StringUtils : NSObject

@end

@interface NSString(NSStringUtils)

/*!
 @abstract 检查字符串是否包含指定前缀
 */
- (BOOL)hasPrefix:(NSString *)prefix ignoreCase:(BOOL)ignoreCase;

/*!
 @abstract 检查字符串是否包含指定后缀
 */
- (BOOL)hasSuffix:(NSString *)suffix ignoreCase:(BOOL)ignoreCase;

/*!
 @abstract 检查字符串是否符合正则表达式
 */
- (BOOL)matches:(NSString *)pattern options:(NSRegularExpressionOptions)options error:(NSError **)error;
/*!
 @abstract 检查字符串是否符合正则表达式，如果发生异常也会返回NO
 */
- (BOOL)matches:(NSString *)pattern options:(NSRegularExpressionOptions)options;

- (NSString *)trim;
- (NSString *)trimForCharSet:(NSCharacterSet *)set;

/*!
 @abstract 包装nil和nsnull为空字符串
 */
+ (instancetype)stringWrapped:(id)object;
@end