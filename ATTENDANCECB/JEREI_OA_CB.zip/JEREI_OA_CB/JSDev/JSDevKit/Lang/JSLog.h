//
//  JSLog.h
//  JSDevKit
//
//  Created by jerei on 14-8-10.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#ifndef JSDevKit_JSLog_h
#define JSDevKit_JSLog_h

#define JSLog(pattern, ...) do {\
(NSLog)(@"%@<%s : %d> %s\n  %@", \
[NSThread currentThread].isMainThread ? @"*" : @"", \
[[[NSString stringWithUTF8String:__FILE__] lastPathComponent] UTF8String], \
__LINE__, \
__func__, \
[[NSString stringWithFormat:(pattern), ##__VA_ARGS__] \
stringByReplacingOccurrencesOfString:@"\n" \
withString:@"\n  "]);\
} while(0)

#endif

// 原生nslog
#define __NSLog(pattern, ...) \
(NSLog)(pattern, ##__VA_ARGS__)


// 替换原生NSLog
#ifndef JSDevKit_JSLog_h_NSLog
#define JSDevKit_JSLog_h_NSLog

// http://onevcat.com/2014/01/black-magic-in-macro/
#define NSLog(pattern, ...) \
JSLog(pattern, ##__VA_ARGS__)
#endif
