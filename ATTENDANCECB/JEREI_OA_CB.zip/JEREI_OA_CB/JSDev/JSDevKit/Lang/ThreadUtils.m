//
//  ThreadUtils.m
//  JSDevKit
//
//  Created by jerei on 14-8-12.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ThreadUtils.h"
#import "MBProgressHUD.h"


@implementation ThreadUtils

+ (void)runInGlobalQueue:(void(^)())taskBlock whenDone:(void(^)())doneBlock
{
    __weak void (^weakTaskBlock)() = taskBlock;
    __weak void (^weakDoneBlock)() = doneBlock;
    
    [ThreadUtils runInGlobalQueue:^(MBProgressHUD *hud) {
        if (weakTaskBlock)
            weakTaskBlock();
    }
                         whenDone:^(MBProgressHUD *hud) {
                             if (weakDoneBlock)
                                 weakDoneBlock();
                             return NO;
                         }
                       viewForHUD:nil
                initializerForHUD:nil];
}

+ (void)runInGlobalQueue:(void (^)(MBProgressHUD *hud))taskBlock
                whenDone:(BOOL (^)(MBProgressHUD *hud))doneBlock
              viewForHUD:(UIView *)viewForHUD
       initializerForHUD:(void (^)(MBProgressHUD *hud))hudHandler
{
    assert(taskBlock != nil);
    
    __weak UIView* weakViewForHUD = viewForHUD;
    __weak MBProgressHUD *weakHud = nil;
    if (viewForHUD) {
        weakHud = [MBProgressHUD showHUDAddedTo:weakViewForHUD animated:YES];
        if (hudHandler)
            hudHandler(weakHud);
    }
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        taskBlock(weakHud);
        dispatch_async(dispatch_get_main_queue(), ^{
            BOOL hudHandled = NO;
            if (doneBlock) {
                hudHandled = doneBlock(weakHud);
            }
            // 如果doneBlock返回了YES，则表示hud已被doneBlock处理，不再自动关闭
            if (!hudHandled && weakHud) {
                [MBProgressHUD hideHUDForView:weakViewForHUD animated:YES];
            }
        });
    });
}

@end



@implementation NSThread(ThreadUtils)

@end