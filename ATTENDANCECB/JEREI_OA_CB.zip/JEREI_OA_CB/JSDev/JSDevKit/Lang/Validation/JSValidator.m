//
//  JSValidator.m
//  JSDevKit
//
//  Created by 丁未汀 on 9/3/14.
//  Copyright (c) 2014 jerei. All rights reserved.
//

#import "JSValidator.h"
#import "StringUtils.h"
#import "DateUtils.h"
#import <objc/runtime.h>

NSString* JSVMakeUnknownValueClassMessage(id value) {
    return [NSString stringWithFormat:@"未知的数据类型:%@", NSStringFromClass([value class])];
}
void JSVPrintUnknownValueClass(id value) {
    NSLog(@"%@", JSVMakeUnknownValueClassMessage(value));
}

@implementation JSValidator


#pragma mark 必填验证

+ (BOOL)validateRequired:(id)value
{
    if (value == nil || [value isNull])
        return NO;
    
    if ([value isKindOfClass:[NSNumber class]]) {
        // 数值非0为合法
        NSNumber *num = (NSNumber *)value;
        return num.doubleValue != 0.0;
    }
    else if ([value isKindOfClass:[NSDate class]]) {
        // 日期超过1970-1-1 0:0:0.0为合法
        NSDate *date = (NSDate *)value;
        return [date timeIntervalSince1970] > 0.0;
    }
    else if ([value isKindOfClass:[NSString class]]) {
        // 字符串去左右空格长度大于0为合法
        NSString *str = (NSString *)value;
        return [str trim].length > 0;
    }
    else if ([value isKindOfClass:[NSArray class]]) {
        // 集合类型长度大于0为合法
        NSArray *arr = (NSArray *)value;
        return arr.count > 0;
    }
    else if ([value isKindOfClass:[NSDictionary class]]) {
        NSDictionary *dict = (NSDictionary *)value;
        return dict.count > 0;
    }
    else if ([value isKindOfClass:[NSSet class]]) {
        NSSet *set = (NSSet *)value;
        return set.count > 0;
    }
    else {
        JSVPrintUnknownValueClass(value);
    }
    return YES;
}


#pragma mark 长度验证

NSString* JSVMakeLengthMessage(uint len, uint minLen, uint maxLen) {
    NSMutableString *msg = [NSMutableString stringWithFormat:@"数据长度%zd超出范围:", len];
    if (minLen > 0) {
        [msg appendFormat:@"最小长度%zd", minLen];
        if (maxLen < UINT_MAX)
            [msg appendString:@","];
    }
    if (maxLen < UINT_MAX) {
        [msg appendFormat:@"最大长度%zd", maxLen];
    }
    return msg;
}

+ (NSString *)validateMaxLength:(id)value maxLength:(uint)maxLength
{
    return [JSValidator validateLengthInRange:value minLength:0 maxLength:maxLength];
}
+ (NSString *)validateMinLength:(id)value minLength:(uint)minLength
{
    return [JSValidator validateLengthInRange:value minLength:minLength maxLength:0];
}
+ (NSString *)validateLengthInRange:(id)value minLength:(uint)minLength maxLength:(uint)maxLength
{
    if (maxLength == 0)
        maxLength = UINT_MAX;
    
    NSAssert(minLength == 0 || maxLength == 0 || minLength <= maxLength, @"最小长度不能大于最大长度");
    NSString *message = nil;
    
    // 处理非字符串类型的值
    // nil/null变为空字符串
    // 数值类型转为浮点型表示的字符串，其他类型返回验证失败消息
    if ([ObjectUtils isNilOrNull:value]) {
        value = @"";
    }
    else if (![value isKindOfClass:[NSString class]]) {
        if ([value isKindOfClass:[NSNumber class]]) {
            value = [NSString stringWithFormat:@"%f", [value doubleValue]];
        }
        else {
            JSVPrintUnknownValueClass(value);
            message = JSVMakeUnknownValueClassMessage(value);
            return message;
        }
    }
    
    NSString *str = [(NSString *)value trim];
    if (str.length < minLength || str.length > maxLength) {
        message = JSVMakeLengthMessage((uint)str.length, minLength, maxLength);
    }
    return message;
}


#pragma mark 值范围验证

NSString* JSVMakeValueRangeMinMessage(id minVal) {
    return [NSString stringWithFormat:@"数据小于最小值%@", minVal];
}
NSString* JSVMakeValueRangeMaxMessage(id minVal) {
    return [NSString stringWithFormat:@"数据大于最大值%@", minVal];
}
NSString* JSVMakeValueRangeMessage(id minVal, id maxVal) {
    return [NSString stringWithFormat:@"数据超出范围%@~%@", minVal, maxVal];
}

+ (NSString *)validateValueInRange:(id)value minValue:(id)minValue maxValue:(id)maxValue
{
    NSAssert(minValue != nil || maxValue != nil, @"必须指定至少一个边界值");
    
    NSString *message = nil;
    if ([ObjectUtils isNilOrNull:value]) {
        message = JSVMakeValueRangeMessage(minValue, maxValue);
    }
    else {
        if ([value isKindOfClass:[NSDate class]]) {
            // 日期类型转换为double再比较
            value = [NSNumber numberWithDouble:[value timeIntervalSince1970]];
            if (minValue)
                minValue = [NSNumber numberWithDouble:[minValue timeIntervalSince1970]];
            if (maxValue)
                maxValue = [NSNumber numberWithDouble:[maxValue timeIntervalSince1970]];
        }
        
        if ([value isKindOfClass:[NSNumber class]]) {
            NSNumber *min = [ObjectUtils convertData:minValue toType:[NSNumber class]];
            NSNumber *max = [ObjectUtils convertData:maxValue toType:[NSNumber class]];
            NSAssert(min == nil || max == nil || [min compare:max] != NSOrderedDescending, @"最小边界不能大于最大边界");
            
            if (min && [value compare:min] == NSOrderedAscending) {
                message = JSVMakeValueRangeMinMessage(min);
            }
            else if (max && [value compare:max] == NSOrderedDescending) {
                message = JSVMakeValueRangeMaxMessage(max);
            }
        }
        else if ([value isKindOfClass:[NSString class]]) {
            NSString *min = [ObjectUtils convertData:minValue toType:[NSString class]];
            NSString *max = [ObjectUtils convertData:maxValue toType:[NSString class]];
            NSAssert(min == nil || max == nil || [min compare:max options:NSLiteralSearch] != NSOrderedDescending, @"最小边界不能大于最大边界");
            
            if (min && [value compare:min options:NSLiteralSearch] == NSOrderedAscending) {
                message = JSVMakeValueRangeMinMessage(min);
            }
            else if (max && [value compare:max options:NSLiteralSearch] == NSOrderedDescending) {
                message = JSVMakeValueRangeMaxMessage(max);
            }
        }
        else {
            message = JSVMakeUnknownValueClassMessage(value);
        }
    }
    return message;
}


#pragma mark 正则表达式验证

+ (NSString *)validateRegExp:(NSString *)value regExp:(NSString *)regExp invalidMessage:(NSString *)invalidMessage
{
    if (!value)
        value = @"";
    
    NSString *message = nil;
    NSError *err;
    if (![value matches:regExp options:NSRegularExpressionCaseInsensitive error:&err]) {
        if (invalidMessage)
            message = invalidMessage;
        else
            invalidMessage = [NSString stringWithFormat:@"数据不匹配指定模式:%@", regExp];
    }
    else if (err) {
        message = [NSString stringWithFormat:@"无法验证数据:%@", [err localizedDescription]];
    }
    return message;
}


#pragma mark 取值集合验证

+ (BOOL)validateValueInSet:(id)value valueSet:(NSSet *)valueSet
{
    NSAssert(valueSet != nil, @"必须提供取值集合");
    if ([ObjectUtils isNilOrNull:value]) {
        return NO;
    }
    else {
        return [valueSet containsObject:value];
    }
}


#pragma mark 使用block验证

+ (NSString *)validateValue:(id)value withBlock:(BOOL (^)(id))validateBlock invalidMessage:(NSString *)invalidMessage
{
    BOOL valid = validateBlock(value);
    if (valid)
        return nil;
    else
        return invalidMessage;
}

#pragma mark 使用预定义验证器

+ (NSString *)validateValue:(id)value withValidator:(Class)validatorClass
{
    JSValidator *validator = [[validatorClass alloc] init];
    return [validator validateValue:value];
}




#pragma mark Instance Methods

- (NSString *)validateValue:(id)value
{
    @throw [ExceptionUtils makeExceptionWithName:@"NotImplemented" reason:@"此方法应由实现类覆盖" description:@"此方法应由实现类覆盖"];
}

@end



#pragma mark 预定义验证器


NSString* JSVValidateRegExp(id value, NSString *regExp, BOOL ignoreCase, NSString *message) {
    if ([ObjectUtils isNilOrNull:value])
        return nil;
    
    NSString *val = [ObjectUtils convertData:value toType:[NSString class]];
    if (![val matches:regExp options:(ignoreCase ? NSRegularExpressionCaseInsensitive : 0)])
        return message;
    else
        return nil;
}
NSString* JSVValidatePhoneNumber(id value) {
    return JSVValidateRegExp(value, @"^((\\d{3,4}-?)|(\\(\\d{3,4}\\)))?(\\d{6,8})(([\\x2d\\x2f]\\d{1,5})?|(\\/\\d{6,8})?)$", NO, @"电话号码正确格式为6-8位数字，可加区号和转接号码，比如0535-12345678，(0535)12345678，0535-1234567-33798，0535-1234567/23456789");
}
NSString* JSVValidateMobileNumber(id value) {
    return JSVValidateRegExp(value, @"^((\\([+]\\d{1,2}\\))|([+]\\d{1,2}))?(\\d{11})$", NO, @"手机号码正确格式为11位数字，可加地区号，比如13300000000，(+86)13300000000");
}


@implementation JSIDValidator
- (NSString *)validateValue:(id)value
{
    return JSVValidateRegExp(value, @"^((\\d{15})|(\\d{17}[a-zA-Z0-9]))$", NO, @"身份证号正确格式为15或18位数字，末位可为字母");
}
@end

@implementation JSPhoneValidator
- (NSString *)validateValue:(id)value
{
    return JSVValidatePhoneNumber(value);
}
@end

@implementation JSMobileVaidator
- (NSString *)validateValue:(id)value
{
    return JSVValidateMobileNumber(value);
}
@end

@implementation JSPhoneMobileValidator
- (NSString *)validateValue:(id)value
{
    NSString *message = JSVValidatePhoneNumber(value);
    if (!message)
        message = JSVValidateMobileNumber(value);
    return message == nil ? nil : @"号码的正确格式为11位手机号码或6-8位座机号码，比如0535-12345678，(0535)12345678，0535-1234567-33798，0535-1234567/23456789";
}
@end


@implementation JSHttpUrlValidator
- (NSString *)validateValue:(id)value
{
    return JSVValidateRegExp(value, @"^(https?:\\/\\/)?[^\\/: ]+\\.[^\\/: ]+(\\/.*?)*$", YES, @"网址的正确格式为http(s)://开头的地址");
}
@end


@implementation JSEMailValidator
- (NSString *)validateValue:(id)value
{
    return JSVValidateRegExp(value, @"^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*.\\w+([-.]\\w+)*$", YES, @"邮箱格式应该类似me@ie.com");
}
@end

@implementation JSPostCodeValidator
- (NSString *)validateValue:(id)value
{
    return JSVValidateRegExp(value, @"^\\d{5,6}$", NO, @"邮政编码应为6位数字");
}
@end

@implementation JSDateTimeValidator
- (NSString *)validateValue:(id)value
{
    if ([ObjectUtils isNilOrNull:value] || [value isKindOfClass:[NSDate class]])
        return nil;
    NSString *val = [ObjectUtils convertData:value toType:[NSString class]];
    NSDate *date = [NSDate dateFromString:val];
    return date ? nil : @"日期应如何格式 年-月-日 时:分:秒，其中时间部分可选";
}
@end
