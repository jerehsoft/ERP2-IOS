//
//  JSTextField.h
//  JSDevKit
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <UIKit/UIKit.h>

DEPRECATED_IN_MAC_OS_X_VERSION_10_0_AND_LATER
@interface JSTextField : UITextField

// 占位符颜色
@property (nonatomic, retain, setter = setPlaceholder:, getter = getPlaceholderColor) UIColor *placeholderColor;
// 占位符字体
@property (nonatomic, retain) UIFont *placeholderFont;

- (void)setPlaceholderColor:(UIColor *)placeholderColor;

- (UIColor *)getPlaceholderColor;

@end
