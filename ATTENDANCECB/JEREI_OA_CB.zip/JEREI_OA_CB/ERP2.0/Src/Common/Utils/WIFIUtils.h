//
//  WIFIUtils.h
//  ERP2.0
//
//  Created by jerei on 14-9-22.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface WIFIUtils : NSObject
+ (NSString *)getSSID;
+ (NSString *)getBSSID;
+ (void)checkWIFIWithWifiInfo:(NSString *)currentWifi currentCBFlag:(BOOL)cbFlag devices:(NSArray *)devices complete:(void(^)())complete;
@end
