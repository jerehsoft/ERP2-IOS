//
//  ERPListActionResponseData.m
//  ERP2.0
//
//  Created by jerei on 14-7-30.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPListActionResponseData.h"

@implementation ERPListActionResponseData

- (ERPListActionResponseData *)initWithDictionary:(NSDictionary *)dictionary pageSize:(NSInteger)pageSize rowsName:(NSString *)rowsName
{
    if (self = [super init]) {
        self.rows = rowsName ? dictionary[rowsName] : [dictionary valueForKey:@"rows"];
        self.total = [((NSNumber *)[dictionary valueForKey:@"total"]) intValue];
        self.pageSize = pageSize;
    }
    return self;
}

+ (ERPListActionResponseData *)parseDictionary:(NSDictionary *)dictionary pageSize:(NSInteger)pageSize rowsName:(NSString *)rowsName
{
    return [[ERPListActionResponseData alloc] initWithDictionary:dictionary pageSize:pageSize rowsName:rowsName];
}

@end
