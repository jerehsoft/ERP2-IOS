//
//  ERPListActionResponseData.h
//  ERP2.0
//
//  Created by jerei on 14-7-30.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ERPListActionResponseData : NSObject

@property (nonatomic, assign) NSInteger total;
@property (nonatomic, retain) NSArray *rows;
@property (nonatomic, retain) NSDictionary *raw;
@property (nonatomic, assign) NSInteger pageSize;

- (ERPListActionResponseData *)initWithDictionary:(NSDictionary *)dictionary pageSize:(NSInteger)pageSize rowsName:(NSString *)rowsName;
/*!
 @abstract 解析action返回的json
 */
+ (ERPListActionResponseData *)parseDictionary:(NSDictionary *)dictionary pageSize:(NSInteger)pageSize rowsName:(NSString *)rowsName;

@end
