//
//  VVCLabel.m
//  XLForm
//
//  Created by jerei on 14/12/18.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//

#import "VVCLabel.h"

@implementation VVCLabel

-(id)valueForUndefinedKey:(NSString *)key{
    return nil;
}

+(void)bindTextFiled:(VVCLabel *)Label cellView:(XLFormBaseCell *)cellView{

    if(Label.valueKey == nil && !Label.singleValue)
        return;
    
    id value = nil;
    
    if(Label.singleValue)
        value = cellView.rowDescriptor.value;
    else
        value = [cellView.rowDescriptor.value valueForKey:Label.valueKey];
    
    Label.cellView = cellView;
    
    if(![value isKindOfClass:[NSString class]]){
        value = [value stringValue];
    }
    if(value)
        Label.text = value;

}

+(void)autoBindLabelOnView:(XLFormBaseCell *)cell{
    NSMutableArray *fields = [[NSMutableArray alloc]init];
    
    [VVCLabel findVVCLabel:cell fields:fields];
    for(VVCLabel *field in fields){
        [VVCLabel bindTextFiled:field cellView:cell];
    }
}

+(void)findVVCLabel:(UIView *)uiView fields:(NSMutableArray *)fields{
    for(UIView *view in uiView.subviews){
        if([view isKindOfClass:[VVCLabel class]]){
            [fields addObject:view];
        }else{
            [VVCLabel findVVCLabel:view fields:fields];
        }
    }
}

@end
