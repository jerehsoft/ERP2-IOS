//
//  VVCIQLPPMainBandsCell.h
//  XLForm
//
//  Created by jerei on 14/12/16.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//

#import "XLFormBaseCell.h"
#import "VVCSelectButton.h"
#import "VVCTextField.h"

@interface VVCPropertiesCell : XLFormBaseCell

@property (weak, nonatomic) IBOutlet VVCTextField *text;
@property BOOL singleValue;
@end
