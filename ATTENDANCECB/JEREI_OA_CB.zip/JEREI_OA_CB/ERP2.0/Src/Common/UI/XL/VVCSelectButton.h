//
//  VVCSelectButton.h
//  XLForm
//
//  Created by jerei on 14/12/16.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLFormBaseCell.h"

@interface VVCSelectButton : UIButton

@property NSString *valueKey;
@property NSString *optionsKey;
@property NSString *suffix;
@property NSString *placeholder;
@property NSString *rightholder;
//@property NS
@property (weak) XLFormBaseCell *cellView;
@property (weak) id<UIPopoverControllerDelegate> popDelegate;
@property BOOL singleValue;
@property CGSize popSize;
@property BOOL customValue;
@property BOOL isBorder;
@property BOOL isRedBorder;
-(void)popOptions;

+(void)bindButton:(VVCSelectButton *)button cellView:(XLFormBaseCell *)cell popDelegate:(id<UIPopoverControllerDelegate>)delegate;

+(void)autoBindButtonsOnView:(XLFormBaseCell *)cell;

@end
