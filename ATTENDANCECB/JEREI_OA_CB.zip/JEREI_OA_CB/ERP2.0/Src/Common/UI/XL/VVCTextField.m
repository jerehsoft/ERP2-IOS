//
//  VVCTextField.m
//  XLForm
//
//  Created by jerei on 14/12/18.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//

#import "VVCTextField.h"

@implementation VVCTextField

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(id)valueForUndefinedKey:(NSString *)key{
    return nil;
}


#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [textField setReturnKeyType:UIReturnKeyDone];
    NSString *value = nil;
    if([@"Integer" isEqual:[self dataType]]){
        value = [NSString stringWithFormat:@"%ld",(long)[textField.text integerValue]];
        [self.cellView.rowDescriptor.value setValue:@([textField.text integerValue]) forKey:self.valueKey];
    }else
        value = textField.text;
    if ([value isEqualToString:@"0"]) {
        textField.text = @"";
    } else {
        textField.text = value;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    NSString *value = nil;
    if([@"Integer" isEqual:[self dataType]]){
        value = [NSString stringWithFormat:@"%ld",(long)[textField.text integerValue]];
        [self.cellView.rowDescriptor.value setValue:@([textField.text integerValue]) forKey:self.valueKey];
    }else
        value = textField.text;
    textField.text = value;
    
    if(self.singleValue)
        self.cellView.rowDescriptor.value = value;
    else
        [self.cellView.rowDescriptor.value setValue:value forKey:self.valueKey];
}


+(void)bindTextFiled:(VVCTextField *)textField cellView:(XLFormBaseCell *)cellView{

    if(textField.valueKey == nil && !textField.singleValue)
        return;
    
    id value = nil;
    
    if(textField.singleValue)
        value = cellView.rowDescriptor.value;
    else
        value = [cellView.rowDescriptor.value valueForKey:textField.valueKey];
    
    id<UITextFieldDelegate> obj = [cellView.rowDescriptor.cellConfigAtConfigure valueForKey:@"textDelegate"];
    
    if(obj){
            textField.delegate = obj;
    }else{
        textField.delegate = textField;
    }
    
    textField.cellView = cellView;
    
    if(![value isKindOfClass:[NSString class]]){
        value = [value stringValue];
    }
    if(value)
        textField.text = value;
    
    if (textField.inputDisabled) {
        textField.userInteractionEnabled = NO;
    }

}

+(void)autoBindTextFieldOnView:(XLFormBaseCell *)cell{
    NSMutableArray *fields = [[NSMutableArray alloc]init];
    
    [VVCTextField findVVCTextField:cell fields:fields];
    for(VVCTextField *field in fields){
        [VVCTextField bindTextFiled:field cellView:cell];
    }
}

+(void)findVVCTextField:(UIView *)uiView fields:(NSMutableArray *)fields{
    for(UIView *view in uiView.subviews){
        if([view isKindOfClass:[VVCTextField class]]){
            [fields addObject:view];
        }else{
            [VVCTextField findVVCTextField:view fields:fields];
        }
    }
}

@end
