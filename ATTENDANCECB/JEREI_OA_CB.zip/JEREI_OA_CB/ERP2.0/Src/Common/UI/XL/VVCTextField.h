//
//  VVCTextField.h
//  XLForm
//
//  Created by jerei on 14/12/18.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLFormBaseCell.h"

@interface VVCTextField : UITextField<UITextFieldDelegate>
@property NSString *valueKey;
@property NSString *dataType;
@property (weak) XLFormBaseCell *cellView;
@property BOOL singleValue;
@property BOOL inputDisabled;

+(void)bindTextFiled:(VVCTextField *)textField cellView:(XLFormBaseCell *)cellView;

+(void)autoBindTextFieldOnView:(XLFormBaseCell *)cell;
@end
