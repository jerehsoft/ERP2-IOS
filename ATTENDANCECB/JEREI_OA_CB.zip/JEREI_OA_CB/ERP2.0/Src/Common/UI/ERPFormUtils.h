//
//  ERPFormUtils.h
//  ERP2.0
//
//  Created by jerei on 14-8-4.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FormDataMapping.h"
#import "Form.h"
#import "FormCellInfo.h"
#import "FormViewCell.h"
#import "CustomIOS7AlertView.h"
#import "JSUIUtils.h"
#import "StringUtils.h"


#pragma mark SimpleReadonlyForm

#define SIMPLE_FORM_CELL_CONTENT_MARGIN 5.0f
#define SIMPLE_FORM_CELL_HEIGHT 30.0f


#pragma mark FormUtils

#define ALERT_FORM_VIEW_PADDING 10

@class TableFormViewController;
@class FormViewCell;
@class FormCellInfo;

/*!
 @abstract 表单工具类
 */
@interface ERPFormUtils : NSObject

/*!
 @abstract 弹出dialog
 */
+ (CustomIOS7AlertView *)showSimpleDialogWithContent:(UIView *)contentView;

/*!
 @abstract 弹出简单只读form
 */
+ (void)showSimpleFormWithData:(NSDictionary *)data mappingForData:(FormDataMapping *)mapping;

/*!
 @abstract 填表，每填充一个cell，应该将该cell所用到的所有数据同时保存一份到FormViewCell的dynamicProperties集合中
 */
+ (void)fillForm:(TableFormViewController *)formController withDictionary:(NSDictionary *)dictionary withListDataProvider:(id)listDataProvider;

/*!
 @abstract 从表单中读取数据，读取时以FormViewCell的dynamicProperties中的数据为基础，加上表单控件中的数据
 */
+ (NSDictionary *)dictionaryFromFromController:(TableFormViewController *)formController withListDataProvider:(id)listDataProvider;

/*!
 @abstract 根据formViewCell的属性类型转换数据
 */
+ (id)convertData:(id)data forCell:(FormViewCell *)cell;

/*!
 @abstract 根据formViewCell的属性类型格式化数据为文字
 */
+ (NSString *)formatData:(id)data forCell:(FormViewCell *)cell withListDataProvider:(id)listDataProvider;

/*!
 @abstract 设置view的显示文字
 */
+ (void)setViewText:(UIView *)view withData:(id)data;

/*!
 @abstract 填充TableViewCell的文字，根据cell类型调用fillTableViewCell或fillFormViewCell
 */
+ (void)fillCell:(UITableViewCell *)cell withData:(id)data withListDataProvider:(id)listDataProvider;

/*!
 @abstract 填充普通TableViewCell的文字
 */
+ (void)fillTableViewCell:(UITableViewCell *)cell withData:(id)data;
/*!
 @abstract 填充FormViewCell的文字，可能根据propertyPattern格式化数据
 */
+ (void)fillFormViewCell:(FormViewCell *)cell withData:(id)data withListDataProvider:(id)listDataProvider;

/*!
 @abstract 用数据选择列表中的值填充控件
 */
+ (void)fillCell:(UITableViewCell *)cell withSelectedData:(id)selectedData withListDataProvider:(id)listDataProvider;

/*!
 @abstract 在cell中查找第一个展示用的文本组件
 */
+ (UIView *)firstInputForCell:(UITableViewCell *)cell;

/*!
 @abstract 检查指定view是否包含可编辑的textField或textView
 */
+ (BOOL)containsEditableTextView:(UIView *)view;

/*!
 @abstract 检查指定view是否textField或textView
 */
+ (BOOL)isTextView:(UIView *)view;

/*!
 @abstract 检查指定view是否textField或textView而且已经获取焦点
 */
+ (BOOL)isTextViewAndFocused:(UIView *)view;

/*!
 @abstract 值事件监听
 */
+ (void)bindValueListener:(id<ControlValueChangeListener>)listener forFormController:(TableFormViewController *)formController;
/*!
 @abstract 取消值事件监听
 */
+ (void)unbindValueListener:(id<ControlValueChangeListener>)listener forFormController:(TableFormViewController *)formController;

+ (void)bindFocusListener:(id<InputFocusDelegate>)listener forFormController:(TableFormViewController *)formController;
+ (void)unbindFocusListener:(id<InputFocusDelegate>)listener forFormController:(TableFormViewController *)formController;

/*!
 @abstract 查找view上层的formViewCell
 */
+ (FormViewCell *)outerFormViewCellForView:(UIView *)innerView;

/*!
 @abstract 查找所有FormCellInfo
 @result [ FormCellInfo *, FormCellInfo *, ... ]
 */
+ (NSArray *)formCellInfosInFormController:(TableFormViewController *)formController;

/*!
 @abstract 检查数据对于指定类型来说是否是合法数据。数值：非0，字符串：trim后长度大于0，数组：长度大于0且包含非nsnull值，其他类型：非nil且非nsnull
 @param value 要检查的值
 @param type 目标类型，如果不指定类型，则使用值的当前类型
 */
+ (BOOL)isValueValid:(id)value forType:(Class)type;

@end
