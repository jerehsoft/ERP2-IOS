//
//  TableFormViewController.h
//  ERP2.0
//
//  Created by jerei on 14-8-11.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ERPSingleSelectSheet.h"
#import "ERPFormUtils.h"
#import "FormViewCell.h"
#import "RMDateSelectionViewController.h"
#import "JSTableViewController.h"

@protocol FormViewCellInputHandler;

@interface TableFormViewController : JSTableViewController<RMDateSelectionViewControllerDelegate, SingleSelectSheetDelegate, ControlValueChangeListener, InputFocusDelegate, FormViewCellInputHandler>
{
    // 表单数据，没有对外公开，需要让子类来初始化
    NSDictionary *formData;
    // 当前选定行的路径（初始化时记录的路径，如果在运行时动态调整了cell，需要根据映射关系查找新的位置）
    NSIndexPath *currentCellIndexPath;
}

/*!
 @abstract 值变化事件监听
 */
@property (nonatomic, assign) id<FormValueDelegate> formValueDelegate;

/*!
 @abstract 选择控件数据源
 */
@property (nonatomic, readonly) id listDataProvider;

/*!
 @abstract 重载点：如果返回NO则不自动填表，需要手动调用fillForm
 */
- (BOOL)shouldAutoFillForm;

/*!
 @abstract 填表，通常情况下不要重复调用
 */
- (void)fillForm;

/*!
 @abstract 重载点：填表完成
 */
- (void)didFillForm;

/*!
 @abstract 重载点：如果返回YES则不自动处理
 @result 选择事件是否已被处理
 */
- (BOOL)cellSelectionHandledForIndexPath:(NSIndexPath *)indexPath;

/*!
 @abstract 是否使用弹出数据输入控件，默认为NO。如果为YES，则使用inputView和inputAccessoryView来实现输入
 */
- (BOOL)preferPopInputForCell;

- (FormViewCell *)cellForFormCellInfo:(FormCellInfo *)formCellInfo;

- (FormCellInfo *)formCellInfoForProperty:(NSString *)propertyName;

@end
