//
//  TableFormViewController_Updatable.h
//  ERP2.0
//
//  Created by jerei on 14-8-14.
//  Copyright (c) 2014年 jerei. All rights reserved.
//


#import "TableFormViewController.h"

// 提供数据操作方法
@interface TableFormViewController(DataManipulation)

/*!
 @abstract 记录model更新并通知delegate(只记录更新，不修改传入的model)
 @param value 要修改的值
 @param isListItem 要修改的值是否属于选择列表，如果是，controller将调用listDataProvider获取列表数据，并更新form中显示的文字
 @param otherModifications 其他更新的值，可选，但这些值的更新不会通知到delegate，只有在最后读取结果数据时叠加到结果上
 */
- (void)updateModelWithValue:(id)value isValueAListItem:(BOOL)isListItem otherModifications:(NSDictionary *)otherModifications;

/*!
 @abstract 记录model更新并通知delegate(只记录更新，不修改传入的model)
 @param value 要修改的值
 @param propertyName 要更新的property
 @param isListItem 要修改的值是否属于选择列表，如果是，controller将调用listDataProvider获取列表数据，并更新form中显示的文字
 @param otherModifications 其他更新的值，可选，但这些值的更新不会通知到delegate，只有在最后读取结果数据时叠加到结果上
 */
- (void)updateModelWithValue:(id)value forProperty:(NSString *)propertyName isValueAListItem:(BOOL)isListItem otherModifications:(NSDictionary *)otherModifications;

/*!
 @abstract 获取初始数据的最终修改结果
 @result
 */
- (NSDictionary *)dataMerged;

/*!
 @abstract 获取property对应的最新值，这里的值可能是更新过的，不一定等于formData中的值。如果没找到对应的项，则尝试从formData中提取值
 */
- (id)currentValueForProperty:(NSString *)propertyName;

/*!
 @abstract 获取property对应的最新值，同时根据propertyType进行类型转换
 */
- (id)currentTypedValueForProperty:(NSString *)propertyName;

/*!
 @abstract 重载点：cell值变化
 */
- (void)valueDidChange:(id)newValue oldValue:(id)oldValue forCell:(FormViewCell *)formViewCell;

@end