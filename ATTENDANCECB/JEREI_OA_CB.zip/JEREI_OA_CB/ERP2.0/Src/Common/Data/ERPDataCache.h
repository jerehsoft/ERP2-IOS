//
//  ERPDataCache.h
//  ERP2.0
//
//  Created by jerei on 14-8-18.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Callback.h"
#import "FMDB.h"
#import "ObjectUtils.h"
#import "DateUtils.h"
#import "Erp2.h"

/*!
 @abstract 列定义
 */
@interface ERPColumn : NSObject

/*!
 @abstract 列名
 */
@property (nonatomic, copy) NSString *name;
/*!
 @abstract 数据类型
 */
@property (nonatomic, copy) NSString *type;
/*!
 @abstract 是否主键
 */
@property (nonatomic, assign) BOOL pk;
/*!
 @abstract 是否可空
 */
@property (nonatomic, assign) BOOL nullable;
/*!
 @abstract 是否有唯一约束
 */
@property (nonatomic, assign) BOOL unique;
/*!
 @abstract 默认值
 */
@property (nonatomic, copy) NSString *defaultVal;

@end



/*!
 @abstract 本地数据缓存
 */
@interface ERPDataCache : NSObject

/*!
 @abstract 晴空数据库（包括表）
 */
+ (void)clear;

/*!
 @abstract 准备数据库（创建表和系统数据）
 */
+ (void)prepare:(JSProgressBlock)progressCallback errorCallback:(JSErrorBlock)errorCallback;

/*!
 @abstract 清理内存中的代码缓存
 */
+ (void)clearCodeDetailsInMemory;

+ (FMDatabaseQueue *)_dbQueue;
+ (FMDatabase *)_db;
/*!
 @abstract 同步用户密码
 */
+ (void)saveLoginUser:(NSString *)uid userNo:(NSString *)userNo userName:(NSString *)userName password:(NSString *)pwd complete:(void(^)())complete error:(void(^)())error;
/*!
 @abstract 获取用户账号密码
 */
+ (NSMutableDictionary *)getLoginUser;
@end


/*!
 @abstract 基础代码
 */
@interface BaseCodeDetail : NSObject

@property (nonatomic, assign) int codeId;
@property (nonatomic, copy) NSString *codeName;
@property (nonatomic, assign) BOOL isUse;
@property (nonatomic, assign) int orderNum;
@property (nonatomic, assign) double codeValue;
@property (nonatomic, copy) NSString *codeString;

@end