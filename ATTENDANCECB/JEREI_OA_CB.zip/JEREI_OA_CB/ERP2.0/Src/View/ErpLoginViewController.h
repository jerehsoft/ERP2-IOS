//
//  ErpLoginViewController.h
//  ERP2.0
//
//  Created by jerei on 14-7-24.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JSViewController.h"
#import "Erp2.h"

@interface ErpLoginViewController : JSViewController
@property (nonatomic, copy) void(^blockForComplete)();

@end
