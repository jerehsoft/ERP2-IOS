//
//  SXNavigationController.m
//  BaseDev
//
//  Created by jereh on 15/12/1.
//  Copyright © 2015年 jerehsoft. All rights reserved.
//

#import "SXNavigationController.h"

@interface SXNavigationController ()

@end

@implementation SXNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    UINavigationBar *appearance = [UINavigationBar appearance];
    // 设置导航栏背景
    UIImage * image = [UIImage imageWithColor:[UIColor blackColor]];
    [appearance setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    
    //1>设置全局导航条外观
    [self setupNav];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 *  让屏幕上面的电池等状态颜色变成高亮
 */
-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

#pragma mark - 自定义方法

/**
 *  设置全局导航条
 */
- (void)setupNav{
    
    //获取应用程序中所有的导航条
    //获取所有导航条外观
    //拿到的是自己导航控制器的导航条
//    UINavigationBar * bar = [UINavigationBar appearanceWhenContainedIn:[SXNavigationController class], nil];
    UINavigationBar * bar;
    if ([UIDevice currentDevice].systemVersion.floatValue < 9.0) {
        bar = [UINavigationBar appearanceWhenContainedIn:[SXNavigationController class], nil];
    } else {
        bar = [UINavigationBar appearanceWhenContainedInInstancesOfClasses:@[[SXNavigationController class]]];
    }
    
    NSDictionary * dict = @{
                            NSForegroundColorAttributeName:[UIColor whiteColor],
                            NSFontAttributeName:[UIFont boldSystemFontOfSize:18]
                            };
    [bar setTitleTextAttributes:dict];
    
    //使得导航条上面的控件颜色设置为白色
    //主题颜色
    [bar setTintColor:[UIColor whiteColor]];
}

@end
