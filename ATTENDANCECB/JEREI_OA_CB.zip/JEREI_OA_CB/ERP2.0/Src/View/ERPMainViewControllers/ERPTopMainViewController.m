//
//  ERPTopMainViewController.m
//  BaseDev
//
//  Created by jereh on 16/6/7.
//  Copyright © 2016年 jerehsoft. All rights reserved.
//


#import "ERPTopMainViewController.h"
#import "SDCycleScrollView.h"
#import "UIView+MJExtension.h"
#import "JSUIUtils.h"
#import "ERPWebRequest.h"
#import "ErpFormDataUtils.h"
#import "JSUIUtils.h"
#import "ERPDataCache.h"
#import "BRTBeaconSDK.h"
#define KWidth [UIScreen mainScreen].bounds.size.width
#define KHeight [UIScreen mainScreen].bounds.size.height
#define ScrollHeight 650

@interface ERPTopMainViewController ()<SDCycleScrollViewDelegate,UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UIView *topPicPlayer;
@property (weak, nonatomic) IBOutlet UIView *secView;
@property (weak, nonatomic) IBOutlet UIView *ButtomView;
@property (weak, nonatomic) SDCycleScrollView *cycleScrollView;
@property (weak, nonatomic) IBOutlet UIView *MiddleView;

@end

@implementation ERPTopMainViewController
- (IBAction)KeepAttendanceRecordsClick:(id)sender {
    [self performSegueWithIdentifier:@"SegueKeepAttendanceRecords" sender:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];


    UIScrollView * scrollView = [[UIScrollView alloc]initWithFrame:self.view.bounds];
    scrollView.contentSize = CGSizeMake(0, self.view.frame.size.height);
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
//    scrollView.bounces = YES;
    scrollView.delegate = self;
    [self.view addSubview:scrollView];

    [scrollView addSubview:self.secView];


    [self addTopPicplayer];
    self.ButtomView.mj_h = ScrollHeight - _topPicPlayer.mj_h - _MiddleView.mj_h - 2;
    self.ButtomView.backgroundColor = [UIColor orangeColor];

    [self addNews];


    NSDictionary *loginUser = [ERPDataCache getLoginUser];
    ERPUser *user = [ERPUser userFromDictionary:loginUser];
    if (user && user.isValid) {
        [ERPAuthContext setUser:user];
    }
    [[ERPWebRequest mainSiteRequest] requestDataWithRelativeURI:@"phone/attenInfo.action"
                                                     withParams:@{@"userId":@(user.userId)}
                                                    withHeaders:nil
                                                 successHandler:^(NSDictionary *responseData) {

                                                     [BRTBeaconSDK startRangingWithUuids:@[[[NSUUID alloc] initWithUUIDString:DEFAULT_UUID]] onCompletion:^(NSArray *beacons, BRTBeaconRegion *region, NSError *error) {

                                                         NSLog(@"%@",beacons);

                                                         if (!error) {
                                                             NSLog(@"%@",beacons);
                                                             if (beacons.count == 0) {
                                                             }else{
                                                                 for (BRTBeacon *beaco in beacons) {
                                                                     for (NSDictionary *device in [responseData valueForKey:@"devices"]) {
                                                                         if ([[device valueForKey:@"machMac"] isEqualToString:beaco.macAddress]) {
                                                                             [ErpFormDataUtils setData:[device valueForKey:@"machMac"] forKey:@"machMacs"];
                                                                             [ErpFormDataUtils setData:@"YES" forKey:@"_cbFlag"];
//                                                                             [BRTBeaconSDK stopRangingBrightBeacons];

                                                                         }
                                                                     }
                                                                 }
                                                             }
                                                         }else{
                                                             //检查蓝牙是否打开
                                                             //                                                             [JSUIUtils popSuccessControllerWithType:5 message:@"请打开蓝牙!" complete:nil];
                                                         }
                                                     }];

                                                 }
                                                   errorHandler:^(MKNetworkOperation *operation, NSError *error) {

                                                       [JSUIUtils popSuccessControllerWithType:5 message:@"请在指定区域考勤,谢谢!" complete:nil];
                                                   }];





    [NSThread detachNewThreadSelector:@selector(asyncGetVersionData) toTarget:self withObject:nil];

}


#pragma mark - version update
- (void)asyncGetVersionData {
    NSString *localVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSURL *url=[[NSURL alloc] initWithString:@"https://raw.githubusercontent.com/jerehsoft/ERP2-IOS/master/ATTENDANCECB/jereiAttendance.plist"];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL:url];
    [request setHTTPMethod:@"GET"];
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSString *error;
    NSPropertyListFormat format;
    NSDictionary *plist = [NSPropertyListSerialization propertyListFromData:responseData mutabilityOption:NSPropertyListImmutable format:&format errorDescription:&error];
    NSString *webVersion = ((NSArray *)[plist valueForKeyPath:@"items.metadata.bundle-version"])[0];
    if (webVersion && ![localVersion isEqualToString:webVersion]) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view.window animated:YES];
        [JSUIUtils alertOKCancel:@"检测到新版本，是否更新？" withTitle:@"版本更新" buttonBlock:^(BOOL isCancel) {
            if (!isCancel) {
                [hud setLabelText:@"正在更新,请稍候···"];
                [hud show:YES];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"itms-services://?action=download-manifest&url=https://raw.githubusercontent.com/jerehsoft/ERP2-IOS/master/ATTENDANCECB/jereiAttendance.plist"]];
                [hud hide:YES];
            }else{
                [hud hide:YES];
            }
        }];
    } else {
        //[JSUIUtils alert:@"当前已经是最新版本" withTitle:@"温馨提示"];

    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation

 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


#pragma -mark加载图片轮播器
- (void)addTopPicplayer{
    // 情景二：采用网络图片实现

    // 情景一：采用本地图片实现
    NSArray *images = @[[UIImage imageNamed:@"homepage_new.jpg"]
                        ];

    NSArray *titles = @[@"最近新闻!"
                        ];

    /***************************************************************************************************
     *  网络加载 --- 创建带标题的图片轮播器
     ***************************************************************************************************/
//    SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:self.topPicPlayer.frame imageURLStringsGroup:nil]; // 模拟网络延时情景

    SDCycleScrollView * cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:self.topPicPlayer.frame  imagesGroup:images];
    self.cycleScrollView = cycleScrollView;
    cycleScrollView.mj_y = 0;
    cycleScrollView.infiniteLoop = YES;
    cycleScrollView.showPageControl = NO;
//    cycleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentRight;
    //是否显示pageControl，以及设置他的样式
//    cycleScrollView.pageControlStyle = SDCycleScrollViewPageContolStyleAnimated;
    cycleScrollView.delegate = self;
//    cycleScrollView.titlesGroup = titles;
//    cycleScrollView.dotColor = [UIColor orangeColor]; // 自定义分页控件小圆标颜色
//    cycleScrollView.placeholderImage = [UIImage imageNamed:@"pkq.png"];
    //         --- 轮播时间间隔，默认1.0秒，可自定义
    cycleScrollView.autoScrollTimeInterval = 1111111112.0;
    [self.topPicPlayer addSubview:cycleScrollView];


    //    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{});
//    cycleScrollView.imageURLStringsGroup = imagesURLStrings;


}

#pragma mark - SDCycleScrollViewDelegate
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
    [self showBasicAlertViewClick];
    //    [self performSegueWithIdentifier:@"segueToAboutUsList" sender:self];
}

- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didScrollToIndex:(NSInteger)index{
    
}

#pragma mark -addNews
- (void)addNews{
    UITableView * NewsTable = [[UITableView alloc]initWithFrame:self.ButtomView.frame style:UITableViewStyleGrouped];
    NewsTable.delegate = self;
    NewsTable.dataSource = self;
    NewsTable.mj_y = 0;
    NewsTable.sectionFooterHeight = 0;
//    NewsTable.userInteractionEnabled = NO;
    NewsTable.scrollEnabled = NO;
    [self.ButtomView addSubview:NewsTable];

}

#pragma mark - UITableViewDatasource
//返回行数
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

//    NSDictionary * temDic=self.dataArray[section];
//    NSArray * temArray=temDic[@"friends"];
    return 6;
}

//返回cell
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString * identy=@"table";
    UITableViewCell * cell=[tableView dequeueReusableCellWithIdentifier:identy];
    if (!cell) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identy];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [tableView deselectRowAtIndexPath:indexPath animated:NO];// 取消选中
//    NSDictionary * temDic=self.dataArray[indexPath.section];
//    NSArray * temArray=temDic[@"friends"];
//    cell.textLabel.text=temArray[indexPath.row];
    cell.textLabel.text = @"";
    return cell;

}

//返回分组数量
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
//    return self.dataArray.count;
    return 1;
}



#pragma mark - UITableViewDelegate
- (NSString*) tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
//    NSDictionary * temDic=self.dataArray[section];
//    return temDic[@"group"];
    return @"最新公文";

}

//
//- (NSString *) tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section{
//return @"hello world";
//}


#pragma mark * 自定义头部
- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{

    UIView * view=[[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    view.backgroundColor=[UIColor whiteColor];
    UILabel * titleLable = [[UILabel alloc]initWithFrame:CGRectMake(15, 2, 100, 40)];
    titleLable.text = @"最新公文";
    titleLable.font = [UIFont systemFontOfSize:16];
    titleLable.textColor = [UIColor blackColor];
    [view addSubview:titleLable];


    return view;
}

#pragma mark * 自定义尾部
//- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
//
//    UIView * view=[[UIView alloc] init];
//    view.backgroundColor=[UIColor blueColor];
//    return view;
//}

#pragma mark * 设置头部的高度
- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 44;
}

#pragma mark * 设置尾部的高度
//- (CGFloat) tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
//    return 30;
//}


//- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView{
//
//    NSMutableArray * array=[NSMutableArray array];
//    for (NSDictionary *dic  in self.dataArray) {
//        [array addObject:dic[@"group"]];
//    }
//
//    return array;
//
//
//}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    [self showBasicAlertViewClick];
}


#pragma mark - 敬请期待
- (void)showBasicAlertViewClick{
    NSString *alertTitle = @"温馨提示";
    NSString *alertMessage = @"正在完善中...";
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:alertTitle
                                                                             message:alertMessage
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction *action)
                               {}];
    
    [alertController addAction:okAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
    
}



@end

