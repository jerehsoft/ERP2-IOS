//
//  JRTabBar.h
//  WYNews
//
//  Created by 李亚奇 on 15/6/25.
//  Copyright (c) 2015年 jereh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JRTabBarButton.h"

@class JRTabBar;

//如果需要传参数给其他对象，block才需要定义参数
typedef void(^JRTabBarBlock)(int selectIndex);


//@protocol JRTabBarDelegate <NSObject>
//
//@optional
//
//- (void)tabBar:(JRTabBar *)tabBar didSelectedIndex:(int)index;
//
//@end



@interface JRTabBar : UIView


//相当于一个小弟，叫他做事情
@property(nonatomic,copy)JRTabBarBlock block;

//@property(nonatomic,weak)id<JRTabBarDelegate>delegate;


// 给外界创建按钮
- (void)addTabBarButtonWithName:(NSString *)name selName:(NSString *)selName index:(int)index;
@end
