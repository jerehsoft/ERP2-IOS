//
//  JRTabBarButton.h
//  WYNews
//
//  Created by 李亚奇 on 15/6/25.
//  Copyright (c) 2015年 jereh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JRTabBarButton : UIButton

@end
