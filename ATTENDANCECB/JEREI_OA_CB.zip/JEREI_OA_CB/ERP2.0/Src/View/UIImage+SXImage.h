//
//  UIImage+SXImage.h
//  BaseDev
//
//  Created by jereh on 15/12/1.
//  Copyright © 2015年 jerehsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (SXImage)
+ (UIImage *)imageWithColor:(UIColor *)color;
@end
