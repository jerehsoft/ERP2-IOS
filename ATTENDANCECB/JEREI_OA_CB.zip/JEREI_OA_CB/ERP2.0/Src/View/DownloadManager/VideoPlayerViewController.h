//
//  VideoPlayerViewController.h
//  CNNCTrain
//
//  Created by jerei on 14-8-26.
//
//

#import <UIKit/UIKit.h>

@interface VideoPlayerViewController : UIViewController
@property (copy, nonatomic) NSString *bookId;
- (instancetype)initWithVideoFile:(NSString *)videoFile title:(NSString *)title;

@end
