//
//  DownloadListBaseViewController.h
//  CNNCTrain
//
//  Created by jerei on 14-8-22.
//
//

#import <UIKit/UIKit.h>
#import "DownloadManager.h"

#define BROWSER_DISMISSING_NOTIFICATION @"DISMISSING_BROWSER"

@interface DownloadListBaseViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITableView *tableView;

- (void)clearData;

- (TaskRepository)taskRepository;
// 重载点：提供任务数据
- (NSArray *)copyOfTasks;

@end
