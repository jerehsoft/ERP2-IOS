//
//  DownloadHistoryViewController.m
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//

#import "DownloadHistoryViewController.h"
#import "TaskCell.h"

@interface DownloadHistoryViewController ()
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@end

@implementation DownloadHistoryViewController

- (NSArray *)copyOfTasks
{
    return [DownloadManager copyOfHistoryTasks];
}

- (TaskRepository)taskRepository
{
    return TaskRepositoryHistory;
}

@end
