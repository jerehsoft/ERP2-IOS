//
//  DMEntryViewController.h
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//

#import <UIKit/UIKit.h>

@interface DMEntryViewController : UIViewController

+ (NSString *)currentUserId;
+ (void)setCurrentUserId:(NSString *)userId;
+ (NSString *)currentUserOrganizeNo;
+ (void)setCurrentUserOrganizeNo:(NSString *)organizeNo;
+ (NSString *)currentUserFullName;
+ (void)setCurrentUserFullName:(NSString *)fullName;

@end
