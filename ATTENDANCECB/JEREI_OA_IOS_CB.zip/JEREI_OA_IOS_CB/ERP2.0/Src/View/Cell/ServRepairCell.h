//
//  ServRepairCell.h
//  BaseDev
//
//  Created by jereh on 16/3/26.
//  Copyright © 2016年 jerehsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServRepairCell : UITableViewCell

@end

#pragma mark - ServRepairTitleCell 顶部cell
/** 顶部cell */
@interface ServRepairTopCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *tel;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *distance;
@property (weak, nonatomic) IBOutlet UIImageView *faceView;
@property (weak, nonatomic) IBOutlet UIButton *callBtn;
@property (weak, nonatomic) IBOutlet UIButton *navBtn;

+ (instancetype)cellWithTableView:(UITableView *)tableView;
+ (CGFloat)height;

@end

#pragma mark - ServRepairMiddleCell 中间cell
/** 中间cell */
@interface ServRepairMiddleCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *modelNo;
@property (weak, nonatomic) IBOutlet UITextView *remark;
@property (weak, nonatomic) IBOutlet UICollectionView *repairPics;

+ (instancetype)cellWithTableView:(UITableView *)tableView;
+ (CGFloat)height;

@end

#pragma mark - ServRepairNormalCell
/**  */
@interface ServRepairNormalCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *img;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *moneyAndCount;

+ (instancetype)cellWithTableView:(UITableView *)tableView;
+ (CGFloat)height;

@end

#pragma mark - ServRepairSection_1_Header 故障代码
/** 故障代码 */
@interface ServRepairSection_1_Header : UIView

@property (weak, nonatomic) IBOutlet UIButton *addBtn;

+ (instancetype)viewFormNib;
+ (CGFloat)height;

@end

#pragma mark - ServRepairSection_2_Header 维修配件 小计
/** 维修配件 小计 */
@interface ServRepairSection_2_Header : UIView

@property (weak, nonatomic) IBOutlet UILabel *moneyLabel;
@property (weak, nonatomic) IBOutlet UIButton *addBtn;

+ (instancetype)viewFormNib;
+ (CGFloat)height;

@end

#pragma mark - ServRepairSection_2_Footer 维修配件 收款
/** 维修配件 收款 */
@interface ServRepairSection_2_Footer : UIView

@property (weak, nonatomic) IBOutlet UITextField *moneyTextField;

+ (instancetype)viewFormNib;
+ (CGFloat)height;

@end

#pragma mark - ServRepairSection_3_Header 维修费用小计
/** 维修费用小计 */
@interface ServRepairSection_3_Header : UIView

@property (weak, nonatomic) IBOutlet UILabel *moneyLabel;
@property (weak, nonatomic) IBOutlet UIButton *addBtn;

+ (instancetype)viewFormNib;
+ (CGFloat)height;

@end

#pragma mark - ServRepairSection_3_Footer 维修费用收款
/** 维修费用收款 */
@interface ServRepairSection_3_Footer : UIView

@property (weak, nonatomic) IBOutlet UITextField *moneyTextField;

+ (instancetype)viewFormNib;
+ (CGFloat)height;

@end

#pragma mark - ServRepairBottomBtnCell 底部按钮
/** 底部按钮 */
@interface ServRepairBottomBtnCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *submitBtn;

+ (instancetype)cellWithTableView:(UITableView *)tableView;
+ (CGFloat)height;

@end
