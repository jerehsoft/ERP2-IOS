//
//  ServRepairCell.m
//  BaseDev
//
//  Created by jereh on 16/3/26.
//  Copyright © 2016年 jerehsoft. All rights reserved.
//

#import "ServRepairCell.h"

@implementation ServRepairCell

@end

#pragma mark - ServRepairTitleCell 顶部cell
@implementation ServRepairTopCell

- (void)awakeFromNib {
    _callBtn.layer.masksToBounds = YES;
    _callBtn.layer.cornerRadius = 25;
    _navBtn.layer.masksToBounds = YES;
    _navBtn.layer.cornerRadius = 25;
    _faceView.layer.masksToBounds = YES;
    _faceView.layer.cornerRadius = 28;
}

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    static NSString *ID = @"topCell";
    ServRepairTopCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[NSBundle mainBundle] loadNibNamed:@"ServRepairCell" owner:nil options:nil][0];
        [cell setValue:ID forKey:@"reuseIdentifier"];
    }
    return cell;
}

+ (CGFloat)height {
    return 180.f;
}

@end

#pragma mark - ServRepairMiddleCell 中间cell
@implementation ServRepairMiddleCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    static NSString *ID = @"middleCell";
    ServRepairMiddleCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[NSBundle mainBundle] loadNibNamed:@"ServRepairCell" owner:nil options:nil][1];
        [cell setValue:ID forKey:@"reuseIdentifier"];
    }
    return cell;
}

+ (CGFloat)height {
    return 270.f;
}

@end

#pragma mark - ServRepairNormalCell
@implementation ServRepairNormalCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    static NSString *ID = @"normalCell";
    ServRepairNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[NSBundle mainBundle] loadNibNamed:@"ServRepairCell" owner:nil options:nil][2];
        [cell setValue:ID forKey:@"reuseIdentifier"];
    }
    return cell;
}

+ (CGFloat)height {
    return 50.f;
}

@end

#pragma mark - ServRepairSection_1_Header 故障代码
@implementation ServRepairSection_1_Header

+ (instancetype)viewFormNib {
    ServRepairSection_1_Header *v = [[NSBundle mainBundle] loadNibNamed:@"ServRepairCell" owner:nil options:nil][3];
    return v;
}

+ (CGFloat)height {
    return 40.f;
}

@end

#pragma mark - ServRepairSection_2_Header 维修配件 小计
@implementation ServRepairSection_2_Header

+ (instancetype)viewFormNib {
    ServRepairSection_2_Header *v = [[NSBundle mainBundle] loadNibNamed:@"ServRepairCell" owner:nil options:nil][4];
    return v;
}

+ (CGFloat)height {
    return 40.f;
}

@end

#pragma mark - ServRepairSection_2_Footer 维修配件 收款
@implementation ServRepairSection_2_Footer

+ (instancetype)viewFormNib {
    ServRepairSection_2_Footer *v = [[NSBundle mainBundle] loadNibNamed:@"ServRepairCell" owner:nil options:nil][5];
    return v;
}

+ (CGFloat)height {
    return 41.f;
}

@end

#pragma mark - ServRepairSection_3_Header 维修费用小计
@implementation ServRepairSection_3_Header

+ (instancetype)viewFormNib {
    ServRepairSection_3_Header *v = [[NSBundle mainBundle] loadNibNamed:@"ServRepairCell" owner:nil options:nil][6];
    return v;
}

+ (CGFloat)height {
    return 40.f;
}

@end

#pragma mark - ServRepairSection_3_Footer 维修费用收款
@implementation ServRepairSection_3_Footer

+ (instancetype)viewFormNib {
    ServRepairSection_3_Footer *v = [[NSBundle mainBundle] loadNibNamed:@"ServRepairCell" owner:nil options:nil][7];
    return v;
}

+ (CGFloat)height {
    return 40.f;
}

@end

#pragma mark - ServRepairBottomBtnCell 底部按钮
@implementation ServRepairBottomBtnCell

- (void)awakeFromNib {
    _submitBtn.layer.masksToBounds = YES;
    _submitBtn.layer.cornerRadius = 5;
}

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    static NSString *ID = @"btnCell";
    ServRepairBottomBtnCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[NSBundle mainBundle] loadNibNamed:@"ServRepairCell" owner:nil options:nil][8];
        [cell setValue:ID forKey:@"reuseIdentifier"];
    }
    return cell;
}

+ (CGFloat)height {
    return 40.f;
}

@end