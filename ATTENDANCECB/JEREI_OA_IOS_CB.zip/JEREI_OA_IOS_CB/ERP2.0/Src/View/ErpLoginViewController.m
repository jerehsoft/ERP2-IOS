//
//  ErpLoginViewController.m
//  ERP2.0
//
//  Created by jerei on 14-7-24.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ErpLoginViewController.h"
#import "MBProgressHUD.h"
#import "FMDB.h"
#import "ERPDataCache.h"
#import "ErpFormDataUtils.h"
#import "UIImageView+WebCache.h"
#import "UIView+MJExtension.h"

@interface ErpLoginViewController ()
{
    NSArray *accessModules;
    NSDictionary *_queryParams;
}

// 登录
@property (strong, nonatomic) IBOutlet UIView *uidView;
@property (strong, nonatomic) IBOutlet UIView *pwdView;
@property (strong, nonatomic) IBOutlet UITextField *txtUid;
@property (strong, nonatomic) IBOutlet UITextField *txtPwd;
@property (strong, nonatomic) IBOutlet UIButton *btnLogin;

@end

@implementation ErpLoginViewController{
    BOOL viewFirstAppear;
}

#pragma mark viewcontroller methods
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

BOOL dataCachePrepared = NO;
- (void)viewDidLoad {
    viewFirstAppear = YES;
    [super viewDidLoad];
    
    // 清除输入框背景和边框
    self.uidView.layer.cornerRadius = 5;
    self.pwdView.layer.cornerRadius = 5;
    self.uidView.layer.borderWidth = 1;
    self.pwdView.layer.borderWidth = 1;
    self.uidView.layer.borderColor = [[UIColor whiteColor] CGColor];
    self.pwdView.layer.borderColor = [[UIColor whiteColor] CGColor];
    
    self.txtUid.backgroundColor = [UIColor clearColor];
    self.txtPwd.backgroundColor = [UIColor clearColor];
    self.txtUid.keyboardType = UIKeyboardTypeDefault;
    self.txtUid.borderStyle = UITextBorderStyleNone;
    self.txtPwd.borderStyle = UITextBorderStyleNone;
    
    self.txtUid.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"用户名" attributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];
    self.txtPwd.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"密码" attributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];
    
    // 登录按钮边框和底色渐变
    [self.btnLogin setTitle:@"正在登录..." forState:UIControlStateDisabled];
    _btnLogin.layer.cornerRadius = 5;
    
    [self prepareDataCache];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSDictionary *loginUser = [ERPDataCache getLoginUser];
    self.txtUid.text = [loginUser valueForKey:@"userNo"];
    NSLog(@"%@",self.txtUid.text);
    self.txtPwd.text = [loginUser valueForKey:@"pwd"];
    viewFirstAppear = NO;
    if ((self.txtUid.text.length > 0) && (self.txtPwd.text > 0)) {
         [self login:nil];
    }
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)prepareDataCache
{
    __weak ErpLoginViewController *weakSelf = self;
    // 准备本地数据库
    [ERPDataCache prepare:^(float progress) {
        NSLog(@"preparing data cache : %f", progress);
        if (progress >= 1.0f) {
            dataCachePrepared = YES;
        }
    } errorCallback:^(NSError *error) {
        [JSUIUtils alert:@"无法创建数据缓存，请重试" withTitle:@"创建缓存失败" buttonBlock:^(NSString *buttonTitle) {
            [weakSelf prepareDataCache];
        }];
    }];
}

// 触摸输入框之外的未知隐藏键盘
- (IBAction)tapOnBackground:(id)sender
{
    [self.txtUid resignFirstResponder];
    [self.txtPwd resignFirstResponder];
}

// 检查必填项并返回账号密码
- (BOOL)extractUserInfoAndValidate:(NSString **)uid password:(NSString **)pwd
{
    UIView * coverView = [[UIView alloc]initWithFrame:self.view.frame];
    coverView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.mj_h - self.btnLogin.mj_y + 10);
    coverView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:coverView];
    *uid = self.txtUid.text;
    *pwd = self.txtPwd.text;
    BOOL valid = (*uid) && (*uid).length && (*pwd) && (*pwd).length;
    if (!valid) {
        [coverView removeFromSuperview];
        [JSUIUtils alert:@"请填写用户名和密码" withTitle:@"温馨提示"];
    }


    return valid;
}

//159369
//123456
- (IBAction)login:(id)sender {
    if (!dataCachePrepared) {
        [JSUIUtils alert:@"数据缓存未准备好，请稍后重试" withTitle:@"缓存未创建"];
        return;
    }
    
    NSString *uid, *pwd;
    if (![self extractUserInfoAndValidate:&uid password:&pwd])
        return;
    
    self.btnLogin.enabled = NO;
    __weak ErpLoginViewController *weakSelf = self;
    // 登录
    NSLog(@"准备登录 : uid -> '%@', pwd -> '%@'", uid, pwd);
    NSDictionary *params = [[NSDictionary alloc] initWithObjectsAndKeys: uid, @"userNo", pwd, @"pwd", nil];
    [[ERPWebRequest mainSiteRequest] requestDataWithRelativeURI:@"pLogin.action"
                                                     withParams:params
                                                    withHeaders:nil
                                                 successHandler:^(NSDictionary *responseData) {
                                                     NSLog(@"登录成功 : %@", @"succeeded"/*responseData*/);
                                                     weakSelf.btnLogin.enabled = YES;
                                                     NSDictionary *userData = [responseData valueForKey:@"user"];
                                                     ERPUser *user = [ERPUser userFromDictionary:userData];
                                                     [ERPDataCache saveLoginUser:[NSString stringWithFormat:@"%ld",(long)user.userId] userNo:user.userNo userName:user.userName password:self.txtPwd.text complete:^{
                                                         if (user && user.isValid) {
                                                             [ERPAuthContext setUser:user];
                                                             __weak ErpLoginViewController *weakSelf = self;
                                                             [weakSelf gotoMain];
                                                         }
                                                     } error:nil];
                                                 }
                                                   errorHandler:^(MKNetworkOperation *operation, NSError *error) {
                                                       // 登录失败
                                                       NSLog(@"登录失败 : %@", error);
                                                       weakSelf.btnLogin.enabled = YES;
//                                                       [weakSelf gotoMain];
                                                       NSString *errorMessage = [[error userInfo] valueForKey:NSLocalizedDescriptionKey];
                                                       [JSUIUtils alert:errorMessage withTitle:@"登录失败"];
                                                   }];
}

- (BOOL)isCacheOutOfSync:(NSInteger)dataCacheDay
{
    return NO;
}

- (void)gotoMain
{
    [self performSegueWithIdentifier:@"SegueToMainSelect" sender:self];

//    if (self.blockForComplete) {
//        self.blockForComplete();
//    }
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
