//
//  ActionManager.h
//  CNNCTrain
//
//  Created by jerei on 14-8-25.
//
//

#import <Foundation/Foundation.h>

@interface ActionManager : NSObject

// 指定请求地址
+ (NSURLRequest *)requestForAndroidAction:(NSString *)actionWithoutAndroidPrefix params:(NSDictionary *)params;
+ (NSURLRequest *)requestForUrl:(NSString *)url;
+ (NSString *)composedUrlForAndroidAction:(NSString *)actionWithoutAndroidPrefix params:(NSDictionary *)params;
// 提交学习时间
+ (NSURLRequest *)requestForSubmitCourseTime:(NSString *)bookId time:(double)time page:(int)page total:(int)total;
+ (NSString *)composedUrlForSubmitCourseTime:(NSString *)bookId time:(double)time page:(int)page total:(int)total;
// pdf课程页数
+ (NSURLRequest *)requestForBookPages:(NSString *)bookId;
+ (NSString *)composedUrlForBookPages:(NSString *)bookId;

@end
