//
//  DMTabBarController.h
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//

#import <UIKit/UIKit.h>
#import "DownloadManager.h"

@interface DMTabBarController : UITabBarController

- (void)clearData;

@end
