//
//  Downloader.h
//  CNNCTrain
//
//  Created by jerei on 14-8-21.
//
//

#import <Foundation/Foundation.h>

@class Downloader;

// 下载监听delegate
@protocol DownloadDelegate<NSObject>

@required
// 接收到header，可根据header信息计算文件大小
- (void)downloader:(Downloader *)downloader headerReceived:(NSDictionary *)header;
// 接收到数据块
- (void)downloader:(Downloader *)downloader dataReceived:(NSData *)chunkOfData;
// 下载开始
- (void)downloader:(Downloader *)downloader startedOn:(NSDate *)timeStarted;
// 连接／下载失败，或服务器返回了错误的状态码
- (void)downloader:(Downloader *)downloader failedWithMessage:(NSString *)errorMessage;
// 下载完成
- (void)downloader:(Downloader *)downloader done:(NSDate *)timeDone;

@end

// 文件下载器，取消或失败后不能重新开始
@interface Downloader : NSObject<NSURLConnectionDataDelegate>

// 从指定位置开始下载
- (instancetype)initWithURL:(NSString *)url startFrom:(unsigned long)startFrom delegate:(id<DownloadDelegate>)delegate;
// 取消任务
- (void)cancel;

@end
