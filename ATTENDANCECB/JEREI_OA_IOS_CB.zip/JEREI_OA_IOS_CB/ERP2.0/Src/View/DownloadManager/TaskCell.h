//
//  TaskCell.h
//  CNNCTrain
//
//  Created by jerei on 14-8-22.
//
//

#import <UIKit/UIKit.h>
#import "DownloadTask.h"

#define NOTIFICATION_TASK_TAPPED @"TASK_TAPPED"

@interface TaskCell : UITableViewCell

@property (nonatomic, readonly, assign) DownloadTask *task;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier size:(CGSize)size;
- (void)updateViewWithTask:(DownloadTask *)task;
+ (float)cellHeight;

@end
