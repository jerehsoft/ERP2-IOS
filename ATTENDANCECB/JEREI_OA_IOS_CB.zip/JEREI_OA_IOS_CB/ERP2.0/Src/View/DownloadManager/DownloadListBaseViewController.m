//
//  DownloadListBaseViewController.m
//  CNNCTrain
//
//  Created by jerei on 14-8-22.
//
//

#import "DownloadListBaseViewController.h"
#import "TaskCell.h"
#import "MBProgressHUD.h"
#import "Zipper.h"
#import "SDImageCache.h"
#import "ImageBrowserViewController.h"
#import "VideoPlayerViewController.h"

@interface DownloadListBaseViewController ()<DownloadManagerDelegate, UITableViewDataSource, UITableViewDelegate, UIAlertViewDelegate>
{
    NSMutableArray *_tasks;
    NSMutableDictionary *_taskCellMap;
    
    // 打开browser之前记录要清理的文件，在接收到通知后删除
    NSMutableArray *_tempResources;
    
    __weak TaskCell *_selectedTaskCell;
}

@end

@implementation DownloadListBaseViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _taskCellMap = [NSMutableDictionary dictionaryWithCapacity:16];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = [TaskCell cellHeight];
    self.tableView.allowsSelection = NO;
    if ([self.tableView respondsToSelector:@selector(setSeparatorInset:)])
        self.tableView.separatorInset = UIEdgeInsetsZero;
    
    [DownloadManager registerDelegate:self];
    // downloadmanager恢复状态时不会触发queueChange，所以恢复视图时需要主动获取任务列表
    _tasks = [NSMutableArray arrayWithArray:[self copyOfTasks]];
    [self.tableView reloadData];
    
    _tempResources = [NSMutableArray arrayWithCapacity:3];
    // 接收browser关闭通知，及时清理临时资源
    [self _observeNotification];
}


- (void)_observeNotification
{
    [self _unobserveNotification];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(_cleanUpTempResources:)
                                                 name:BROWSER_DISMISSING_NOTIFICATION
                                               object:nil];
}

- (void)_unobserveNotification
{
    @try {
        [[NSNotificationCenter defaultCenter] removeObserver:self
                                                        name:BROWSER_DISMISSING_NOTIFICATION
                                                      object:nil];
    }
    @catch (NSException *exception) {
        NSLog(@"ex = %@", exception);
    }
}


- (void)dealloc
{
    [self printDealloc];
    [self _unobserveNotification];
    _taskCellMap = nil;
    _tasks = nil;
    _tempResources = nil;
}


- (void)queueChangedForTask:(DownloadTask *)task source:(TaskRepository)source destination:(TaskRepository)destination
{
    if (destination == [self taskRepository]) {
        [_tasks insertObject:task atIndex:0];
        [self.tableView insertRowsAtIndexPaths:@[ [NSIndexPath indexPathForRow:0 inSection:0] ]
                              withRowAnimation:UITableViewRowAnimationLeft];
    }
    else if (source == [self taskRepository] && destination != [self taskRepository]) {
        for (NSUInteger idx = 0; idx < _tasks.count; ++idx) {
            if ([task.resourceId isEqualToString:((DownloadTask*)_tasks[idx]).resourceId]) {
                [_tasks removeObjectAtIndex:idx];
                [self.tableView deleteRowsAtIndexPaths:@[ [NSIndexPath indexPathForRow:idx inSection:0] ]
                                      withRowAnimation:UITableViewRowAnimationRight];
                break;
            }
        }
        
    }
}

- (void)progressChangedForTask:(DownloadTask *)task
{
    TaskCell *cell = [_taskCellMap valueForKey:task.resourceId];
    [cell updateViewWithTask:task];
}

- (void)stateChangedForTask:(DownloadTask *)task
{
    // 如果目标状态为完成，则会被移动到另一个队列，将由queueChangedForTask处理
    if (task.state != TaskDownDone) {
        TaskCell *cell = [_taskCellMap valueForKey:task.resourceId];
        [cell updateViewWithTask:task];
    }
}

#pragma mark Task Action


#pragma mark TableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _tasks.count;
}


#pragma mark empty abstract methods
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TaskCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        CGSize size = CGSizeMake(tableView.bounds.size.width, tableView.rowHeight);
        cell = [[TaskCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell" size:size];
        cell.textLabel.highlightedTextColor = [UIColor redColor];
        
        UILongPressGestureRecognizer *gr = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(onLongPress:)];
        gr.minimumPressDuration = .7;
        [cell addGestureRecognizer:gr];
    }
    
    DownloadTask *task = [_tasks objectAtIndex:indexPath.row];
    [cell updateViewWithTask:task];
    // 记录任务对应的cell实例，在刷新时查表获取实例并更新，通过dequeueReusableCellWithIdentifier获取的实例通常都不是显示task的实例
    [_taskCellMap setValue:cell forKey:task.resourceId];
    return cell;
}

- (void)onLongPressTimer:(NSTimer *)timer
{
    pressTimer += timer.timeInterval;
    if (pressTimer > 1) {
        [_selectedTaskCell setHighlighted:YES animated:YES];
        [timer invalidate];
    }
}

static double pressTimer = 0;
// 长按提示删除
- (void)onLongPress:(UILongPressGestureRecognizer *)gr
{
    static BOOL pressChanged = NO;
    static NSTimer *timer;
    if (gr.state == UIGestureRecognizerStateBegan) {
        _selectedTaskCell = (TaskCell *)gr.view;
        pressTimer = 0;
        if (timer) {
            [timer invalidate];
            timer = nil;
        }
        timer = [NSTimer scheduledTimerWithTimeInterval:.05 target:self selector:@selector(onLongPressTimer:) userInfo:nil repeats:YES];
        pressChanged = NO;
    }
    else if (gr.state == UIGestureRecognizerStateChanged || gr.state == UIGestureRecognizerStateCancelled) {
        pressChanged = YES;
        [timer invalidate];
    }
    else if (gr.state == UIGestureRecognizerStateEnded && !pressChanged) {
        // 删除
        [timer invalidate];
        [[[UIAlertView alloc] initWithTitle:@"删除"
                                   message:@"是否删除任务?"
                                  delegate:self
                         cancelButtonTitle:@"取消"
                         otherButtonTitles:@"删除", nil] show];
    }
}

- (void)alertView:(UIAlertView *)alertView willDismissWithButtonIndex:(NSInteger)buttonIndex
{
    [_selectedTaskCell setHighlighted:NO animated:NO];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if ([[alertView buttonTitleAtIndex:buttonIndex] isEqualToString:@"删除"]) {
        [alertView dismissWithClickedButtonIndex:buttonIndex animated:YES];
        [DownloadManager cancelTask:_selectedTaskCell.task];
    }
}

- (NSArray *)copyOfTasks
{
    NSLog(@"This method should be overridden");
    return nil;
}

- (TaskRepository)taskRepository
{
    return TaskRepositoryNull;
}
- (void)clearData
{
    [DownloadManager clearRepository:self.taskRepository];
}



- (void)_cleanUpTempResources:(NSNotification *)notification
{
    NSLog(@"清理临时文件: %@", _tempResources);
    for (NSString *resPath in _tempResources) {
        [[NSFileManager defaultManager] removeItemAtPath:resPath error:nil];
    }
    [_tempResources removeAllObjects];
}

@end


