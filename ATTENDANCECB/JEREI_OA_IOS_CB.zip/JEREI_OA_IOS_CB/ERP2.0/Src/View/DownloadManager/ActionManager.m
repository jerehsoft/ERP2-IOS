//
//  ActionManager.m
//  CNNCTrain
//
//  Created by jerei on 14-8-25.
//
//

#import "ActionManager.h"
#import "DMEntryViewController.h"
#import "DownloadManager.h"

#define CNNC_ACTION_TIMEOUT 10

@implementation ActionManager

// 课程页数
+ (NSString *)composedUrlForBookPages:(NSString *)bookId
{
    NSDictionary *params = @{
                             @"bookId" : bookId
                             };
    return [ActionManager composedUrlForAndroidAction:@"mCourse/course_getPage.action" params:params];
}
+ (NSURLRequest *)requestForBookPages:(NSString *)bookId
{
    NSString *url = [ActionManager composedUrlForBookPages:bookId];
    return [ActionManager requestForUrl:url];
}

// 学习时间
+ (NSURLRequest *)requestForSubmitCourseTime:(NSString *)bookId time:(double)time page:(int)page total:(int)total
{
    NSString *url = [ActionManager composedUrlForSubmitCourseTime:bookId time:time page:page total:total];
    return [ActionManager requestForUrl:url];
}

+ (NSString *)composedUrlForSubmitCourseTime:(NSString *)bookId time:(double)time page:(int)page total:(int)total
{
    NSDictionary *params = @{
                             @"bookId" : bookId,
                             @"time" : [NSString stringWithFormat:@"%d", (int)time],
                             @"page" : [NSString stringWithFormat:@"%d", page],
                             @"total" : [NSString stringWithFormat:@"%d", total]
                             };
    return [ActionManager composedUrlForAndroidAction:@"mCourse/course_submitTime.action" params:params];
}

+ (NSURLRequest *)requestForAndroidAction:(NSString *)actionWithoutAndroidPrefix params:(NSDictionary *)params
{
    NSString *url = [ActionManager composedUrlForAndroidAction:actionWithoutAndroidPrefix params:params];
    return [ActionManager requestForUrl:url];
}

+ (NSURLRequest *)requestForUrl:(NSString *)url
{
    return [NSURLRequest requestWithURL:[NSURL URLWithString:url]
                            cachePolicy:NSURLCacheStorageNotAllowed
                        timeoutInterval:CNNC_ACTION_TIMEOUT];
}

+ (NSString *)composedUrlForAndroidAction:(NSString *)actionWithoutAndroidPrefix params:(NSDictionary *)params
{
    actionWithoutAndroidPrefix = [actionWithoutAndroidPrefix stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/"]];
    if ([actionWithoutAndroidPrefix hasPrefix:@"android/"])
        actionWithoutAndroidPrefix = [actionWithoutAndroidPrefix substringFromIndex:8];
    actionWithoutAndroidPrefix = [actionWithoutAndroidPrefix stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/"]];
    
    
    NSMutableString *url = [NSMutableString stringWithFormat:@"%@/android/", [DownloadManager webRoot]];
    [url appendString:actionWithoutAndroidPrefix];
    if ([url rangeOfString:@"?"].length) {
        [url appendString:@"&"];
    }
    else {
        [url appendString:@"?"];
    }
    
    if (params) {
        NSMutableDictionary *newParams;
        newParams = [NSMutableDictionary dictionaryWithDictionary:params];
        [newParams setValue:[DMEntryViewController currentUserId] forKey:@"userName"];
        [newParams setValue:[DMEntryViewController currentUserFullName] forKey:@"fullName"];
        [newParams setValue:[DMEntryViewController currentUserOrganizeNo] forKey:@"organizeNo"];
        
        
        for (NSString *key in newParams) {
            id value = [newParams valueForKey:key];
            if ([value isKindOfClass:[NSNull class]])
                value = @"";
            [url appendString:key];
            [url appendString:@"="];
            [url appendString:[[value description] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            [url appendString:@"&"];
        }
        if (newParams.count)
            [url deleteCharactersInRange:NSMakeRange(url.length - 1, 1)];
    }
    
    NSLog(@"url -> %@", url);
    return url;
}


@end
