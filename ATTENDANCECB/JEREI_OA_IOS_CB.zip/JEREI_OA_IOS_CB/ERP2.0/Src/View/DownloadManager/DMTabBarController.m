//
//  DMTabBarController.m
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//

#import "DMTabBarController.h"
#import "MBProgressHUD.h"
#import "Zipper.h"
#import "SDImageCache.h"
#import "ImageBrowserViewController.h"
#import "VideoPlayerViewController.h"
#import "TaskCell.h"

@interface DMTabBarController ()<UIDocumentInteractionControllerDelegate>
{
    UIDocumentInteractionController *documentController;
}
@end

@implementation DMTabBarController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
}

- (void)clearData
{
    // 通知当前的tab清空数据
    UIViewController *currentTabVc = self.selectedViewController;
    if ([currentTabVc respondsToSelector:@selector(clearData)]) {
        [currentTabVc performSelector:@selector(clearData)];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self _observeNotification];
}
- (void)dealloc
{
    [self printDealloc];
    [self _unobserveNotification];
}

- (void)_observeNotification
{
    [self _unobserveNotification];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(taskTapped:)
                                                 name:NOTIFICATION_TASK_TAPPED
                                               object:nil];
}

- (void)_unobserveNotification
{
    @try {
        [[NSNotificationCenter defaultCenter] removeObserver:self
                                                        name:NOTIFICATION_TASK_TAPPED
                                                      object:nil];
    }
    @catch (NSException *exception) {
        NSLog(@"ex = %@", exception);
    }
}

- (void)taskTapped:(NSNotification *)notification
{
    NSString *command = [notification.userInfo valueForKey:@"command"];
    DownloadTask *task = notification.object;
    NSLog(@"task tapped : %@, task : %@", command, task);
    if ([command isEqualToString:@"下载"] || [command isEqualToString:@"重试"]) {
        [task start];
    }
    else if ([command isEqualToString:@"暂停"]) {
        [task pause];
    }
    else if ([command isEqualToString:@"取消"]) {
        [task cancel];
    }
    else if ([command isEqualToString:@"打开"]) {
        if ([task.fileType isEqualToString:@".jpg"] || [task.fileType isEqualToString:@".JPG"]) {
            [self openImgViewerForTask:task];
        }
        else if ([task.fileType isEqualToString:@".png"] || [task.fileType isEqualToString:@".PNG"]) {
            [self openImgViewerForTask:task];
        }
        else if ([task.fileType isEqualToString:@".mp4"] || [task.fileType isEqualToString:@".MP4"]) {
            [self openVideoViewerForTask:task];
        }
        else {
            //            [JSUIUtils alert:@"未知的文件类型" withTitle:@"无法浏览"];
            NSString *cachePath = [DownloadTask pathForResourceFile:task.resourceId];
            NSLog(@"open path : %@",cachePath);
            if(cachePath != nil) {
                if (documentController == nil) {
                    documentController = [[UIDocumentInteractionController alloc] init];
                    
                    documentController = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:cachePath]];
                    documentController.delegate = self;
                    //[fileInteractionController retain];
                }else {
                    documentController.URL = [NSURL fileURLWithPath:cachePath];
                }
                //                [documentController presentPreviewAnimated:YES];
                [documentController presentOpenInMenuFromRect:CGRectZero inView:self.view animated:YES];
            }
        }
    }
    else {
        NSLog(@"未知的命令");
    }
}

- (UIViewController *)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)interactionController
{
    return self;
}

-(UIView *)documentInteractionControllerViewForPreview:(UIDocumentInteractionController *)controller
{
    return self.view;
}

- (CGRect)documentInteractionControllerRectForPreview:(UIDocumentInteractionController*)controller
{
    return self.view.frame;
}


#pragma mark Resource Viewers
#pragma mark Image Viewer
- (void)openImgViewerForTask:(DownloadTask *)task
{
    NSString *resFile = [DownloadTask pathForResourceFile:task.resourceId];
    __weak DMTabBarController *weakSelf = self;
    [weakSelf _showImages:resFile forTask:task];
}

- (void)_showImages:(NSString *)image forTask:(DownloadTask *)task
{
    [[SDImageCache sharedImageCache] clearDisk];
    [[SDImageCache sharedImageCache] clearMemory];
    NSArray *images = [[NSArray alloc] initWithObjects:image, nil];
    ImageBrowserViewController *browser = [[ImageBrowserViewController alloc] initWithImages:images];
    [self presentViewController:browser animated:YES completion:nil];
}

#pragma mark Video Viewer
- (void)openVideoViewerForTask:(DownloadTask *)task
{
    NSString *resFile = [DownloadTask pathForResourceFile:task.resourceId];
    __weak DMTabBarController *weakSelf = self;
    [weakSelf _showVideo:resFile forTask:task];
}

- (void)_showVideo:(NSString *)videoFile forTask:(DownloadTask *)task
{
    VideoPlayerViewController *player = [[VideoPlayerViewController alloc] initWithVideoFile:videoFile title:task.title];
    [self presentViewController:player animated:YES completion:nil];
}


@end
