//
//  Zipper.m
//  CNNCTrain
//
//  Created by jerei on 14-8-25.
//
//

#import "Zipper.h"
#import "ZipArchive.h"

@implementation Zipper

+ (NSString *)decrypt:(NSString *)file
{
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForReadingAtPath:file];
    if (!fileHandle)
        return nil;
    
    NSString *decryptedFile = [file stringByAppendingString:@".decrypted"];
    [[NSFileManager defaultManager] removeItemAtPath:decryptedFile error:nil];
    [[[NSData alloc] init] writeToFile:decryptedFile atomically:YES];
    NSFileHandle *decryptedFileHandle = [NSFileHandle fileHandleForWritingAtPath:decryptedFile];
    [decryptedFileHandle seekToFileOffset:0];
    if (!decryptedFileHandle) {
        [fileHandle closeFile];
        return nil;
    }
    
    char *keyStr = ENCRYPT_KEY;
    uint lenOfKeyStr = strlen(keyStr);

    char *destChunkBytes;
    destChunkBytes = calloc(sizeof(char), ZIPPER_BUFF_SIZE);
    uint offset = 0, lenOfSrcChunk;
    
    NSData *srcChunk;
    while ((srcChunk = [fileHandle readDataOfLength:ZIPPER_BUFF_SIZE]) && (lenOfSrcChunk = srcChunk.length)) {
        char *srcChunkBytes = (char *)[srcChunk bytes];
        for (uint offsetInChunk = 0; offsetInChunk < lenOfSrcChunk; ++offsetInChunk, ++offset) {
            char key = *(keyStr + (offset % lenOfKeyStr));
            char srcByte = *(srcChunkBytes + offsetInChunk);
            char destByte = srcByte ^ key;
            char *pDestChunk = destChunkBytes + offsetInChunk;
            *pDestChunk = destByte;
        }
        
        NSData *destChunk = [NSData dataWithBytes:destChunkBytes length:lenOfSrcChunk];
        [decryptedFileHandle writeData:destChunk];
    }
    
    free(destChunkBytes);
    
    [fileHandle closeFile];
    [decryptedFileHandle closeFile];
    return decryptedFile;
}

+ (BOOL)unzip:(NSString *)zipFile toFolder:(NSString *)path
{
    // 创建目录，如果存在同名文件则删除
    BOOL isDir;
    if ([[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDir])
        [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
    [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    
    BOOL result = NO;
    ZipArchive* zip = [[ZipArchive alloc] init];
    if([zip UnzipOpenFile:zipFile]) {
        result = [zip UnzipFileTo:path overWrite:YES];
        [zip UnzipCloseFile];
    }
    return result;
}

+ (NSString *)unzipToDefaultFolder:(NSString *)zipFile
{
    NSString *defaultFolder = [zipFile stringByAppendingString:@".unzipped"];
    if ([Zipper unzip:zipFile toFolder:defaultFolder])
        return defaultFolder;
    else
        return nil;
}

@end
