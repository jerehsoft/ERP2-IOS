//
//  DownloadManager.h
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//
#import "Erp2.h"
#import <Foundation/Foundation.h>
#import "DownloadTask.h"

/*
 任务描述文件和资源文件都存储在Library/Cache/Download目录中，一个任务描述对应一个资源文件，如果资源文件不存在表示任务还没有开始
 任务描述文件的文件名即为资源id，扩展名为.task，文件中包含：任务标题title（即课程名），资源类型fileType（文件扩展名），资源大小bytesTotal
 资源文件存储时以资源id为名称，扩展名为资源类型
 
 如果资源文件大小小于描述文件中的资源大小，表示下载未完成
 每个任务只能有一个线程负责下载，同时进行的下载任务数量应该有限制
 */

typedef enum {
    TaskRepositoryNull,
    TaskRepositoryRunning,
    TaskRepositoryHistory
} TaskRepository;


@protocol DownloadManagerDelegate <NSObject>

@required
// 下载队列变化
- (void)queueChangedForTask:(DownloadTask *)task source:(TaskRepository)source destination:(TaskRepository)destination;
// 进度变化
- (void)progressChangedForTask:(DownloadTask *)task;
- (void)stateChangedForTask:(DownloadTask *)task;
@end


// 下载管理
@interface DownloadManager : NSObject

@property (nonatomic, readonly) NSOrderedSet *delegates;
// 站点的根目录，以协议名开头，去左右空白，不以/结尾
@property (nonatomic, copy) NSString *webRoot;

// 获取共享实例
+ (DownloadManager *)shared;

// 资源文件存储目录
+ (NSString *)pathForResources;

// 从存储中恢复，只有在应用启动时使用，不会触发任务队列变更通知
+ (void)restore;
// 持久化到存储中，应该在任务状态变化时调用
+ (void)persist;

// 清除指定任务列表
+ (void)clearRepository:(TaskRepository)repository;

// 开始一个任务，如果指定任务已经存在则直接返回该任务
+ (DownloadTask *)queueTaskForResourceId:(NSString *)resourceId title:(NSString *)title fileType:(NSString *)fileType extraData:(NSDictionary *)extraData;
+ (DownloadTask *)queueTaskForResourceId:(NSString *)resourceId title:(NSString *)title url:(NSString *)url fileType:(NSString *)fileType extraData:(NSDictionary *)extraData;

+ (void)registerDelegate:(id<DownloadManagerDelegate>)delegate;

// 开始任务
+ (BOOL)startTask:(DownloadTask *)task;
// 取消任务，并删除文件
+ (BOOL)cancelTask:(DownloadTask *)task;
// 暂停任务
+ (BOOL)pauseTask:(DownloadTask *)task;
// 如果任务未完成则继续任务
+ (BOOL)resumeTask:(DownloadTask *)task;

// 获取正在进行的任务
+ (NSArray *)copyOfRunningTasks;
// 获取历史下载任务的副本
+ (NSArray *)copyOfHistoryTasks;

// action，不包含/android及之前的部分
//+ (NSString *)urlForAction:(NSString *)action;
//// mp4资源包
//+ (NSString *)urlForVideoResource:(NSString *)resourceId;
//// pdf资源包
//+ (NSString *)urlForWordResource:(NSString *)resourceId;
//// pdf每一页对应的图片
//+ (NSString *)urlForImageResource:(NSString *)resourceId page:(uint)page;
+ (NSString *)urlForResource:(NSString *)row;

// 站点根目录
+ (NSString *)webRoot;
+ (void)setWebRoot:(NSString *)webRoot;

@end
