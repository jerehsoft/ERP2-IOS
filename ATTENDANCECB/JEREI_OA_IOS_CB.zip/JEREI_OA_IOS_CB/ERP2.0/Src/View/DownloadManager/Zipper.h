//
//  Zipper.h
//  CNNCTrain
//
//  Created by jerei on 14-8-25.
//
//

#import <Foundation/Foundation.h>

#define ENCRYPT_KEY "6^)(9-p35@%3#4S!4S0)$Y%%^&5(j.&^&o(*0)$Y%!#O@*GpG@=+@j.&6^)(0-=+\0"
#define ZIPPER_BUFF_SIZE (1024 * 10)

@interface Zipper : NSObject

// 解压缩文件
+ (BOOL)unzip:(NSString *)zipFile toFolder:(NSString *)path;

// 解压缩到默认文件夹，并返回文件夹路径
+ (NSString *)unzipToDefaultFolder:(NSString *)zipFile;

// 解密文件，并返回解密完成的临时文件路径（使用完成后应删除）
+ (NSString *)decrypt:(NSString *)file;

@end
