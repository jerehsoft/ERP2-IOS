//
//  UIUtils.m
//  CNNCTrain
//
//  Created by jerei on 14-8-27.
//
//

#import "UIUtils.h"

@implementation UIUtils

+ (void)toast:(NSString *)message duration:(double)duration
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *oldHud = [MBProgressHUD HUDForView:[UIApplication sharedApplication].keyWindow];
        if (oldHud) {
            @try {
                [oldHud hide:NO];
            }
            @catch (NSException *exception) {
            }
        }
        MBProgressHUD *hud = [[MBProgressHUD alloc] initWithWindow:[UIApplication sharedApplication].keyWindow];
        hud.mode = MBProgressHUDModeText;
        hud.labelFont = [UIFont systemFontOfSize:[UIFont systemFontSize]];
        hud.labelText = message;
        hud.removeFromSuperViewOnHide = YES;
        [[UIApplication sharedApplication].keyWindow addSubview:hud];
        
        [hud showAnimated:YES whileExecutingBlock:^{
            [NSThread sleepForTimeInterval:duration];
        }];
    });
}

+ (void)alert:(NSString *)title message:(NSString *)message
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[[UIAlertView alloc] initWithTitle:title
                                   message:message
                                  delegate:nil
                         cancelButtonTitle:@"OK"
                         otherButtonTitles:nil] show];
    });
}

@end
