//
//  DownloadManager.m
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//

#import "DownloadManager.h"
#import "ErpFormDataUtils.h"

@interface DownloadManager()
{
    // 进行中队列
    NSMutableDictionary *_taskQueueMap;
    // 已完成队列
    NSMutableDictionary *_taskHistoryMap;
    
    NSMutableOrderedSet *_delegates;
}
@end

@implementation DownloadManager {
    NSString *_archivePath;
}

#pragma mark SINGLETON
+ (DownloadManager *)shared
{
    static DownloadManager *__singleton = nil;
    @synchronized(self) {
        if (!__singleton) {
            __singleton = [[DownloadManager alloc] init];
        }
    }
    return __singleton;
}

+ (void)registerDelegate:(id<DownloadManagerDelegate>)delegate
{
    [((NSMutableOrderedSet *)[[DownloadManager shared] delegates]) addObject:delegate];
}

@synthesize delegates = _delegates;

#pragma mark PRIVATE
- (id)init
{
    //获得文件路径
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    _archivePath = [documentPath stringByAppendingPathComponent:@"downloadtasks.archiver"];
    if (self = [super init]) {
        //解归档
        //1. 从磁盘读取文件，生成NSData实例
        NSData *unarchiverData = [NSData dataWithContentsOfFile:_archivePath];
        //2. 根据Data实例创建和初始化解归档对象
        NSKeyedUnarchiver *unachiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:unarchiverData];
        //3. 解归档，根据key值访问
        _taskQueueMap = [unachiver decodeObjectForKey:@"taskQueue"];
        _taskHistoryMap = [unachiver decodeObjectForKey:@"taskHistory"];
        if(!_taskQueueMap) {
            _taskQueueMap = [NSMutableDictionary dictionaryWithCapacity:64];
        }
        if(!_taskHistoryMap) {
            _taskHistoryMap = [NSMutableDictionary dictionaryWithCapacity:64];
        }
        _delegates = [NSMutableOrderedSet orderedSetWithCapacity:3];
    }
    return self;
}

- (void)dealloc
{
    [self printDealloc];
    for (DownloadTask *task in [_taskQueueMap allValues]) {
        [self _unobserveTask:task];
    }
    for (DownloadTask *task in [_taskHistoryMap allValues]) {
        [self _unobserveTask:task];
    }
    [_delegates removeAllObjects];
    _delegates = nil;
    _taskQueueMap = nil;
    _taskHistoryMap = nil;
}

- (DownloadTask *)queueTaskForResourceId:(NSString *)resourceId title:(NSString *)title url:(NSString *)url fileType:(NSString *)fileType extraData:(NSDictionary *)extraData
{
    DownloadTask *task;
    BOOL addTask = NO;
    @synchronized(self) {
        // 先检查历史记录里是否存在任务
        task = [_taskHistoryMap valueForKey:resourceId];
        if (task) {
            NSLog(@"任务已存在于历史记录中: %@", task);
        }
        
        // 如果历史记录里没有则检查正在进行的队列
        if (!task) {
            task = [_taskQueueMap valueForKey:resourceId];
            if (task) {
                NSLog(@"任务已存在于下载队列中: %@", task);
            }
            if (!task) {
                NSLog(@"任务没有找到, resourceId = %@, 开始下载任务", resourceId);
                // 如果正在执行的队列中也没有则添加任务
                task = [[DownloadTask alloc] initWithResourceId:resourceId
                                                          title:title
                                                            url:url
                                                       fileType:fileType
                                                      extraData:extraData];
                addTask = YES;
                [self _unobserveTask:task];
                
                // 监视状态变化和下载进度
                [self _observeTask:task];
                // 启动线程下载
                [self startTask:task];
            }
        }
    }
    if (addTask) {
        // 避免死锁，在同步块之外添加任务
        [self _addTaskToQueue:task];
    }
    return task;
}


- (void)_observeTask:(DownloadTask *)task
{
    [self _unobserveTask:task];
    [task addObserver:self
           forKeyPath:@"state"
              options:NSKeyValueObservingOptionOld|NSKeyValueObservingOptionNew
              context:nil];
    [task addObserver:self
           forKeyPath:@"bytesDownloaded"
              options:NSKeyValueObservingOptionOld|NSKeyValueObservingOptionNew
              context:nil];
}

- (void)_unobserveTask:(DownloadTask *)task
{
    @try {
        [task removeObserver:self forKeyPath:@"state" context:nil];
        [task removeObserver:self forKeyPath:@"bytesDownloaded" context:nil];
    }
    @catch (NSException *exception) {
        NSLog(@"ex = %@", exception);
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    DownloadTask *task = (DownloadTask *)object;
    if ([keyPath isEqualToString:@"state"]) {
        // NSLog(@"state changed : %@", object);
        dispatch_async(dispatch_get_main_queue(), ^{
            for (id<DownloadManagerDelegate> delegate in _delegates)
                [delegate stateChangedForTask:task];
            [self archiveTaskQueue:_taskQueueMap taskHistory:_taskHistoryMap];
        });
        if (task.state == TaskDownDone) {
            __weak DownloadManager *weakSelf = self;
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf _moveTaskToHistory:task];
                [self archiveTaskQueue:_taskQueueMap taskHistory:_taskHistoryMap];
            });
        }
    }
    else if ([keyPath isEqualToString:@"bytesDownloaded"]) {
        // NSLog(@"progress changed : %f", task.progress);
        dispatch_async(dispatch_get_main_queue(), ^{
            for (id<DownloadManagerDelegate> delegate in _delegates)
                [delegate progressChangedForTask:task];
        });
    }
}

- (NSArray *)copyOfTasks:(BOOL)isHistory
{
    NSArray *tasks;
    @synchronized(self) {
        if (isHistory) {
            tasks = [_taskHistoryMap allValues];
        }
        else {
            tasks = [_taskQueueMap allValues];
        }
    }
    // 按任务创建时间倒序排列
    NSArray *sortedTasks = [tasks sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        double t1 = [obj1 taskTimestamp];
        double t2 = [obj2 taskTimestamp];
        return signbit(t1 - t2);
    }];
    return sortedTasks;
}

#pragma mark PUBLIC PROPERTIES
- (void)setWebRoot:(NSString *)webRoot
{
    _webRoot = [webRoot stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/ "]];
}

#pragma mark PRIVATE 队列管理
- (void)_addTaskToQueue:(DownloadTask *)task
{
    @synchronized(self) {
        // 如果重新下载已经完成的任务，需要从历史列表中移除
        [_taskHistoryMap removeObjectForKey:task.resourceId];
        [_taskQueueMap setValue:task forKey:task.resourceId];
    }
    
    dispatch_async((dispatch_get_main_queue()), ^{
        for (id<DownloadManagerDelegate> delegate in _delegates)
            [delegate queueChangedForTask:task
                                   source:TaskRepositoryNull
                              destination:TaskRepositoryRunning];
    });
}

- (void)_moveTaskToHistory:(DownloadTask *)task
{
    @synchronized(self) {
        [_taskQueueMap removeObjectForKey:task.resourceId];
        [_taskHistoryMap setObject:task forKey:task.resourceId];
    }
    
    dispatch_async((dispatch_get_main_queue()), ^{
        for (id<DownloadManagerDelegate> delegate in _delegates)
            [delegate queueChangedForTask:task
                                   source:TaskRepositoryRunning
                              destination:TaskRepositoryHistory];
    });
}
- (void)_removeTaskFromQueue:(DownloadTask *)task
{
    TaskRepository src;
    @synchronized(self) {
        if ([_taskQueueMap valueForKey:task.resourceId]) {
            src = TaskRepositoryRunning;
            [_taskQueueMap removeObjectForKey:task.resourceId];
        }
        else if ([_taskHistoryMap valueForKey:task.resourceId]) {
            src = TaskRepositoryHistory;
            [_taskHistoryMap removeObjectForKey:task.resourceId];
        }
        else {
            src = TaskRepositoryNull;
            NSLog(@"Task not found");
        }
    }
    
    dispatch_async((dispatch_get_main_queue()), ^{
        for (id<DownloadManagerDelegate> delegate in _delegates)
            [delegate queueChangedForTask:task
                                   source:src
                              destination:TaskRepositoryNull];
    });
}

- (void)clearRepository:(TaskRepository)repository
{
    NSArray *_removedTasks;
    
    @synchronized(self) {
        if (repository == TaskRepositoryHistory) {
            _removedTasks = [_taskHistoryMap allValues];
            [_taskHistoryMap removeAllObjects];
        }
        else if (repository == TaskRepositoryRunning) {
            _removedTasks = [_taskQueueMap allValues];
            [_taskQueueMap removeAllObjects];
        }
        else {
            NSLog(@"未知的任务列表");
            _removedTasks = @[];
        }
        for (DownloadTask *task in _removedTasks) {
            [self _unobserveTask:task];
        }
        [self archiveTaskQueue:_taskQueueMap taskHistory:_taskHistoryMap];
    }
    
    dispatch_async((dispatch_get_main_queue()), ^{
        for (DownloadTask *task in [_removedTasks reverseObjectEnumerator]) {
            [task cancel];
            for (id<DownloadManagerDelegate> delegate in _delegates) {
                [delegate queueChangedForTask:task
                                       source:repository
                                  destination:TaskRepositoryNull];
            }
        }
    });
}

-(void)archiveTaskQueue:(NSMutableDictionary *)taskQueue taskHistory:(NSMutableDictionary *)taskHistory {
    //归档
    //1. 使用NSData存放归档数据
    NSMutableData *archiverData = [NSMutableData data];
    //2. 创建归档对象
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:archiverData];
    //3. 添加归档内容 （设置键值对）
    [archiver encodeObject:taskQueue forKey:@"taskQueue"];
    [archiver encodeObject:taskHistory forKey:@"taskHistory"];
    //4. 完成归档
    [archiver finishEncoding];
    //5. 将归档的信息存储到磁盘上
    if ([archiverData writeToFile:_archivePath atomically:YES]) {
        NSLog(@"archiver success");
    }
}


#pragma mark PRIVATE 任务控制
- (BOOL)startTask:(DownloadTask *)task
{
    return [task start];
}
- (BOOL)pauseTask:(DownloadTask *)task
{
    return [task pause];
}
- (BOOL)cancelTask:(DownloadTask *)task
{
    BOOL cancelled = [task cancel];
    if (cancelled) {
        [self _removeTaskFromQueue:task];
    }
    return cancelled;
}
- (BOOL)resumeTask:(DownloadTask *)task
{
    return [task resume];
}

#pragma mark PRIVATE 状态保存与恢复
- (void)restore
{
    // 遍历下载文件夹，获取任务信息
    NSString *resFolder = [DownloadManager pathForResources];
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *resFiles = [fm subpathsAtPath:resFolder];
    
    // 恢复任务状态
    NSMutableArray *tasks = [NSMutableArray arrayWithCapacity:16];
    for (NSString *file in resFiles) {
        if ([file hasSuffix:@".task"]) {
            NSString *resourceId = [file substringToIndex:file.length - 5];
            DownloadTask *task = [[DownloadTask alloc] initWithDescriptorFileOfResourceId:resourceId];
            [tasks addObject:task];
        }
    }
    // 按创建时间倒排任务
    NSArray *sortedTasks = [tasks sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        DownloadTask *t1 = (DownloadTask *)obj1;
        DownloadTask *t2 = (DownloadTask *)obj2;
        return (NSComparisonResult)signbit(t1.taskTimestamp - t2.taskTimestamp);
    }];
    
    // 添加任务到队列
    for (DownloadTask *task in sortedTasks) {
        if (task.state == TaskDownDone) {
            [_taskHistoryMap setValue:task forKey:task.resourceId];
        }
        else {
            [_taskQueueMap setValue:task forKey:task.resourceId];
        }
    }
}


#pragma mark PUBLIC 任务状态
+ (NSArray *)copyOfHistoryTasks
{
    return [[DownloadManager shared] copyOfTasks:YES];
}
+ (NSArray *)copyOfRunningTasks
{
    return [[DownloadManager shared] copyOfTasks:NO];
}

#pragma mark PUBLIC 工具方法
+ (NSString *)pathForResources
{
    static NSString *path = nil;
    if (!path) {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(/*NSCachesDirectory*/NSDocumentDirectory, NSUserDomainMask, YES);
        path = [paths[0] stringByAppendingPathComponent:@"DMSDownload"];
        // 准备目录
        BOOL createDir = YES;
        BOOL isDir;
        if ([[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDir]) {
            // 如果指定路径是个文件则删除
            if (!isDir) {
                [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
            }
            else {
                createDir = NO;
            }
        }
        
        if (createDir) {
            NSError *err;
            if (![[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:&err]) {
                NSLog(@"无法创建资源文件目录%@ : %@", path, [err localizedDescription]);
            }
        }
        NSLog(@"资源文件目录: %@", path);
    }
    return path;
}

#pragma mark PUBLIC 任务控制
+ (DownloadTask *)queueTaskForResourceId:(NSString *)resourceId title:(NSString *)title fileType:(NSString *)fileType extraData:(NSDictionary *)extraData
{
    return [[DownloadManager shared] queueTaskForResourceId:resourceId
                                                      title:title
                                                        url:nil
                                                   fileType:fileType
                                                  extraData:extraData];
}

+ (DownloadTask *)queueTaskForResourceId:(NSString *)resourceId title:(NSString *)title url:(NSString *)url fileType:(NSString *)fileType extraData:(NSDictionary *)extraData;
{
    return [[DownloadManager shared] queueTaskForResourceId:resourceId
                                                      title:title
                                                        url:url
                                                   fileType:fileType
                                                  extraData:extraData];
}

+ (BOOL)startTask:(DownloadTask *)task
{
    return [[DownloadManager shared] startTask:task];
}

+ (BOOL)pauseTask:(DownloadTask *)task
{
    return [[DownloadManager shared] pauseTask:task];
}

+ (BOOL)cancelTask:(DownloadTask *)task
{
    return [[DownloadManager shared] cancelTask:task];
}

+ (BOOL)resumeTask:(DownloadTask *)task
{
    return [[DownloadManager shared] resumeTask:task];
}

#pragma mark PUBLIC 状态保存与恢复
+ (void)restore
{
    [[DownloadManager shared] restore];
}

+ (void)persist
{
    NSLog(@"未使用");
}

+ (void)clearRepository:(TaskRepository)repository
{
    [[DownloadManager shared] clearRepository:repository];
}

#pragma mark PUBLIC 地址拼接
+ (NSString *)webRoot
{
    return [DownloadManager shared].webRoot;
}
+ (void)setWebRoot:(NSString *)webRoot
{
    [DownloadManager shared].webRoot = webRoot;
}


//+ (NSString *)urlForAction:(NSString *)action
//{
//    if ([action hasPrefix:@"/"])
//        action = [action stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/"]];
//    NSString *url = [NSString stringWithFormat:@"%@/android/%@", [DownloadManager webRoot], action];
//    return url;
//}
//+ (NSString *)urlForImageResource:(NSString *)resourceId page:(uint)page
//{
//    NSString *url = [NSString stringWithFormat:@"%@/uploadfiles/book/%@/%zd.png", [DownloadManager webRoot], resourceId, page];
//    return url;
//}
//+ (NSString *)urlForVideoResource:(NSString *)resourceId
//{
//    NSString *url = [NSString stringWithFormat:@"%@/mobileResource/video/%@", [DownloadManager webRoot], resourceId];
//    return url;
//}
//+ (NSString *)urlForWordResource:(NSString *)resourceId
//{
//    NSString *url = [NSString stringWithFormat:@"%@/mobileResource/word/%@", [DownloadManager webRoot], resourceId];
//    return url;
//}
+ (NSString *)urlForResource:(NSString *)resourceId
{
    NSDictionary *row = [ErpFormDataUtils getDataForKey:resourceId];
    NSString *url = [NSString stringWithFormat:@"%@%@%@%@",ERP_MAIN_SITE_URL,ERP_MAIN_SITE_SERVLET_ADDR,[row valueForKey:@"pathName"],[row valueForKey:@"fileName"]];
    //    [ErpFormDataUtils removeDataForKey:resourceId];
    return url;
}
@end
