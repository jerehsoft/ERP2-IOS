//
//  DownloadTask.h
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//

#import <Foundation/Foundation.h>
#import "Downloader.h"

// 任务状态
typedef enum {
    TaskUnInited = -2,  // 任务创建，未获取资源大小
    TaskPending = -1,   // 正在获取资源大小
    TaskDownDone = 0,       // 任务完成
    TaskRunning = 1,    // 正在下载
    TaskPaused = 2,     // 已获取资源大小，暂停
    TaskFailed = 3      // 已获取资源大小，任务失败（获取资源大小时失败会返回到Uninited）
} TaskState;

// 下载任务
@interface DownloadTask : NSObject<DownloadDelegate, NSCoding>

// 资源id
@property (nonatomic, readonly, copy) NSString *resourceId;
// 任务标题
@property (nonatomic, readonly, copy) NSString *title;
// 下载地址
@property (nonatomic, readonly, copy) NSString *downloadUrl;
// 文件类型（小写），如果有则必定以.开头，否则应该是空字符串
@property (nonatomic, readonly, copy) NSString *fileType;
// 资源大小
@property (nonatomic, readonly) unsigned long bytesTotal;
// 已下载资源大小（可观察）
@property (nonatomic, readonly) unsigned long bytesDownloaded;
// 任务开始时间（即描述文件创建时间）
@property (nonatomic, readonly) double taskTimestamp;

// 任务附加属性
@property (nonatomic, readonly, copy) NSDictionary *extraData;

// 下载进度
@property (nonatomic, readonly) float progress;

// 任务状态（可观察）
@property (nonatomic, readonly) TaskState state;


// 开始
- (BOOL)start;
// 从pause状态继续
- (BOOL)resume;
// 暂停
- (BOOL)pause;
// 取消并删除资源
- (BOOL)cancel;


// 从描述文件初始化任务，描述文件名 = resourceId + ".task"
- (instancetype)initWithDescriptorFileOfResourceId:(NSString *)resourceId;
// 新任务
- (instancetype)initWithResourceId:(NSString *)resourceId title:(NSString *)title fileType:(NSString *)fileType extraData:(NSDictionary *)extraData;
- (instancetype)initWithResourceId:(NSString *)resourceId title:(NSString *)title url:(NSString *)url fileType:(NSString *)fileType extraData:(NSDictionary *)extraData;
// 描述文件名
+ (NSString *)descriptorFileNameForResourceId:(NSString *)resourceId;

// 资源文件路径
+ (NSString *)pathForResourceFile:(NSString *)resourceId;
// 描述文件路径
+ (NSString *)pathForDescriptorFile:(NSString *)resourceId;

@end

