//
//  UIUtils.h
//  CNNCTrain
//
//  Created by jerei on 14-8-27.
//
//

#import <Foundation/Foundation.h>
#import "MBProgressHUD.h"

@interface UIUtils : NSObject

+ (void)toast:(NSString *)message duration:(double)duration;

+ (void)alert:(NSString *)title message:(NSString *)message;
@end
