//
//  ImageBrowserViewController.m
//  CNNCTrain
//
//  Created by jerei on 14-8-25.
//
//

#import "ImageBrowserViewController.h"
#import "MBProgressHUD.h"
#import "ActionManager.h"
#import "DownloadListBaseViewController.h"
#import "UIUtils.h"

#define BROWSER_TITLE_LBL_TAG 12731
#define BROWSER_TIMER_LBL_TAG 12821

@interface ImageBrowserViewController ()<UIAlertViewDelegate>
{
    NSArray *_images;
    CXBrowserNavBarView *navBarView;
    CXBrowserToolBarView *toolBarView;
}
@end

@implementation ImageBrowserViewController

- (instancetype)initWithImages:(NSArray *)images
{
    if (self = [super initWithDataSource:self delegate:self]) {
        NSMutableArray *cxImages = [[NSMutableArray alloc] initWithCapacity:images.count];
        for (UIImage *imageFile in images) {
            CXPhoto *photo;
            photo = [[CXPhoto alloc] initWithImage:imageFile];
            [cxImages addObject:photo];
        }
        _images = cxImages;
    }
    return self;
}

- (instancetype)initWithSingleImage:(UIImage *)image
{
    if (self = [super initWithDataSource:self delegate:self]) {
        NSMutableArray *cxImages = [[NSMutableArray alloc] initWithCapacity:1];
        CXPhoto *photo;
        photo = [[CXPhoto alloc] initWithImage:image];
        [cxImages addObject:photo];
        _images = cxImages;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor blackColor]];
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.view.window.windowLevel = UIWindowLevelAlert;
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.view.window.windowLevel = UIWindowLevelNormal;
}

- (void)onTimer:(NSTimer *)timer
{}

#pragma mark DataSource
- (NSUInteger)numberOfPhotosInPhotoBrowser:(CXPhotoBrowser *)photoBrowser
{
    return [_images count];
}

- (id<CXPhotoProtocol>)photoBrowser:(CXPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index
{
    if (index < _images.count)
        return [_images objectAtIndex:index];
    return nil;
}

- (CXBrowserNavBarView *)browserNavigationBarViewOfOfPhotoBrowser:(CXPhotoBrowser *)photoBrowser withSize:(CGSize)size
{
    CGRect frame;
    frame.origin = CGPointZero;
    frame.size = size;
    if (!navBarView)
    {
        navBarView = [[CXBrowserNavBarView alloc] initWithFrame:frame];
        [navBarView setBackgroundColor:[UIColor clearColor]];
        
        UIView *bkgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        [bkgView setBackgroundColor:[UIColor blackColor]];
        bkgView.alpha = 0.7;
        bkgView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [navBarView addSubview:bkgView];
        
        UIButton *doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [doneButton setTitle:NSLocalizedString(@"关闭", @"关闭") forState:UIControlStateNormal];
        [doneButton setFrame:CGRectMake(10, (size.height - 30) / 2, 50, 30)];
        [doneButton setBackgroundColor:[UIColor clearColor]];
        [doneButton addTarget:self action:@selector(quitBrowser:) forControlEvents:UIControlEventTouchUpInside];
        doneButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin;
        [navBarView addSubview:doneButton];
        
        UILabel *titleLabel = [[UILabel alloc] init];
        [titleLabel setFrame:CGRectMake((size.width - 80) / 2, (size.height - 40) / 2, 80, 40)];
        [titleLabel setBackgroundColor:[UIColor clearColor]];
        [titleLabel setCenter:navBarView.center];
        [titleLabel setTextAlignment:NSTextAlignmentCenter];
        [titleLabel setFont:[UIFont boldSystemFontOfSize:[UIFont labelFontSize]]];
        [titleLabel setTextColor:[UIColor whiteColor]];
        titleLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        [titleLabel setTag:BROWSER_TITLE_LBL_TAG];
        [navBarView addSubview:titleLabel];
    }
    
    return navBarView;
}

#pragma mark - CXPhotoBrowserDelegate
- (void)photoBrowser:(CXPhotoBrowser *)photoBrowser didChangedToPageAtIndex:(NSUInteger)index
{
    UILabel *titleLabel = (UILabel *)[navBarView viewWithTag:BROWSER_TITLE_LBL_TAG];
    if (titleLabel)
    {
        if (_images.count > 1) {
            titleLabel.text = [NSString stringWithFormat:@"%@ / %@", [NSNumber numberWithLong:index+1], [NSNumber numberWithLong:photoBrowser.photoCount]];
        } else {
            titleLabel.text = @"";
        }
    }
}

- (BOOL)supportReload
{
    return YES;
}

- (void)quitBrowser:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if ([title isEqualToString:@"重试"]) {
        [self quitBrowser:nil];
    } else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void)dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [super dismissViewControllerAnimated:flag completion:completion];
        // 通知上级视图清理资源
        [[NSNotificationCenter defaultCenter] postNotificationName:BROWSER_DISMISSING_NOTIFICATION object:self];
    });
}
@end
