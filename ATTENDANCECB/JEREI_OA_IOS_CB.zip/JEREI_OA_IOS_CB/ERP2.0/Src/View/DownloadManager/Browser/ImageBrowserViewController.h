//
//  ImageBrowserViewController.h
//  CNNCTrain
//
//  Created by jerei on 14-8-25.
//
//

#import "CXPhotoBrowser.h"

@interface ImageBrowserViewController : CXPhotoBrowser<CXPhotoBrowserDataSource, CXPhotoBrowserDelegate>

- (instancetype)initWithImages:(NSArray *)images;
- (instancetype)initWithSingleImage:(UIImage *)image;

@end
