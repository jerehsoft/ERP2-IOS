//
//  CXBrowserToolBarView.h
//  CXPhotoBrowserDemo
//
//  Created by ChrisXu on 13/4/23.
//  Copyright (c) 2013年 ChrisXu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CXPhotoBrowser;

@interface CXBrowserToolBarView : UIView

@property (nonatomic, assign, readonly) CXPhotoBrowser *photoBrowser;

@end
