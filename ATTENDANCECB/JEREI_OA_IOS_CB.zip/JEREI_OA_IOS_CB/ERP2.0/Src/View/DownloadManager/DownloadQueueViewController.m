//
//  DownloadQueueViewController.m
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//

#import "DownloadQueueViewController.h"
#import "TaskCell.h"

@interface DownloadQueueViewController ()
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@end

@implementation DownloadQueueViewController

- (NSArray *)copyOfTasks
{
    return [DownloadManager copyOfRunningTasks];
}

- (TaskRepository)taskRepository
{
    return TaskRepositoryRunning;
}

@end
