//
//  DownloadHistoryViewController.h
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//

#import <UIKit/UIKit.h>
#import "DownloadListBaseViewController.h"

@interface DownloadHistoryViewController : DownloadListBaseViewController

@end
