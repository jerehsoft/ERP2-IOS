//
//  Downloader.m
//  CNNCTrain
//
//  Created by jerei on 14-8-21.
//
//

#import "Downloader.h"


@interface Downloader()
{
    __weak id<DownloadDelegate> _delegate;
    NSURLConnection *_conn;
    BOOL _finished;
}
@end

@implementation Downloader

- (instancetype)initWithURL:(NSString *)url startFrom:(unsigned long)startFrom delegate:(id<DownloadDelegate>)delegate
{
    if (self = [super init]) {
        _delegate = delegate;
        
        NSLog(@"new downloader -> %@", url);
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:url]
                                                                    cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                                                timeoutInterval:10];
        NSString *dataRange = [NSString stringWithFormat:@"bytes=%zd-", startFrom];
        [request setValue:dataRange forHTTPHeaderField:@"Range"];
        _conn = [[NSURLConnection alloc] initWithRequest:request
                                                delegate:self
                                        startImmediately:NO];
        if (!_conn) {
            NSLog(@"无法创建连接");
            return nil;
        }
        // 连接必须从主线程发起，否则无效
        // http://www.cocoachina.com/bbs/simple/?t2745.html
        __weak NSURLConnection *weakConn = _conn;
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakConn start];
        });
    }
    return self;
}

- (void)dealloc
{
    [self cancel];
}

- (void)cancel
{
    _delegate = nil;
    [_conn cancel];
    _conn = nil;
}

#pragma mark Connection Delegates
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    [_delegate downloader:self failedWithMessage:[error localizedDescription]];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [_delegate downloader:self dataReceived:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    [_delegate downloader:self done:[NSDate date]];
    _finished = YES;
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSHTTPURLResponse *resp = (NSHTTPURLResponse *)response;
    long statusCode = [resp statusCode];
    if (statusCode == 200 || statusCode == 206) {
        NSDictionary *headers = [resp allHeaderFields];
        [_delegate downloader:self headerReceived:headers];
    }
    else {
        [_delegate downloader:self failedWithMessage:@"未找到资源"];
    }
}

- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    [_delegate downloader:self startedOn:[NSDate date]];
    return request;
}
@end
