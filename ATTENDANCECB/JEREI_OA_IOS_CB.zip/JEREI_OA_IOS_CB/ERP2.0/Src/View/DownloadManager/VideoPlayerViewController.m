//
//  VideoPlayerViewController.m
//  CNNCTrain
//
//  Created by jerei on 14-8-26.
//
//

#import "VideoPlayerViewController.h"
#import "MBProgressHUD.h"
#import "ActionManager.h"
#import "DownloadListBaseViewController.h"
#import "JSUIUtils.h"
#import <MediaPlayer/MediaPlayer.h>

@interface VideoPlayerViewController ()
{
    NSString *_title;
    NSString *_videoFile;
    
    MPMoviePlaybackState _playbackState;
    MPMoviePlayerController *_player;
    
    UIView *_navBar;
}

@end

@implementation VideoPlayerViewController{
    NSTimer *_timer;
    int timeSpend;
}

- (instancetype)initWithVideoFile:(NSString *)videoFile title:(NSString *)title 
{
    if (self = [super init]) {
        _title = title;
        _videoFile = videoFile;
        _playbackState = -1;
    }
    return self;
}

- (void)dealloc
{
    [_player stop];
    _player = nil;
    _navBar = nil;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.view.window.windowLevel = UIWindowLevelAlert;
    if (![ObjectUtils isNilOrNull:_bookId] && ![_bookId isEqualToString:@""]) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
    }
}

-(void)updateTimer {
    timeSpend ++;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.view.window.windowLevel = UIWindowLevelNormal;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor blackColor]];
    
    _navBar = [self navBarViewOfSize:CGSizeMake(self.view.bounds.size.width, 50)];
    [self.view addSubview:_navBar];
    
    NSURL *url = [NSURL fileURLWithPath:_videoFile isDirectory:NO];
    _player = [[MPMoviePlayerController alloc] initWithContentURL:url];
    _player.scalingMode = MPMovieScalingModeAspectFit;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(playbackStateChanged:)
                                                 name:MPMoviePlayerPlaybackStateDidChangeNotification
                                               object:_player];
    
    _player.view.frame = CGRectMake(0, 40, self.view.bounds.size.width, self.view.bounds.size.height - 40);
    _player.view.contentMode = UIViewContentModeScaleAspectFit;
    _player.view.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    [self.view addSubview:_player.view];
    [_player play];

}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (UIView *)navBarViewOfSize:(CGSize)size
{
    CGRect frame;
    frame.origin = CGPointZero;
    frame.size = size;
    UIView *navBarView = [[UIView alloc] initWithFrame:frame];
    navBarView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [navBarView setBackgroundColor:[UIColor clearColor]];
    
    UIView *bkgView = [[UIView alloc] initWithFrame:CGRectMake( 0, 0, size.width, size.height)];
    [bkgView setBackgroundColor:[UIColor blackColor]];
    bkgView.alpha = 0.7;
    bkgView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    [navBarView addSubview:bkgView];
    
    UIButton *doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [doneButton setTitle:NSLocalizedString(@"关闭", @"关闭") forState:UIControlStateNormal];
    [doneButton setFrame:CGRectMake(10, (size.height - 30) / 2, 50, 30)];
    [doneButton setBackgroundColor:[UIColor clearColor]];
    [doneButton addTarget:self action:@selector(quitBrowser:) forControlEvents:UIControlEventTouchUpInside];
    doneButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin;
    [navBarView addSubview:doneButton];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    [titleLabel setFrame:CGRectMake((size.width - 140) / 2, (size.height - 30) / 2, 140, 30)];
    [titleLabel setCenter:navBarView.center];
    [titleLabel setTextAlignment:NSTextAlignmentCenter];
    [titleLabel setFont:[UIFont boldSystemFontOfSize:[UIFont labelFontSize]]];
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
//    [titleLabel setText:_title];
    [titleLabel setText:@""];
    titleLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    [titleLabel setTag:1];
    [navBarView addSubview:titleLabel];
    
    return navBarView;
}

- (void)playbackStateChanged:(NSNotification *)notification
{
    _playbackState = _player.playbackState;
}



- (void)quitBrowser:(id)sender
{
    [_player pause];
    if (![ObjectUtils isNilOrNull:_bookId] && ![_bookId isEqualToString:@""]) {
        [JSUIUtils alertOKCancel:@"退出并上传阅读时间?" withTitle:@"阅读时间上传" buttonBlock:^(BOOL isCancel) {
            if (!isCancel) {
                [_timer invalidate];
                _timer = nil;
                [self submitStudyTimeComplete:^{
                    [JSUIUtils alert:@"提交成功" withTitle:@"温馨提示" buttonBlock:^(NSString *buttonTitle) {
                        [self dismissViewControllerAnimated:YES completion:nil];
                    }];
                }];
            }
        }];
    } else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}
-(void)submitStudyTimeComplete:(void(^)())complete {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view.window animated:YES];
    [hud setLabelText:@"正在提交,请稍候···"];
    [[ERPWebRequest mainSiteRequest] requestDataWithRelativeURI: @"train/web/study/saveBookStudyTime.action"
                                                     withMethod:@"POST"
                                                     withParams:@{@"bookId":_bookId,
                                                                  @"studyTime" : @(timeSpend),
                                                                  @"suggestTime" : @0,
                                                                  @"currentPage" : @0,
                                                                  @"totalPage" : @0}
                                                    withHeaders:nil
                                                 successHandler:^(NSDictionary *responseData) {
                                                     [hud hide:YES];
                                                     complete();
                                                 }
                                                   errorHandler:^(MKNetworkOperation *completedOperation, NSError *error) {
                                                       NSLog(@"error : %@",[error localizedFailureReason]);
                                                       [hud hide:YES];
                                                       [JSUIUtils alert:@"提交失败,请稍后再试" withTitle:@"网络异常"];
                                                   }];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if ([title isEqualToString:@"重试"]) {
        [self quitBrowser:nil];
    }
    else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


- (void)dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion
{
    [super dismissViewControllerAnimated:flag completion:completion];
    // 通知上级视图清理资源
    [[NSNotificationCenter defaultCenter] postNotificationName:BROWSER_DISMISSING_NOTIFICATION object:self];
}

@end
