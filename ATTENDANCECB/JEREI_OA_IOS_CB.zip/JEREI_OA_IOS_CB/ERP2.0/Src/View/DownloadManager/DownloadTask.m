//
//  DownloadTask.m
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//

#import "DownloadTask.h"
#import "DownloadManager.h"

// 暂存数据量限制
#define BUFF_FLUSH_THRESHOLD (200 * 1024)

@interface DownloadTask()
{
    id _threadLock;
    Downloader *_downloader;
    // 用来启动downloader的线程，downloader被cancel时结束
    NSThread *_downloadThread;
    
    // 任务的附加数据
    NSDictionary *_extraData;
    
    // 暂存接收到的数据，使用时初始化
    NSMutableData *_buff;
}
@end

@implementation DownloadTask

#pragma mark Properties
@synthesize resourceId = _resourceId;
@synthesize title = _title;
@synthesize fileType = _fileType;
@synthesize bytesTotal = _bytesTotal;
@synthesize bytesDownloaded = _bytesDownloaded;
@synthesize progress = _progress;
@synthesize state = _state;
@synthesize extraData = _extraData;

#pragma mark 编码 对对象属性进行编码的处理
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:_resourceId forKey:@"resourceId"];
    [aCoder encodeObject:_title forKey:@"title"];
    [aCoder encodeObject:_downloadUrl forKey:@"downloadUrl"];
    [aCoder encodeObject:_fileType forKey:@"fileType"];
    [aCoder encodeInteger:_bytesTotal forKey:@"bytesTotal"];
    [aCoder encodeInteger:_bytesDownloaded forKey:@"bytesDownloaded"];
    [aCoder encodeDouble:_taskTimestamp forKey:@"taskTimestamp"];
    [aCoder encodeObject:_extraData forKey:@"extraData"];
    [aCoder encodeDouble:_progress forKey:@"progress"];
    [aCoder encodeInteger:_state forKey:@"state"];
}

#pragma mark 解码 解码归档数据来初始化对象
- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init]) {
        _resourceId = [aDecoder decodeObjectForKey:@"resourceId"];
        _title = [aDecoder decodeObjectForKey:@"title"];
        _downloadUrl = [aDecoder decodeObjectForKey:@"downloadUrl"];
        _fileType = [aDecoder decodeObjectForKey:@"fileType"];
        _bytesTotal = [aDecoder decodeIntegerForKey:@"bytesTotal"];
        _bytesDownloaded = [aDecoder decodeIntegerForKey:@"bytesDownloaded"];
        _taskTimestamp = [aDecoder decodeDoubleForKey:@"taskTimestamp"];
        _extraData = [aDecoder decodeObjectForKey:@"extraData"];
        _progress = [aDecoder decodeDoubleForKey:@"progress"];
        switch ([aDecoder decodeIntegerForKey:@"state"]) {
            case -2:
                _state = TaskUnInited;
                break;
            case -1:
                _state = TaskPending;
                break;
            case 0:
                _state = TaskDownDone;
                break;
            case 1:
                _state = TaskRunning;
                break;
            case 2:
                _state = TaskPaused;
                break;
            case 3:
                _state = TaskFailed;
                break;
        }
    }
    return self;
}

- (float)progress
{
    return _bytesTotal ? 1.0f * _bytesDownloaded / _bytesTotal : 0.0f;
}

#pragma mark Setters for KVO
- (void)setState:(TaskState)state
{
    NSLog(@"状态变化 %@ -> %@", [self _stringForState:_state], [self _stringForState:state]);
    _state = state;
}

- (void)setBytesDownloaded:(unsigned long)bytesDownloaded
{
    _bytesDownloaded = bytesDownloaded;
}

// 在调用bytesDownloaded的setter之后调用，保证state变化滞后于progress
- (void)_syncFinishState
{
    if (_bytesDownloaded >= _bytesTotal && _bytesTotal) {
        [self downloader:_downloader done:[NSDate date]];
    }
}

#pragma mark State managing
- (NSException *)_exceptionWithDescription:(NSString *)description
{
    NSException *ex = [NSException exceptionWithName:description
                                              reason:description
                                            userInfo:@{
                                                       NSLocalizedDescriptionKey : description,
                                                       NSLocalizedFailureReasonErrorKey : description
                                                       }];
    return ex;
}
- (void)_breakOnInvalidStateChange:(NSString *)message
{
    @throw [self _exceptionWithDescription:message];
}
- (NSString *)_stringForState:(TaskState)state
{
    NSDictionary *states = @{
                             @"-2" : @"TaskUnInited",
                             @"-1" : @"TaskPending",
                             @"0" : @"TaskDone",
                             @"1" : @"TaskRunning",
                             @"2" : @"TaskPaused",
                             @"3" : @"TaskFailed",
                             };
    return states[[@(state) description]];
}

- (BOOL)_updateState:(TaskState)state
{
    @synchronized(self) {
        if (_state != state) {
            // 检查状态转换
            if (_state == TaskUnInited) {
                if (state != TaskPending) {
                    // pending -> 正在请求文件大小
                    [self _breakOnInvalidStateChange:@"uninited状态只能转换为pending"];
                }
            }
            else if (_state == TaskPending) {
                if (state != TaskRunning && state != TaskUnInited) {
                    // running -> 成功获取到文件大小，开始下载
                    // uninited -> 无法获取文件大小，退回初始状态
                    [self _breakOnInvalidStateChange:@"pending状态只能转换为running或uninited"];
                }
            }
            else if (_state == TaskPaused) {
                if (state != TaskRunning) {
                    // running -> 恢复运行
                    //[self _breakOnInvalidStateChange:@"paused状态只能转换为running"];
                }
            }
            else if (_state == TaskRunning) {
                if (state != TaskPaused && state != TaskDownDone && state != TaskFailed) {
                    // paused -> 暂停
                    // done -> 下载完成
                    // failed -> 下载失败
                    [self _breakOnInvalidStateChange:@"running状态只能转换为paused,done或failed"];
                }
            }
            else if (_state == TaskFailed) {
                if (state != TaskRunning) {
                    // running -> 恢复运行
                    [self _breakOnInvalidStateChange:@"failed状态只能转换为running"];
                }
            }
            else {
                [self _breakOnInvalidStateChange:[NSString stringWithFormat:@"未知的目标任务状态:%d", state]];
            }
            self.state = state;
            
            // 取消下载线程
            if (state == TaskDownDone || state == TaskUnInited || state == TaskFailed || state == TaskPaused) {
                [self cancelDownloadThread];
                [_downloader cancel];
            }
            
            // 只要状态变化为Uninitied以外的状态，都做记录
            [self saveToDescriptorFile];
        }
    }
    return YES;
}

- (void)cancelDownloadThread
{
    @synchronized(_threadLock) {
        [_downloadThread cancel];
    }
}


- (BOOL)start
{
    @try{
    @synchronized(_threadLock) {
        if (_downloadThread) {
            return NO;
        }
        else {
            _downloadThread = [[NSThread alloc] initWithTarget:self selector:@selector(_download) object:nil];
            [_downloadThread setName:[NSString stringWithFormat:@"Task-%@", self.resourceId]];
            [_downloadThread start];
        }
        return YES;
    }
    }@catch(NSException *e){
        NSLog(@"%@",[e reason]);
        return NO;
    }
}

- (BOOL)cancel
{
    BOOL result = YES;
    if (self.state == TaskRunning)
        result = [self _updateState:TaskPaused];
    else if(self.state == TaskPending)
        result = [self _updateState:TaskUnInited];
    else
        [self cancelDownloadThread];
    // 删除记录
    if (result) {
        NSString *resFile = [DownloadTask pathForResourceFile:self.resourceId];
        NSString *descFile = [DownloadTask pathForDescriptorFile:self.resourceId];
        [[NSFileManager defaultManager] removeItemAtPath:resFile error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:descFile error:nil];
    }
    return result;
}

- (BOOL)pause
{
    BOOL result = [self _updateState:TaskPaused];
    return result;
}

- (BOOL)resume
{
    return [self start];
}


#pragma mark Threading
- (void)_download
{
    // 标记任务开始
    if (_downloader) {
        NSLog(@"downloader已存在，应检查是否状态冲突");
        [_downloader cancel];
        _downloader = nil;
    }
    
    _downloader = [[Downloader alloc] initWithURL:self.downloadUrl?self.downloadUrl:[self remoteUrlForResource] startFrom:_bytesDownloaded delegate:self];

    // 必须保证在更新任务状态之前先检查线程的状态，如果已经取消，则跳过后续所有步骤，以快速响应请求
    while (1) {
        [NSThread sleepForTimeInterval:.05];
        if ([_downloadThread isCancelled])
            break;
    }
    _downloadThread = nil;
    NSLog(@"结束下载线程 %@", [[NSThread currentThread] name]);
}

#pragma mark Downloader Delegate
// 发起请求
- (void)downloader:(Downloader *)downloader startedOn:(NSDate *)timeStarted
{
    if (_state == TaskUnInited) {
        // 重新开始则清除资源文件
        [self _removeResource];
        [self _updateState:TaskPending];
    }
    else {
        [self _updateState:TaskRunning];
    }
}

// 收到请求
- (void)downloader:(Downloader *)downloader headerReceived:(NSDictionary *)header
{
    if (_state == TaskPending) {
        // 分析header获取文件大小
        NSString *contentRange = [header valueForKey:@"Content-Range"];
        uint total;
        if (contentRange && contentRange.length) {
            NSRange r = [contentRange rangeOfString:@"/" options:NSBackwardsSearch];
            total = [[contentRange substringFromIndex:r.location + 1] intValue];
        }
        else {
            total = [[header valueForKey:@"Content-Length"] intValue];
        }
        _bytesTotal = total;
        [self _updateState:TaskRunning];
    }
}

// 收到数据
- (void)downloader:(Downloader *)downloader dataReceived:(NSData *)chunkOfData
{
    //NSLog(@"%d bytes loaded", chunkOfData.length);
    [self _appendToBuffer:chunkOfData];

    self.bytesDownloaded = _bytesDownloaded + chunkOfData.length;
    [self _syncFinishState];
}

// 下载完成
- (void)downloader:(Downloader *)downloader done:(NSDate *)timeDone
{
    [self _flushBuffer:YES];
    [self _updateState:TaskDownDone];
}

// 失败
- (void)downloader:(Downloader *)downloader failedWithMessage:(NSString *)errorMessage
{
    [self downloader:downloader failedWithMessage:errorMessage flushBuffer:YES];
}
- (void)downloader:(Downloader *)downloader failedWithMessage:(NSString *)errorMessage flushBuffer:(BOOL)flushBuffer
{
    NSLog(@"failed %@", errorMessage);
    // TODO toast提示错误消息
    // 如果是downloader失败，则将buff中现有数据写入，如果是写入失败，则不再重试
    if (flushBuffer)
        [self _flushBuffer:YES];
    
    if (_state == TaskPending)
        [self _updateState:TaskUnInited];
    else
        [self _updateState:TaskFailed];
    
    [_downloader cancel];
    _downloader = nil;
}


#pragma mark 资源文件管理
- (void)_removeResource
{
    NSString *resourceFile = [DownloadTask pathForResourceFile:self.resourceId];
    [[NSFileManager defaultManager] removeItemAtPath:resourceFile error:nil];
}
- (void)_appendToBuffer:(NSData *)data
{
    @synchronized(self) {
        if (!_buff)
            _buff = [NSMutableData dataWithCapacity:BUFF_FLUSH_THRESHOLD];
        [_buff appendData:data];
    }
    [self _flushBuffer:NO];
}
// 写入数据，如果非forced，则检查缓存大小，超过一定数量才写入
- (void)_flushBuffer:(BOOL)forced
{
    @synchronized(self) {
        if (_buff && (_buff.length >= BUFF_FLUSH_THRESHOLD || forced)) {
            // flush
            if (_buff.length) {
                NSString *resourceFile = [DownloadTask pathForResourceFile:self.resourceId];
                NSLog(@"Flushing data (%zd bytes) to resource file %@", _buff.length, resourceFile);
                
                NSFileHandle *resFile = [NSFileHandle fileHandleForUpdatingAtPath:resourceFile];
                if (!resFile) {
                    // 创建文件
                    NSError *err;
                    if (![_buff writeToFile:resourceFile options:NSDataWritingAtomic error:&err]) {
                        [self downloader:_downloader failedWithMessage:[err localizedDescription] flushBuffer:NO];
                    }
                    else {
                        [_buff setLength:0];
                    }
                }
                else {
                    // 追加数据
                    [resFile seekToEndOfFile];
                    [resFile writeData:_buff];
                    [resFile closeFile];
                    [_buff setLength:0];
                }
            }
            else {
                NSLog(@"No data to flush");
            }
        }
    }
}


#pragma mark Init & Destroy
- (void)_init
{
    _threadLock = @[];
}

- (instancetype)initWithResourceId:(NSString *)resourceId title:(NSString *)title fileType:(NSString *)fileType extraData:(NSDictionary *)extraData
{
    if (self = [super init]) {
        [self _init];

        _resourceId = resourceId;
        _title = title;
        if (!fileType)
            fileType = @"";
        if (fileType.length && ![fileType hasPrefix:@"."])
            fileType = [@"." stringByAppendingString:fileType];
        _fileType = [fileType lowercaseString];
        _bytesTotal = 0;
        _bytesDownloaded = 0;
        _state = TaskUnInited;
        _extraData = extraData;
        _taskTimestamp = [[NSDate date] timeIntervalSince1970];
    }
    return self;
}


- (instancetype)initWithResourceId:(NSString *)resourceId title:(NSString *)title url:(NSString *)url fileType:(NSString *)fileType extraData:(NSDictionary *)extraData
{
    if (self = [super init]) {
        [self _init];
        
        _resourceId = resourceId;
        _title = title;
        _downloadUrl = url;
        if (!fileType)
            fileType = @"";
        if (fileType.length && ![fileType hasPrefix:@"."])
            fileType = [@"." stringByAppendingString:fileType];
        _fileType = [fileType lowercaseString];
        _bytesTotal = 0;
        _bytesDownloaded = 0;
        _state = TaskUnInited;
        _extraData = extraData;
        _taskTimestamp = [[NSDate date] timeIntervalSince1970];
    }
    return self;
}

- (instancetype)initWithDescriptorFileOfResourceId:(NSString *)resourceId
{
    if (self = [super init]) {
        [self _init];
        
        // 分析描述文件
        if (![self tryRestoreStateFromDescriptorFileOfResourceId:resourceId])
            return nil;
        if (_bytesTotal) {
            if (_bytesDownloaded == _bytesTotal)
                _state = TaskDownDone;
            else
                _state = TaskPaused;
            // 调用setter更新状态
            self.bytesDownloaded = _bytesDownloaded;
            [self _syncFinishState];
        }
        else {
            _state = TaskUnInited;
        }
    }
    return self;
}

- (void)dealloc
{
    [self printDealloc];
    _buff = nil;
    _threadLock = nil;
    _downloadThread = nil;
    _extraData = nil;
}

- (BOOL)saveToDescriptorFile
{
    NSString *folder = [DownloadManager pathForResources];
    NSString *fileName = [DownloadTask descriptorFileNameForResourceId:self.resourceId];
    NSString *file = [folder stringByAppendingPathComponent:fileName];
    NSString *content = [self stringContentForDescriptorFile];
    NSData *contentData = [content dataUsingEncoding:NSUTF8StringEncoding];
    
    NSError *err;
    BOOL fileWritten = [contentData writeToFile:file
                                        options:NSDataWritingAtomic
                                          error:&err];
    if (!fileWritten) {
        NSLog(@"无法保存任务描述到文件%@ : %@", file, [err localizedDescription]);
    }
    return fileWritten;
}

+ (NSString *)descriptorFileNameForResourceId:(NSString *)resourceId
{
    return [NSString stringWithFormat:@"%@.task", resourceId];
}

#pragma mark Utils

+ (NSString *)pathForResourceFile:(NSString *)resourceId
{
    NSString *resourceFile = [[DownloadManager pathForResources] stringByAppendingPathComponent:resourceId];
    return resourceFile;
}
+ (NSString *)pathForDescriptorFile:(NSString *)resourceId
{
    NSString *fileName = [DownloadTask descriptorFileNameForResourceId:resourceId];
    NSString *descriptorFile = [[DownloadManager pathForResources] stringByAppendingPathComponent:fileName];
    return descriptorFile;
}

- (NSString *)stringContentForDescriptorFile
{
    NSMutableString *desc = [NSMutableString stringWithCapacity:128];
    [desc appendString:@"title="];
    [desc appendString:[self.title stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    [desc appendString:@"\nfileType="];
    [desc appendString:[self.fileType stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    [desc appendString:@"\nbytesTotal="];
    [desc appendFormat:@"%u", self.bytesTotal];
    if (_extraData) {
        for (NSString *extraDataKey in _extraData) {
            [desc appendFormat:@"\nextraData.%@=", extraDataKey];
            NSString *extraDataValue = [[[_extraData valueForKey:extraDataKey] description] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            [desc appendString:extraDataValue];
        }
    }
    return desc;
}

- (BOOL)tryRestoreStateFromDescriptorFileOfResourceId:(NSString *)resourceId
{
    _resourceId = resourceId;
    
    NSString *file = [DownloadTask pathForDescriptorFile:resourceId];
    NSError *err;
    NSString *content = [[NSString alloc] initWithContentsOfFile:file
                                                        encoding:NSUTF8StringEncoding
                                                           error:&err];
    if (err) {
        NSLog(@"无法读取任务描述文件%@ : %@", file, [err localizedDescription]);
        return NO;
    }
    else if (!content || !content.length) {
        NSLog(@"无法读取任务描述文件%@ : NO CONTENT", file);
        return NO;
    }
    else {
        _extraData = [NSMutableDictionary dictionaryWithCapacity:8];
        NSArray *lines = [content componentsSeparatedByString:@"\n"];
        for (NSString *line in lines) {
            NSRange pcolon = [line rangeOfString:@"="];
            if (!pcolon.length || !pcolon.location)
                continue;
            NSString *key = [line substringToIndex:pcolon.location];
            NSString *value = [[line substringFromIndex:pcolon.location + 1] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            if (!key.length)
                continue;
            if ([key isEqualToString:@"title"]) {
                _title = value;
            }
            else if ([key isEqualToString:@"fileType"]) {
                if (value.length && ![value hasPrefix:@"."])
                    value = [@"." stringByAppendingString:value];
                _fileType = [value lowercaseString];
            }
            else if ([key isEqualToString:@"bytesTotal"]) {
                _bytesTotal = [value intValue];
            }
            else {
                // 附加信息格式为extraData.<PROPERTY>=*
                if ([key hasPrefix:@"extraData."]) {
                    NSString *extraDataKey = [key substringFromIndex:10];
                    [_extraData setValue:value forKey:extraDataKey];
                }
            }
        }
        _bytesDownloaded = 0;
        
        // 文件创建时间
        NSDictionary *descFileAttrs = [[NSFileManager defaultManager] attributesOfItemAtPath:file error:nil];
        _taskTimestamp = [[descFileAttrs fileCreationDate] timeIntervalSince1970];
        
        // 检查资源文件
        NSString *resourceFile = [DownloadTask pathForResourceFile:resourceId];
        NSFileManager *fm = [NSFileManager defaultManager];
        BOOL isResourceFileADirectory;
        if ([fm fileExistsAtPath:resourceFile isDirectory:&isResourceFileADirectory]) {
            if (isResourceFileADirectory) {
                // 删除目录
            }
            else {
                err = nil;
                NSDictionary *fileAttrs = [fm attributesOfItemAtPath:resourceFile error:&err];
                if (err) {
                    NSLog(@"无法获取文件属性%@ : %@", resourceFile, [err localizedDescription]);
                }
                else {
                    if (fileAttrs)
                        _bytesDownloaded = fileAttrs.fileSize;
                    else
                        NSLog(@"无法获取文件属性%@ : NO ATTRS", resourceFile);
                }
            }
        }
    }
    return YES;
}


- (NSString *)remoteUrlForResource
{
    NSString *url;
//    if ([self.fileType isEqualToString:@".pdf"]) {
//        url = [DownloadManager urlForWordResource:self.resourceId];
//    }
//    else if ([self.fileType isEqualToString:@".mp4"]) {
//        url = [DownloadManager urlForVideoResource:self.resourceId];
//    }
//    else {
//        NSLog(@"未知的资源类型:%@", self.fileType);
//        url = nil;
//    }
    url = [DownloadManager urlForResource:self.resourceId];
    return url;
}

- (NSString *)description
{
    NSString *desc = [NSString stringWithFormat:@"< DownloadTask, resId = %@, title = %@, fileType = %@, bytes = %d/%d : %f, state = %@ >", _resourceId, _title, _fileType, _bytesDownloaded, _bytesTotal, self.progress, [self _stringForState:_state]];
    return desc;
}
@end