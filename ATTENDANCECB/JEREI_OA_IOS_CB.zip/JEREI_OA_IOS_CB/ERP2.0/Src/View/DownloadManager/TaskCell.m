//
//  TaskCell.m
//  CNNCTrain
//
//  Created by jerei on 14-8-22.
//
//

#import "TaskCell.h"

@interface TaskCell()
{
    UILabel *_titleLabel;
    UILabel *_sizeLabel;
    UIButton *_actionButton;
    UIProgressView *_progressView;
    BOOL _layoutDone;
}
@end

@implementation TaskCell

@synthesize task = _task;

// H : horizontal, V : vertical
// spacing : 元素间距
// margin : label/button/text外补白
static float _cellHeight, _cellWidth, _spacingHV = 4.0f, _marginHV = 8.0f, _textMarginV = 2.0f, _progressHeight = 2.0f;
static float _fontSize, _smallFontSize;
+ (void)load
{
    _fontSize = [UIFont labelFontSize];
    _smallFontSize = [UIFont smallSystemFontSize];
    
    _cellWidth = [UIScreen mainScreen].bounds.size.width;
    _cellHeight = _marginHV * 2 + _spacingHV + _fontSize + _smallFontSize + _textMarginV * 4;
}

+ (float)cellHeight
{
    return _cellHeight;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier size:(CGSize)size
{
    if (self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier]) {
        [self _init:size];
    }
    return self;
}

- (void)_init:(CGSize)size
{
    self.frame = CGRectMake(0, 0, size.width, size.height);
    self.contentView.frame = self.frame;
    self.imageView.hidden = YES;
    self.textLabel.hidden = YES;
    self.detailTextLabel.hidden = YES;
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    
    _progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(0, 0, size.width, _progressHeight)];
    _progressView.progress = 0;
    _progressView.userInteractionEnabled = NO;
    _progressView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.contentView addSubview:_progressView];
    
    _titleLabel = [[UILabel alloc] init];
    _titleLabel.font = [UIFont systemFontOfSize:_fontSize];
    _titleLabel.userInteractionEnabled = NO;
    _titleLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self.contentView addSubview:_titleLabel];
    
    _sizeLabel = [[UILabel alloc] init];
    _sizeLabel.font = [UIFont systemFontOfSize:_smallFontSize];
    _sizeLabel.textColor = [UIColor lightGrayColor];
    _sizeLabel.userInteractionEnabled = NO;
    _sizeLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self.contentView addSubview:_sizeLabel];
    
    _actionButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _actionButton.titleLabel.font = [UIFont systemFontOfSize:_fontSize];
    [_actionButton addTarget:self action:@selector(taskTapped:) forControlEvents:UIControlEventTouchUpInside];
    _actionButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [self.contentView addSubview:_actionButton];
    
    [self _doLayout];
}

- (void)updateViewWithTask:(DownloadTask *)task
{
    _task = task;
    
    NSString *buttonTitle;
    NSString *sizeTitle = [NSString stringWithFormat:@"%zdB", task.bytesTotal];
    BOOL buttonEnabled;
    BOOL progressHidden;
    
    switch (task.state) {
        case TaskDownDone:
            buttonTitle = @"打开";
            buttonEnabled = YES;
            progressHidden = YES;
            break;
        case TaskFailed:
            sizeTitle = [NSString stringWithFormat:@"%@ 已暂停", sizeTitle];
            buttonTitle = @"重试";
            buttonEnabled = YES;
            progressHidden = NO;
            break;
        case TaskPaused:
            sizeTitle = [NSString stringWithFormat:@"%@ 已暂停", sizeTitle];
            buttonTitle = @"下载";
            buttonEnabled = YES;
            progressHidden = NO;
            break;
        case TaskPending:
            buttonTitle = @"等待";
            buttonEnabled = NO;
            progressHidden = YES;
            break;
        case TaskUnInited:
            buttonTitle = @"下载";
            buttonEnabled = YES;
            progressHidden = YES;
            break;
        case TaskRunning:
            buttonTitle = @"暂停";
            buttonEnabled = YES;
            progressHidden = NO;
            break;
        default:
            NSLog(@"invalid task state");
            break;
    }
    
    
    if (![_titleLabel.text isEqualToString:task.title])
        _titleLabel.text = task.title;
    if (![_sizeLabel.text isEqualToString:sizeTitle])
        _sizeLabel.text = sizeTitle;
    if (![[_actionButton titleForState:UIControlStateNormal] isEqualToString:buttonTitle])
        [_actionButton setTitle:buttonTitle forState:UIControlStateNormal];
    if (_actionButton.enabled != buttonEnabled)
        _actionButton.enabled = buttonEnabled;
    if (_progressView.hidden != progressHidden)
        _progressView.hidden = progressHidden;
    if (!progressHidden && _progressView.progress != task.progress)
        [_progressView setProgress:task.progress animated:NO];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
}

- (void)_doLayout
{
    float w, h;
    w = self.frame.size.width;
    h = self.frame.size.height;
    float m = _marginHV, tm = _textMarginV, s = _spacingHV, ph = _progressHeight;
    float aw = w - m * 2, ah = h - m * 2;
    float wbtn = [UIFont labelFontSize] * 2 * 1.2;
    
    CGRect crTitle = CGRectMake(m, m + tm, aw - wbtn - s, _fontSize);
    _titleLabel.frame = crTitle;
    
    CGRect crSize = CGRectMake(m, crTitle.origin.y + crTitle.size.height + tm + s + tm, aw - wbtn - s, _smallFontSize);
    _sizeLabel.frame = crSize;
    
    CGRect crAction = CGRectMake(crTitle.origin.x + crTitle.size.width + s, m, wbtn, ah);
    _actionButton.frame = crAction;
    
    CGRect crProgress = { { 0, h - ph - 1 }, { w, ph } };
    _progressView.frame = crProgress;
}

- (void)taskTapped:(id)sender
{
    UIButton *btn = (UIButton *)sender;
    NSDictionary *userInfo = @{ @"command" : btn.titleLabel.text };
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_TASK_TAPPED object:_task userInfo:userInfo];
}

@end
