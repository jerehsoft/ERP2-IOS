//
//  DMEntryViewController.m
//  CNNCTrain
//
//  Created by jerei on 14-8-20.
//
//

#import "DMEntryViewController.h"
#import "DMTabBarController.h"
#import "DownloadManager.h"

@interface DMEntryViewController ()
{
    __weak DMTabBarController * tabBarController;
}
@property (strong, nonatomic) IBOutlet UIView *containerView;

@end

@implementation DMEntryViewController

- (IBAction)addDownload_TEST:(id)sender
{
    // 随机添加测试下载
    NSArray *books = @[
                       @{@"courseId" : @"f7dd8d58ee6f425baca0a20fc4db8b53",
                         @"id" : @"acbbeedf94804599991627508887bbb7",
                         @"mobileFileName" : @"/uploadfiles/mobileBook/03eedfb878df40e6aeb00bc88a3fae81.pdf",
                         @"mobileFileOldName" : @"",
                         @"name" : @"Sprite Kit............"},
                       @{@"courseId" : @"f7dd8d58ee6f425baca0a20fc4db8b53",
                         @"id" : @"2a9d58fb36854549b9da17c5d349201b",
                         @"mobileFileName" : @"/uploadfiles/mobileBook/b274f991be38497781b857b5bd16a6a5.mp4",
                         @"mobileFileOldName" : @"",
                         @"name" : @"2011..............."},
                       @{@"courseId" : @"f7dd8d58ee6f425baca0a20fc4db8b53",
                         @"id" : @"375838b17b334af78303d4c24acc535c",
                         @"mobileFileName" : @"/uploadfiles/mobileBook/161a54cd10a445f38f3363584f8cb97d.pdf",
                         @"mobileFileOldName" : @"",
                         @"name" : @"................................."},
                       @{@"courseId" : @"2b57daae85af4b228f53d69cf1eaa574",
                         @"id" : @"5451a0df3d264f2da8215be12a6a4a7e",
                         @"mobileFileName" : @"/uploadfiles/mobileBook/00a274e800ea42c096cf54cbd03f3ede.pdf",
                         @"mobileFileOldName" : @"",
                         @"name" : @"............-...................................."},
                       @{@"courseId" : @"f7dd8d58ee6f425baca0a20fc4db8b53",
                         @"id" : @"217909428ea340f1bf43ca05c97f694c",
                         @"mobileFileName" : @"/uploadfiles/mobileBook/94b21ed5a6174e83a64c23fabf1c7dc9.mp4",
                         @"mobileFileOldName" : @"", 
                         @"name" : @"94b0f919965d4034a17a15a705ae1dfa"} 
                       ];
    
    srand(arc4random());
    double randomResourceIndex = (rand() / (double)RAND_MAX) * books.count;
    NSDictionary *book = [books objectAtIndex:(int)randomResourceIndex];
    NSLog(@"add task -> %@", book);
    NSString *resourceId = [book valueForKey:@"id"];
    NSString *title = [book valueForKey:@"name"];
    NSString *fileNameWithType = [book valueForKey:@"mobileFileName"];
    NSString *fileType = [[fileNameWithType substringFromIndex:[fileNameWithType rangeOfString:@"." options:NSBackwardsSearch].location] lowercaseString];
    NSDictionary *extraData = @{
                                @"courseName" : book[@"name"],
                                @"courseId" : book[@"courseId"],
                                @"mobileFileName" : book[@"mobileFileName"]
                                 };
    DownloadTask *task = [DownloadManager queueTaskForResourceId:resourceId
                                                           title:title
                                                        fileType:fileType
                                                       extraData:extraData];
    NSLog(@"task = %@", task);
}

- (IBAction)dismissDownloadManager:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)clearData:(id)sender
{
    if (tabBarController) {
        [tabBarController clearData];
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.destinationViewController isKindOfClass:[DMTabBarController class]])
    {
        // 记住内嵌的tabbarcontroller，用于发送清空数据消息
        tabBarController = segue.destinationViewController;
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 恢复本地任务
//    [DownloadManager restore];
}

#pragma mark Current User
static NSString *_currentUserId, *_currentUserOrganizeNo, *_currentUserFullName;
+ (void)setCurrentUserId:(NSString *)userId
{
    _currentUserId = userId;
}
+ (NSString *)currentUserId
{
    return _currentUserId;
}

+ (void)setCurrentUserOrganizeNo:(NSString *)organizeNo
{
    _currentUserOrganizeNo = organizeNo;
}
+ (NSString *)currentUserOrganizeNo
{
    return _currentUserOrganizeNo;
}

+ (void)setCurrentUserFullName:(NSString *)fullName
{
    _currentUserFullName = fullName;
}
+ (NSString *)currentUserFullName
{
    return _currentUserFullName;
}

@end
