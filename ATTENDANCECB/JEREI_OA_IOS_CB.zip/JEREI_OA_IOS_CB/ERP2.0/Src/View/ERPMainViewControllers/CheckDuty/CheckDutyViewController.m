//
//  CheckDutyViewController.m
//  ERP2.0
//
//  Created by jerei on 14-12-18.
//  Copyright (c) 2014年 jerehsoft. All rights reserved.
//

#import "CheckDutyViewController.h"
#import "ERPWebRequest.h"
#import "ERPDataCache.h"
#import "WIFIUtils.h"
#import "UIView+MJExtension.h"
#import "CheckdutyCell.h"
#import "ErpFormDataUtils.h"
#import "BRTBeaconSDK.h"
#define showAlert(msg) [[[UIAlertView alloc] initWithTitle:Lang(@"Tips", @"提示") message:msg delegate:nil cancelButtonTitle:Lang(@"OK", @"确定") otherButtonTitles: nil] show];

@interface CheckDutyViewController () <UITableViewDataSource, UITableViewDelegate, UIActionSheetDelegate>
@property (weak, nonatomic) IBOutlet UILabel *alreadyCheclLable;
@property (weak, nonatomic) IBOutlet UIImageView *topiamge;
@property (strong, nonatomic) IBOutlet UIView *leaveCoView;
@property (strong, nonatomic) IBOutlet UIView *returnCoView;
@property (strong, nonatomic) IBOutlet UIImageView *dutyImage;
@property (strong, nonatomic) IBOutlet UILabel *dutyLabel;
@property (strong, nonatomic) IBOutlet UILabel *timeLabel;
@property (strong, nonatomic) IBOutlet UILabel *dateLabel;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *CheckButton;
@property (weak, nonatomic) IBOutlet UIView *checkView;
@property (weak, nonatomic) IBOutlet UIView *noticeView;
@property (weak, nonatomic) IBOutlet UILabel *noticeLable;
@property (weak, nonatomic) IBOutlet UILabel *kqjlLable;
@property (weak, nonatomic) IBOutlet UILabel *ckxxLable;
@property (weak, nonatomic) IBOutlet UIButton *ckeckDetailButton;
@property (nonatomic, strong) NSArray                  *beacons;

@property (weak, nonatomic) IBOutlet UIView *checkDetailView;
@property (copy, atomic) NSString *currentWifi;
@property (copy, atomic) NSString *currentWifiName;

@end

@implementation CheckDutyViewController {
    NSTimer *_timer;
    NSMutableArray *_signDisplayList;
    NSArray *_devices;
    NSArray *_signList;
    BOOL checkOnDuty;
    NSString *_uuid;
    NSString *_submitMessage;
    NSArray *_deviceList;
    UIActionSheet *_actionSheet;
    NSMutableArray *_peripheralList;
    BOOL _notifyDataHasChanged;
    BOOL _connecting;
    BOOL _cbFlag;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}


#pragma mark - frame
- (void)viewDidLoad {
    [super viewDidLoad];
    _cbFlag = NO;
    _deviceList = [[NSUserDefaults standardUserDefaults] objectForKey:@"deviceList"];


    _peripheralList = [[NSMutableArray alloc] init];
    _connecting = NO;

    self.noticeLable.adjustsFontSizeToFitWidth = YES;
    self.CheckButton.layer.masksToBounds = YES;
    self.CheckButton.layer.cornerRadius = self.CheckButton.mj_w / 2.0;
    self.checkView.mj_y = self.checkView.mj_y - 15;
    self.returnCoView.mj_y = self.checkView.mj_y - 20;
    self.checkView.layer.cornerRadius = self.checkView.mj_w / 2.0;
    self.leaveCoView.mj_y = self.checkView.mj_y - 20;
    self.alreadyCheclLable.layer.masksToBounds = YES;
    self.alreadyCheclLable.layer.cornerRadius = 10;
    self.alreadyCheclLable.adjustsFontSizeToFitWidth = YES;
    self.leaveCoView.backgroundColor = [UIColor colorWithRed:31/255.0 green:186/255.0 blue:243/255.0 alpha:1];
    self.returnCoView.backgroundColor = [UIColor yellowColor];
    self.leaveCoView.mj_x = self.checkView.mj_x - self.leaveCoView.mj_w - 15;
    self.returnCoView.mj_x = self.checkView.mj_w + self.checkView.mj_x + 15;
    self.noticeView.mj_y = self.checkView.mj_y + self.checkView.mj_h + 2;
    self.checkView.backgroundColor = [UIColor colorWithRed:240/255.0 green:152/255.0 blue:38/255.0 alpha:1];
    self.kqjlLable.adjustsFontSizeToFitWidth = YES;
    self.kqjlLable.mj_y = self.noticeView.mj_y + self.noticeView.mj_h + 4;
    self.ckxxLable.layer.masksToBounds = YES;
    self.ckxxLable.layer.cornerRadius = self.ckxxLable.mj_h / 2.0;
    self.checkDetailView.mj_y = self.kqjlLable.mj_y + self.kqjlLable.mj_h +  5;
    self.dutyImage.mj_x = self.checkView.mj_w / 2.0 - self.dutyImage.mj_w / 2.0;
    self.tableView.mj_y = self.checkDetailView
    .mj_y + self.checkDetailView.mj_h;
    self.tableView.mj_h = [UIScreen mainScreen].bounds.size.height - self.tableView.mj_y - 49;
    self.tableView.bounces = NO;



    self.topiamge.mj_h = self.topiamge.mj_h  - 64;
    self.timeLabel.adjustsFontSizeToFitWidth = YES;
    _signDisplayList = [[NSMutableArray alloc] init];
    if ([UIScreen mainScreen].bounds.size.height <= 480) {
        //专为4:3屏幕优化布局
        CGRect frame = self.leaveCoView.frame;
        frame.origin.y += 10;
        self.leaveCoView.frame = frame;
        
        frame = self.returnCoView.frame;
        frame.origin.y += 10;
        self.returnCoView.frame = frame;
        
        frame = self.dutyImage.frame;
        frame.origin.y += 5;
        self.dutyImage.frame = frame;
        
        frame = self.dutyLabel.frame;
        frame.origin.y += 10;
        self.dutyLabel.frame = frame;
    }
    self.leaveCoView.layer.cornerRadius = self.leaveCoView.mj_w/2.0;
    self.returnCoView.layer.cornerRadius = self.returnCoView.mj_w/2.0;
    self.leaveCoView.layer.masksToBounds = YES;
    self.returnCoView.layer.masksToBounds = YES;
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    if ([[[NSDate date] stringWithFormat:@"HH"] intValue] >= 6 && [[[NSDate date] stringWithFormat:@"HH"] intValue] <= 18 ) {
        self.dutyImage.image = [UIImage imageNamed:@"sbqd.png"];
    } else {
        self.dutyImage.image = [UIImage imageNamed:@"xb.png"];
    }

    
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];

    if ([UIScreen mainScreen].bounds.size.width == 320) {
        self.leaveCoView.mj_y = 260;
        self.returnCoView.mj_y = 260;
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
- (IBAction)dismiss:(id)sender {
    [self.navigationController  popViewControllerAnimated:YES];
//    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    _cbFlag = NO;
    _uuid = [ObjectUtils createUUID];
    if ([ERPAuthContext getUser]) {
        [self loadDutyDataWithComplete:^{
            checkOnDuty = NO;
            for (NSDictionary *sign in _signList) {
                if ([[sign valueForKey:@"signType"] intValue] == 1) {
                    checkOnDuty = YES;
                    break;
                }
            }
            if (checkOnDuty) {
                self.dutyImage.image = [UIImage imageNamed:@"xb.png"];
                self.dutyLabel.text = @"下班签退";
            } else {
                self.dutyImage.image = [UIImage imageNamed:@"sbqd.png"];
                self.dutyLabel.text = @"上班签到";
            }
            [self.tableView reloadData];
        }];
    }
}
- (IBAction)detailButClick:(id)sender {
    [JSUIUtils alert:@"正在维护..." withTitle:@"敬请期待"];
}

-(void)updateTimer {

    if ([[ErpFormDataUtils getDataForKey:@"day"]intValue] != [[[NSDate date] stringWithFormat:@"dd"] intValue] ) {
        [ErpFormDataUtils removeDataForKey:@"leave"];
    }


    [[[NSThread alloc]initWithTarget:self selector:@selector(getWifiInfo) object:nil] start];
    NSDate *date = [NSDate date];
    self.dateLabel.text = [NSString stringWithFormat:@"%@ %@",[date stringWithFormat:@"yyyy-MM-dd"],[DateUtils weekDayNameByDate:date]];
    self.timeLabel.text = [date stringWithFormat:@"HH:mm:ss"];
    if (checkOnDuty) {
        [_timer setFireDate:[NSDate distantFuture]];
        self.timeLabel.text = @"上班已签到";
    }
    if ([[ErpFormDataUtils getDataForKey:@"leave"]isEqualToString:@"leave"]) {
        self.timeLabel.text = @"下班已签退";
    }
}

-(void)loadDutyDataWithComplete:(void(^)())complete {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view.window animated:YES];
    [hud setLabelText:@"请稍候"];
    ERPUser *user = [ERPAuthContext getUser];
    [[ERPWebRequest mainSiteRequest] requestDataWithRelativeURI:@"phone/attenInfo.action"
                                                     withParams:@{@"userId":@(user.userId)}
                                                    withHeaders:nil
                                                 successHandler:^(NSDictionary *responseData) {

                                                     _devices = [responseData valueForKey:@"devices"];
                                                     [BRTBeaconSDK startRangingWithUuids:@[[[NSUUID alloc] initWithUUIDString:DEFAULT_UUID]] onCompletion:^(NSArray *beacons, BRTBeaconRegion *region, NSError *error) {

                                                         if (!error) {
                                                             NSLog(@"%@",beacons);
                                                             if (beacons.count == 0) {
                                                                 [hud hide:YES];
                                                             }else{
                                                                 for (BRTBeacon *beaco in beacons) {
                                                                     for (NSDictionary *device in _devices) {
                                                                         if ([[device valueForKey:@"machMac"] isEqualToString:beaco.macAddress]) {
                                                                             [ErpFormDataUtils setData:[device valueForKey:@"machMac"] forKey:@"machMacs"];
                                                                             _cbFlag = YES;
                                                                             [hud hide:YES];
                                                                         }
                                                                     }
                                                                 }
                                                             }
                                                         }else{
                                                             //检查蓝牙是否打开
                                                             [hud hide:YES];
                                                             [JSUIUtils popSuccessControllerWithType:5 message:@"请打开蓝牙!" complete:nil];
                                                         }
                                                     }];
                                                     _signList = [responseData valueForKey:@"signList"];
                                                     [_signDisplayList removeAllObjects];
                                                     for (NSDictionary *sign in _signList) {
                                                         NSString *typeName = @"";
                                                         switch ([[sign valueForKey:@"signType"] intValue]) {
                                                             case 1:
                                                                 typeName = @"上班签到";
                                                                 break;
                                                             case 2:
                                                                 typeName = @"下班签退";
                                                                 break;
                                                             case 3:
                                                                 typeName = @"离司打卡";
                                                                 break;
                                                             case 4:
                                                                 typeName = @"回司打卡";
                                                                 break;
                                                         }
                                                         [_signDisplayList addObject:[NSString stringWithFormat:@"您已 %@成功",typeName]];
                                                         if (complete) {
                                                             complete();
                                                         }
                                                     }
                                                 }
                                                   errorHandler:^(MKNetworkOperation *operation, NSError *error) {
                                                       [hud hide:YES];
                                                       [JSUIUtils popSuccessControllerWithType:5 message:@"请在指定区域考勤,谢谢!" complete:nil];
                                                   }];
}

-(void)submitAttenWithType:(int)type complete:(void(^)())complete {
    _submitMessage = nil;
    NSMutableDictionary *mtformData = [[NSMutableDictionary alloc] init];
    [mtformData setValue:@([ERPAuthContext getUser].userId) forKey:@"userId"];
    _currentWifi = [ErpFormDataUtils getDataForKey:@"machMacs"];
    [mtformData setValue:_currentWifi forKey:@"signMachMac"];
    _currentWifiName = [ErpFormDataUtils getDataForKey:@"machMacs"];
    [mtformData setValue:_currentWifiName forKey:@"signMachName"];
//    [mtformData setValue:[[NSDate date] stringWithFormat:@"yyyy-MM-dd HH:mm:ss"] forKey:@"signTime"];
    [mtformData setValue:@(type) forKey:@"signType"];
    [mtformData setValue:_uuid forKey:@"uuid"];
    NSMutableDictionary *params = [JSWebRequest paramsWithDictionary:nil];
    [JSWebRequest addParamOfName:@"en" value:mtformData toParams:params];
    NSDictionary *extraParams = @{@"struts.enableJSONValidation" : @"true"};
    [JSWebRequest addParamOfName:nil value:extraParams toParams:params];
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view.window animated:YES];
    [hud setLabelText:@"请稍候"];

    [[ERPWebRequest mainSiteRequest] requestDataWithRelativeURI:@"phone/submitAtten.action"
                                                     withMethod:@"POST"
                                                     withParams:params
                                                    withHeaders:nil
                                                 successHandler:^(NSDictionary *responseData) {
                                                     _submitMessage = [responseData valueForKey:@"actionMessages"][0];
                                                     [hud hide:YES];
                                                     if (complete) {
                                                         complete();
                                                     }
                                                 }
                                                   errorHandler:^(MKNetworkOperation *operation, NSError *error) {
                                                       [hud hide:YES];
                                                       NSString *failureReason = [error localizedFailureReason];
                                                       [JSUIUtils popSuccessControllerWithType:5 message:failureReason complete:nil];
                                                   }];
}

#pragma mark - user interaction
-(IBAction)duty:(id)sender {
    if ([ERPAuthContext getUser] && [ERPAuthContext getUser].isValid) {
        _currentWifi = [WIFIUtils getBSSID];
        _currentWifiName = [WIFIUtils getSSID];
        [WIFIUtils checkWIFIWithWifiInfo:_currentWifi currentCBFlag:_cbFlag devices:_devices complete:^{
            if ([self.dutyLabel.text isEqualToString:@"下班签退"]) {
                NSString *alertTitle = NSLocalizedString(@"温馨提示", @"Basic Alert Style");
                NSString *alertMessage = NSLocalizedString(@"您确定要签退吗?", @"Basic Alert With Buttons");
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:alertTitle
                                                                                         message:alertMessage
                                                                                  preferredStyle:UIAlertControllerStyleAlert];

                UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"取消", @"Cancel action")
                                                                       style:UIAlertActionStyleCancel
                                                                     handler:^(UIAlertAction *action)
                                               {
//                                                   [self viewDidAppear:NO];
                                               }];

                UIAlertAction *okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"确定", @"OK action")
                                                                   style:UIAlertActionStyleDefault
                                                                 handler:^(UIAlertAction *action)
                                           {
                                               [self submitAttenWithType:checkOnDuty?2:1 complete:^{
                                                   [JSUIUtils popSuccessControllerWithType:checkOnDuty?2:1 message:_submitMessage complete:^{
                                                       if ([self.dutyLabel.text isEqualToString:@"下班签退"]) {
                                                           //                        [_timer setFireDate:[NSDate date]];
                                                           [_timer setFireDate:[NSDate distantFuture]];
                                                           self.timeLabel.text = @"下班已签退";
                                                           [ErpFormDataUtils setData:@"leave" forKey:@"leave"];

                                                           [ErpFormDataUtils setData:@([[[NSDate date] stringWithFormat:@"dd"] intValue]) forKey:@"day"];
                                                           
                                                       }else{
                                                           [_timer setFireDate:[NSDate distantFuture]];
                                                           self.timeLabel.text = @"上班已签到";
                                                           
                                                       }
                                                       [self viewDidAppear:NO];
                                                   }];
                                               }];
                                           }];
                
                [alertController addAction:cancelAction];
                [alertController addAction:okAction];
                
                [self presentViewController:alertController animated:YES completion:nil];
            }
        }];
    } else {
        [JSUIUtils popLoginControllerWithComplete:nil];
    }
}

-(IBAction)leaveCompony:(id)sender {
    if ([ERPAuthContext getUser] && [ERPAuthContext getUser].isValid) {
        [WIFIUtils checkWIFIWithWifiInfo:_currentWifi currentCBFlag:_cbFlag devices:_devices complete:^{
            [self submitAttenWithType:3 complete:^{
                [JSUIUtils popSuccessControllerWithType:3 message:_submitMessage complete:^{
                    NSLog(@"wohao");

                    [self viewDidAppear:NO];
                }];
            }];
        }];
    } else {
        [JSUIUtils popLoginControllerWithComplete:nil];
    }
}

-(IBAction)returnCompony:(id)sender {
    if ([ERPAuthContext getUser] && [ERPAuthContext getUser].isValid) {
        [WIFIUtils checkWIFIWithWifiInfo:_currentWifi currentCBFlag:_cbFlag devices:_devices complete:^{
            [self submitAttenWithType:4 complete:^{
                [JSUIUtils popSuccessControllerWithType:4 message:_submitMessage complete:^{
                    [self viewDidAppear:NO];
                }];
            }];
        }];
    } else {
        [JSUIUtils popLoginControllerWithComplete:nil];
    }
}

#pragma mark - WIFI 建议用子线程
- (void)getWifiInfo {
    _currentWifi = [WIFIUtils getBSSID];
    _currentWifiName = [WIFIUtils getSSID];

}

#pragma mark - tableview delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _signDisplayList.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier=@"cell";
    CheckdutyCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"CheckdutyCell" owner:nil options:nil] firstObject];
    }
    cell.backgroundColor = [UIColor clearColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.centerX = 30;
    cell.mj_w = [UIScreen mainScreen].bounds.size.width;

    NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] initWithString:_signDisplayList[indexPath.row]];
    NSString * checkInfor = [attrStr string];
    NSRange range = [checkInfor rangeOfString:@"上"];//判断字符串是否包含
    if (range.length >0)//包含
    {
        NSDictionary *ondutyAttr = @{NSForegroundColorAttributeName: [UIColor grayColor]};
        [attrStr setAttributes:ondutyAttr range:[_signDisplayList[indexPath.row] rangeOfString:@"上班签到成功"]];
        cell.leftLable.attributedText = attrStr;
//        [_timer setFireDate:[NSDate distantFuture]];

        return cell;

    }

    NSRange rangeBack = [checkInfor rangeOfString:@"回"];//判断字符串是否包含
    if (rangeBack.length >0)//包含
    {
        NSDictionary *ondutyAttr = @{NSForegroundColorAttributeName: [UIColor grayColor]};
        [attrStr setAttributes:ondutyAttr range:[_signDisplayList[indexPath.row] rangeOfString:@"回司打卡成功"]];
        cell.leftLable.attributedText = attrStr;
        return cell;

    }

    NSRange xia = [checkInfor rangeOfString:@"下"];//判断字符串是否包含
    if (xia.length >0)//包含
    {
        NSDictionary *offdutyAttr = @{NSForegroundColorAttributeName: [UIColor grayColor]};
        [attrStr setAttributes:offdutyAttr range:[_signDisplayList[indexPath.row] rangeOfString:@"下班签退成功"]];
        cell.rightLable.attributedText = attrStr;
//        [_timer setFireDate:[NSDate date]];

        return cell;

    }

    NSRange li = [checkInfor rangeOfString:@"离"];//判断字符串是否包含
    if (li.length >0)//包含
    {
        NSDictionary *offdutyAttr = @{NSForegroundColorAttributeName: [UIColor grayColor]};
        [attrStr setAttributes:offdutyAttr range:[_signDisplayList[indexPath.row] rangeOfString:@"离司打卡成功"]];
        cell.rightLable.attributedText = attrStr;
        return cell;

    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
