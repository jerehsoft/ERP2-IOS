//
//  CheckdutyCell.m
//  BaseDev
//
//  Created by jereh on 16/6/8.
//  Copyright © 2016年 jerehsoft. All rights reserved.
//

#import "CheckdutyCell.h"
#import "UIView+MJExtension.h"

@implementation CheckdutyCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.middleImage.layer.masksToBounds  = YES;
    self.middleImage.layer.cornerRadius = self.middleImage.mj_w / 2.0;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
