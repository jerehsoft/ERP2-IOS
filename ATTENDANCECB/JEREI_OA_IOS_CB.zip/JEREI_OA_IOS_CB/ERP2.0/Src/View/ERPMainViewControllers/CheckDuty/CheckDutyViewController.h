//
//  CheckDutyViewController.h
//  ERP2.0
//
//  Created by jerei on 14-12-18.
//  Copyright (c) 2014年 jerehsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JSViewController.h"

@interface CheckDutyViewController : JSViewController

@end