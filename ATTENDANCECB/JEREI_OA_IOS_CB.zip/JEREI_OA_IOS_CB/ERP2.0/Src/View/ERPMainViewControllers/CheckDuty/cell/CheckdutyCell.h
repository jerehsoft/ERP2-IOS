//
//  CheckdutyCell.h
//  BaseDev
//
//  Created by jereh on 16/6/8.
//  Copyright © 2016年 jerehsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckdutyCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *middleView;
@property (weak, nonatomic) IBOutlet UILabel *leftLable;
@property (weak, nonatomic) IBOutlet UIImageView *middleImage;
@property (weak, nonatomic) IBOutlet UILabel *rightLable;

@end
