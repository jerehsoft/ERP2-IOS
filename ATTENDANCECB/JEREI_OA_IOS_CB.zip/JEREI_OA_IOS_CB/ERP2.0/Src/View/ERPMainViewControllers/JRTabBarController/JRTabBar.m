//
//  JRTabBar.m
//  WYNews
//
//  Created by 李亚奇 on 15/6/25.
//  Copyright (c) 2015年 jereh. All rights reserved.
//

#import "JRTabBar.h"
#import "JRTabBarButton.h"

CGFloat betWeenButton ;
@interface JRTabBar(){
    NSMutableArray * LableCenterX;

}

@property(nonatomic,weak)UIButton * selectedButton;

@property(nonatomic,strong)NSMutableArray * arrayLable;

@property(nonatomic,weak)UILabel * lable;


@end

@implementation JRTabBar

- (NSMutableArray *)arrayLable{
    if (_arrayLable == nil) {
        _arrayLable = [NSMutableArray array];
    }
    return _arrayLable;
}



//调用init方法的时候一定会调用该方法，此时确定按钮的frame
- (instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    if (self) {
        
        //添加标题
        [self addLables];
   
    }
    return self;
}

//添加lable
- (void)addLables{
    LableCenterX = [NSMutableArray array];
    for (int i = 0; i < 4; i++) {
        UILabel * lable = [[UILabel alloc]init];
        lable.tag = i;
        CGFloat btnW = 44;
        CGFloat btnLeft = 25;
        betWeenButton = ( [[UIScreen mainScreen] bounds].size.width - btnW * 4 - btnLeft * 2 )/(4 - 1);
        CGFloat btnH = 22;
        CGFloat btnX = 0;
        CGFloat btnY = 26;
        
        
        //添加lable
        NSArray * array = @[@"消息",@"工作",@"知识库",@"我的"];
        
        btnX = i * btnW + btnLeft + betWeenButton * i;
        int btnCenterX =  btnX + btnW / 2.0;
        [LableCenterX addObject:@(btnCenterX)];
        
        lable.frame = CGRectMake(btnX , btnY  , btnW, btnH);
        
        lable.text = (NSString *)array[i];
        lable.textAlignment = NSTextAlignmentCenter;
        lable.font = [UIFont systemFontOfSize:13];
        lable.tag = i;
        [self.arrayLable addObject:lable];
        [self addSubview:lable];
        
    }

}




// 提供一个方法给外界创建按钮
- (void)addTabBarButtonWithName:(NSString *)name selName:(NSString *)selName index:(int)index{
    CGFloat btnW = 26;
    CGFloat btnLeft = 25;
    
    betWeenButton = ( [[UIScreen mainScreen] bounds].size.width - btnW * 4 - btnLeft * 2 )/(4 - 1);
    
    CGFloat btnH = btnW;
    CGFloat btnX = 0;
    CGFloat btnY = 15;
        
    JRTabBarButton * button = [JRTabBarButton buttonWithType:UIButtonTypeCustom];
    
    btnX = index * btnW + btnLeft + betWeenButton * index;
    
    button.frame = CGRectMake(btnX, btnY, btnW, btnH);
    int buttonCenterX = [LableCenterX[index]intValue];
    button.center = CGPointMake(buttonCenterX, btnY);
    button.tag = index;
    
    //设置按钮的图片
    [button setBackgroundImage:[UIImage imageNamed:name] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:selName] forState:UIControlStateSelected];
    
    //监听按钮的点击
    [button addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchDown];
    
    if (index == 1) {
        [self btnClick:button];
    }
    
    [self addSubview:button];
    


}



//点击按钮的时候调用
- (void)btnClick:(UIButton*)button{
    _selectedButton.selected = NO;
    _lable.textColor = [UIColor blackColor];
    
    button.selected = YES;
    _selectedButton = button;
    

    //切换控制器
    if (_block) {
        _block((int)button.tag);
    }
    

    //改变lable的颜色
    UILabel * lable = self.arrayLable[button.tag];
    lable.textColor = [UIColor orangeColor];
    _lable = lable;
    
    

}


@end








