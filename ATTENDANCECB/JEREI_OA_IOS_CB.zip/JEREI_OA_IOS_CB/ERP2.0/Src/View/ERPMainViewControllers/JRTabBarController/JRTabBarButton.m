
//
//  JRTabBarButton.m
//  WYNews
//
//  Created by 李亚奇 on 15/6/25.
//  Copyright (c) 2015年 jereh. All rights reserved.
//

#import "JRTabBarButton.h"

@implementation JRTabBarButton

//取消系统的高亮的状态
- (void)setHighlighted:(BOOL)highlighted{

}

@end
