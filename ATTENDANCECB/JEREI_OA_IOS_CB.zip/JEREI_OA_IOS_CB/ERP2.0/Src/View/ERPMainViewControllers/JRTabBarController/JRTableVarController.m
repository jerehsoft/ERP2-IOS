//
//  JRTableVarController.m
//  WYNews
//
//  Created by 李亚奇 on 15/6/25.
//  Copyright (c) 2015年 jereh. All rights reserved.
//

#import "JRTableVarController.h"
#import "JRTabBar.h"

@interface JRTableVarController ()//<JRTabBarDelegate>

@end

@implementation JRTableVarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    //移除在带的TabBar
    [self.tabBar removeFromSuperview];
    
    //创建TabBar
    JRTabBar * tabBar = [[JRTabBar alloc]init];
    
    
    //定义一个block
    tabBar.block = ^(int selectIndex){
        self.selectedIndex = selectIndex;
    
    };
    
//    tabBar.delegate = self;
    [tabBar setBackgroundColor:[UIColor whiteColor]];
   
    tabBar.frame = self.tabBar.frame;
    
    [self.view addSubview:tabBar];
    
    NSString * imageName = nil;
    NSString * imageNameSelect = nil;

    
    for (int i = 0; i < self.childViewControllers.count; i++) {
        
        imageName = [NSString stringWithFormat:@"t%d",i];
        imageNameSelect = [NSString stringWithFormat:@"t%ds",i];
        
        //给底部的TabBar添加按钮
        [tabBar addTabBarButtonWithName:imageName selName:imageNameSelect index:i];
    }
    
}


@end
