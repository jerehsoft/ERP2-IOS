//
//  AlertPopViewController.m
//  ERP2.0
//
//  Created by jerei on 14-7-24.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "AlertPopViewController.h"

@interface AlertPopViewController ()
@property (strong, nonatomic) IBOutlet UIView *panel;
@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutlet UILabel *alertLabel;
@property (strong, nonatomic) IBOutlet UIImageView *labelIcon;
@property (strong, nonatomic) IBOutlet UIImageView *alertImg;

@end

@implementation AlertPopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    [self.view setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.4f]];
    self.panel.layer.cornerRadius = 10;
    //签到1签退2离司3回司4
    switch (_alertType) {
        case 1:{
            _titleLabel.text = _message?_message:@"签到成功";
            _alertLabel.text = @"喝杯咖啡开始工作吧";
            _labelIcon.image = [UIImage imageNamed:@"icon_coffee.png"];
            _alertImg.image = [UIImage imageNamed:@"icon_startwork.png"];
            break;
        }
        case 2:{
            _titleLabel.text = _message?_message:@"签退成功";
            _alertLabel.text = @"伸个懒腰下班啦";
            _labelIcon.image = [UIImage imageNamed:@"icon_smile.png"];
            _alertImg.image = [UIImage imageNamed:@"icon_stopwork.png"];
            break;
        }
        case 3:{
            _titleLabel.text = _message?_message:@"临时离司";
            _alertLabel.text = @"路上注意安全哦!";
            _labelIcon.image = [UIImage imageNamed:@"icon_smile.png"];
            _alertImg.image = [UIImage imageNamed:@"icon_leaveCompany.png"];
            break;
        }
        case 4:{
            _titleLabel.text = _message?_message:@"顺利回司";
            _alertLabel.text = @"喝杯咖啡开始工作吧";
            _labelIcon.image = [UIImage imageNamed:@"icon_coffee.png"];
            _alertImg.image = [UIImage imageNamed:@"icon_startwork.png"];
            break;
        }
        case 5:{
            _titleLabel.text = @"考勤失败";
            _alertLabel.text = _message?_message:@"服务器出错啦!";
            _labelIcon.image = [UIImage imageNamed:@"icon_coffee.png"];
            _alertImg.image = [UIImage imageNamed:@"icon_atten_error.png"];
            break;
        }
    }
}

- (IBAction)tapOnBackground:(id)sender {
    _blockForComplete();
}

@end
