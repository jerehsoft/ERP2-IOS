//
//  ERPWebRequest.h
//  ERP2.0
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//
//更新版本时注意检查LoginViewController里面的地址

#ifndef ERP_MAIN_SITE

#if DEBUG
#define ERP_MAIN_SITE_URL @"http://119.254.90.234:8883/"
#define ERP_MAIN_SITE_SERVLET_ADDR @"upload/"
#else
#define ERP_MAIN_SITE_URL @"http://119.254.90.234:8883/"
#define ERP_MAIN_SITE_SERVLET_ADDR @"upload/"
#endif

#define ERP_MAIN_SITE 1
#define BAIDU_MAP_KEY @"ZaNxaDvhL5ZTIYG03LLyQUZ6"

#endif

#import "Erp2.h"
#import "ArrayUtils.h"


typedef void (^ERPResponseBlock)(NSDictionary* responseData);

@interface ERPWebRequest : JSWebRequest

+ (ERPWebRequest *)mainSiteRequest;

- (void)requestDataWithRelativeURI:(NSString *)uri
                    withParams:(id)params
                   withHeaders:(NSDictionary *)headers
                successHandler:(ERPResponseBlock)successHandler
                  errorHandler:(MKNKResponseErrorBlock)errorHandler;

- (void)requestDataWithRelativeURI:(NSString *)uri
                    withMethod:(NSString *)method
                    withParams:(id)params
                   withHeaders:(NSDictionary *)headers
                successHandler:(ERPResponseBlock)successHandler
                  errorHandler:(MKNKResponseErrorBlock)errorHandler;

@end
