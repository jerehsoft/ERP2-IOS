//
//  ERPWebRequest.m
//  ERP2.0
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPWebRequest.h"



static ERPWebRequest *_mainRequest;

@implementation ERPWebRequest

+ (ERPWebRequest *)mainSiteRequest
{
    if (!_mainRequest) {
        _mainRequest = [[ERPWebRequest alloc] initWithBaseUrl:ERP_MAIN_SITE_URL];
    }
    return _mainRequest;
}

- (void)dealloc
{
    [self printDealloc];
}

- (void)requestDataWithRelativeURI:(NSString *)uri
                        withParams:(id)params
                       withHeaders:(NSDictionary *)headers
                    successHandler:(ERPResponseBlock)successHandler
                      errorHandler:(MKNKResponseErrorBlock)errorHandler
{
    [self requestDataWithRelativeURI:uri
                          withMethod:@"GET"
                          withParams:params
                         withHeaders:headers
                      successHandler:successHandler
                        errorHandler:errorHandler];
}

- (void)requestDataWithRelativeURI:(NSString *)uri
                        withMethod:(NSString *)method
                        withParams:(id)params
                       withHeaders:(NSDictionary *)headers
                    successHandler:(ERPResponseBlock)successHandler
                      errorHandler:(MKNKResponseErrorBlock)errorHandler
{
    NSMutableDictionary *h = [NSMutableDictionary dictionaryWithDictionary:headers];
    
    [h setValue:[NSNumber numberWithLong:[[ERPAuthContext getUser] userId]] forKey:@"userId"];
    [h setValue:[NSNumber numberWithLong:[[ERPAuthContext getUser] userId]] forKey:@"mbrId"];
    [self requestWithRelativeURI:uri
                      withMethod:method
                      withParams:params
                     withHeaders:h
                  successHandler:^(MKNetworkOperation *completedOperation) {
                      id responseJson = completedOperation.responseJSON;
                      ERPError *err = nil;
                      if (!responseJson) {
                          // 再次检查服务器返回消息是否json
                          NSData *responseData = completedOperation.responseData;
                          if (responseData && responseData.length) {
                              err = [ERPError makeError:ERPWebRequestError_ResponseNotJSON];
                          }
                      }
                      else {
                          err = [ERPWebRequest checkActionResult:responseJson];
                      }
                      if (err) {
                          if (errorHandler)
                              errorHandler(completedOperation, err);
                      } else {
                          if (successHandler)
                              successHandler((NSDictionary *)responseJson);
                          else
                              NSLog(@"ERPWebRequest:未提供successHandler");
                      }
                  }
                    errorHandler:errorHandler];
}

+ (ERPError *)checkActionResult:(NSDictionary *)responseDict
{
    ERPError *error = nil;
    if (!responseDict) {
        // 没有消息
        error = [ERPError makeError:ERPWebRequestError_EmptyResponse];
    }
    else if (![responseDict isKindOfClass:[NSDictionary class]]) {
        // 消息非dictionary
        error = [ERPError makeError:ERPWebRequestError_ResponseNotADictionary];
    }
    else {
        // TODO 将所有消息组合到一起分组显示
        // 目前是只选择其中一部分显示，忽略掉其他，优先级：fieldErrors > actionErrors > actionErrorMessages
        NSArray *fieldErrors = nil, *actionErrors = nil, *actionErrorMessages = nil;
        id errorMessages;
        
        // 检查fieldErrors
        errorMessages = [responseDict valueForKey:@"fieldErrors"];
        if (![ObjectUtils isNilOrNull:errorMessages]) {
            // 转换fieldErrors为array，拼接字段验证消息
            if ([errorMessages isKindOfClass:[NSDictionary class]]) {
                NSDictionary *fieldErrorDict = (NSDictionary *)errorMessages;
                NSMutableArray *_fieldErrors = [NSMutableArray arrayWithCapacity:fieldErrorDict.count];
                for (NSString *field in fieldErrorDict) {
                    // 转换为字段验证消息
                    ERPFieldErrorMessage *fieldError = [[ERPFieldErrorMessage alloc] init];
                    fieldError.field = field;
                    // 消息明细
                    NSArray *fieldErrorMessages = (NSArray *)[fieldErrorDict valueForKey:field];
                    if (![ObjectUtils isNilOrNull:fieldErrorMessages] && fieldErrorMessages.count) {
                        fieldError.message = [fieldErrorMessages stringJoinedBy:@","];
                    }
                    else {
                        NSLog(@"字段'%@'的验证消息没有内容", field);
                    }
                    [_fieldErrors addObject:fieldError];
                }
                fieldErrors = _fieldErrors;
            }
            else {
                // fieldErrors格式无效
                NSLog(@"fieldErrors格式无效，应该是一个字典");
            }
            
            if (fieldErrors && fieldErrors.count) {
                NSString *msg = [fieldErrors stringJoinedBy:@"," ofKeyPath:@"message"];
                error = [ERPError makeError:ERPWebRequestError_FieldError
                                description:msg];
                return error;
            }
        }
        
        // 检查actionErrors
        errorMessages = [responseDict valueForKey:@"actionErrors"];
        if (![ObjectUtils isNilOrNull:errorMessages]) {
            if ([errorMessages isKindOfClass:[NSArray class]]) {
                actionErrors = (NSArray *)errorMessages;
            }
            else {
                // actionErrors格式无效
                NSLog(@"actionErrors格式无效，应该是一个字典");
            }
            
            if (actionErrors && actionErrors.count) {
                NSString *msg = [actionErrors stringJoinedBy:@","];
                error = [ERPError makeError:ERPWebRequestError_ActionError
                                description:msg];
                return error;
            }
        }
        
        
        // 检查actionErrorMessages
        errorMessages = [responseDict valueForKey:@"actionErrorMessages"];
        if (![ObjectUtils isNilOrNull:errorMessages]) {
            if ([errorMessages isKindOfClass:[NSArray class]]) {
                actionErrorMessages = (NSArray *)errorMessages;
            }
            else {
                // actionErrorMessages格式无效
                NSLog(@"actionErrorMessages格式无效，应该是一个字典");
            }

            if (actionErrorMessages && actionErrorMessages.count) {
                NSString *msg = [actionErrorMessages stringJoinedBy:@","];
                error = [ERPError makeError:ERPWebRequestError_ActionErrorMessage
                                description:msg];
                return error;
            }
        }
        
        // 检查actionErrorMessages
        errorMessages = [responseDict valueForKey:@"errors"];
        if (![ObjectUtils isNilOrNull:errorMessages]) {
            if ([errorMessages isKindOfClass:[NSArray class]]) {
                actionErrorMessages = (NSArray *)errorMessages;
            }
            else {
                // actionErrorMessages格式无效
                NSLog(@"errors格式无效，应该是一个字典");
            }
            
            if (actionErrorMessages && actionErrorMessages.count) {
                NSString *msg = [actionErrorMessages stringJoinedBy:@","];
                error = [ERPError makeError:ERPWebRequestError_ActionErrorMessage
                                description:msg];
                return error;
            }
        }
        
    }
    return error;
}
@end
