//
//  ERPDataCache.m
//  ERP2.0
//
//  Created by jerei on 14-8-18.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPDataCache.h"


@implementation ERPColumn
@end

#pragma mark Column辅助函数
ERPColumn *ERPMakeColumn(NSString *name, NSString *type, BOOL pk, BOOL nullable, BOOL unique, NSString *defaultVal)
{
    ERPColumn *col = [[ERPColumn alloc] init];
    col.name = name;
    col.type = type;
    col.pk = pk;
    col.nullable = nullable;
    col.unique = unique;
    if (![ObjectUtils isNilOrNull:defaultVal]) {
        col.defaultVal = [NSString stringWithFormat:@"'%@'", [[defaultVal description] stringByReplacingOccurrencesOfString:@"'" withString:@"''"]];
    }
    return col;
}
ERPColumn *ERPMakeTextColumn(NSString *name, BOOL pk, BOOL nullable, BOOL unique, NSString *defaultVal)
{
    return ERPMakeColumn(name, @"TEXT", pk, nullable, unique, defaultVal);
}
ERPColumn *ERPMakeCommonTextColumn(NSString *name, BOOL nullable)
{
    return ERPMakeColumn(name, @"TEXT", NO, nullable, NO, nil);
}
ERPColumn *ERPMakeIntColumn(NSString *name, BOOL pk, BOOL nullable, BOOL unique, NSNumber *defaultVal)
{
    return ERPMakeColumn(name, @"INTEGER", pk, nullable, unique, [defaultVal stringValue]);
}
ERPColumn *ERPMakeCommonIntColumn(NSString *name, BOOL nullable)
{
    return ERPMakeColumn(name, @"INTEGER", NO, nullable, NO, 0);
}
ERPColumn *ERPMakeRealColumn(NSString *name, BOOL pk, BOOL nullable, BOOL unique, NSNumber *defaultVal)
{
    return ERPMakeColumn(name, @"REAL", pk, nullable, unique, [defaultVal stringValue]);
}
ERPColumn *ERPMakeCommonRealColumn(NSString *name, BOOL nullable)
{
    return ERPMakeColumn(name, @"REAL", NO, nullable, NO, 0);
}
ERPColumn *ERPMakeDateColumn(NSString *name, BOOL pk, BOOL nullable, BOOL unique, NSDate *date)
{
    return ERPMakeColumn(name, @"TEXT", pk, nullable, unique, [date stringWithDefaultFormat]);
}
ERPColumn *ERPMakeCommonDateColumn(NSString *name, BOOL nullable)
{
    return ERPMakeColumn(name, @"TEXT", NO, nullable, NO, nil);
}
// 检查列定义是否匹配
BOOL ERPColumnMatchesSchema(ERPColumn *col, NSString *name, NSString *type, BOOL pk, BOOL nullable, NSString *defaultVal)
{
    BOOL matches = col
    && [col.name isEqualToString:name]
    && [col.type isEqualToString:type]
    && col.pk == pk
    && col.nullable == nullable
    && (
        ([ObjectUtils isNilOrNull:col.defaultVal] && [ObjectUtils isNilOrNull:defaultVal]) ||
        [col.defaultVal isEqualToString:defaultVal]
        );
    return matches;
}
// 生成建表语句
NSString *ERPMakeTableDefSql(NSString *tableName, NSArray *columns)
{
    NSMutableString *def = [NSMutableString stringWithCapacity:128];
    [def appendString:@"CREATE TABLE IF NOT EXISTS "];
    [def appendString:tableName];
    [def appendString:@" ("];
    for (ERPColumn *col in columns) {
        [def appendFormat:@"%@ %@", col.name, col.type];
        if (col.pk)
            [def appendString:@" PRIMARY KEY"];
        if (!col.nullable)
            [def appendString:@" NOT NULL"];
        if (col.unique)
            [def appendString:@" UNIQUE"];
        if (![ObjectUtils isNilOrNull:col.defaultVal])
            [def appendFormat:@" DEFAULT %@", col.defaultVal];
        [def appendString:@", "];
    }
    if (columns.count) {
        [def deleteCharactersInRange:NSMakeRange(def.length - 2, 2)];
    }
    [def appendString:@")"];
    
    return def;
}




@implementation ERPDataCache

#pragma mark 数据库连接
static NSString *__dbPath;
+ (NSString *)_dbPath
{
    if (!__dbPath) {
        NSArray *folders = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        __dbPath = [NSString stringWithFormat:@"%@/erp2.db", folders[0]];
    }
    return __dbPath;
}

+ (FMDatabaseQueue *)_dbQueue
{
    FMDatabaseQueue *queue = [FMDatabaseQueue databaseQueueWithPath:[ERPDataCache _dbPath]];
    [queue inDatabase:^(FMDatabase *db) {
        [ERPDataCache _setupDbFormat:db];
    }];
    return queue;
}

+ (FMDatabase *)_db
{
    FMDatabase *db = [FMDatabase databaseWithPath:[ERPDataCache _dbPath]];
    [ERPDataCache _setupDbFormat:db];
    [db open];
    return db;
}

+ (void)_setupDbFormat:(FMDatabase *)db
{
    // 为text日期列指定格式 yyyy-MM-dd HH:mm:ss.SSS
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    dateFormat.dateFormat = DATEUTILS_DATE_TIME_FORMAT_WITH_MILLIS;
    dateFormat.timeZone = [ERPDefaults defaultTimeZone];
    dateFormat.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    db.dateFormat = dateFormat;
}

#pragma mark 初始化
+ (NSArray *)_dbSchema
{
    // 1. 表名
    // 2. 列定义s
    // 3. 初始化语句s
    return @[
             @[ @"LOGIN_USER", @[
                    ERPMakeIntColumn(@"USER_ID", YES, NO, YES, 0),
                    ERPMakeCommonTextColumn(@"USER_NO", YES),
                    ERPMakeCommonTextColumn(@"USER_NAME", YES),
                    ERPMakeCommonTextColumn(@"PWD", YES)
                    ]]
             ];
}

+ (void)_prepareTableWithName:(NSString *)tableName columns:(NSArray *)columns initSqls:(NSArray *)initSqls inDatabase:(FMDatabase *)db
{
    BOOL tableExists = [db tableExists:tableName];
    if (tableExists) {
        BOOL schemaMatches = YES;
        
        NSDictionary *colDict = [NSMutableDictionary dictionaryWithCapacity:columns.count];
        for (ERPColumn *col in columns) {
            [colDict setValue:col forKey:col.name];
        }
        // 如果存在表，则检查结构
        NSLog(@"检查表结构%@", tableName);
        FMResultSet *rs = [db getTableSchema:tableName];
        int columnsChecked = 0;
        while (rs.next) {
            NSString *colName = [rs stringForColumn:@"name"];
            NSString *colType = [rs stringForColumn:@"type"];
            BOOL colNullable = ![rs boolForColumn:@"notnull"];
            NSString *colDefault = [rs stringForColumn:@"dflt_value"];
            BOOL colPk = [rs boolForColumn:@"pk"];
            
            ERPColumn *col = [colDict valueForKey:colName];
            if (!col || !ERPColumnMatchesSchema(col, colName, colType, colPk, colNullable, colDefault)) {
                schemaMatches = NO;
                break;
            }
            ++columnsChecked;
        }
        if (schemaMatches && columnsChecked < columns.count) {
            // 缺少列
            schemaMatches = NO;
        }
        [rs close];
        // 如果结构不符合定义则删除表
        if (!schemaMatches) {
            NSLog(@"表%@结构已更改，将被删除", tableName);
            NSString *sqlDropTable = [NSString stringWithFormat:@"DROP TABLE %@", tableName];
            [db executeUpdate:sqlDropTable];
            tableExists = NO;
        }
    }
    
    if (!tableExists) {
        NSString *tableDefSql = ERPMakeTableDefSql(tableName, columns);
        NSLog(@"创建表%@, sql = %@", tableName, tableDefSql);
        // 如果不存在表则创建
        [db executeUpdate:tableDefSql];
        
        // 初始化表
        if (initSqls) {
            for (NSString *initSql in initSqls) {
                [db executeUpdate:initSql];
            }
        }
    }
}

// 准备数据库，创建表和系统数据
+ (void)prepare:(JSProgressBlock)progressCallback errorCallback:(JSErrorBlock)errorCallback
{
    NSLog(@"准备数据库");
    FMDatabaseQueue *queue = [ERPDataCache _dbQueue];
    @try {
        [queue inDatabase:^(FMDatabase *db) {
            NSArray *schema = [ERPDataCache _dbSchema];
            int tablesChecked = 0;
            for (NSArray *table in schema) {
                if (progressCallback)
                    progressCallback((tablesChecked++) * 1.0f / schema.count);
                NSString *tableName = (NSString *)table[0];
                NSArray *columns = (NSArray *)table[1];
                NSArray *initSqls = table.count > 2 ? (NSArray *)table[2] : nil;
                [ERPDataCache _prepareTableWithName:tableName columns:columns initSqls:initSqls inDatabase:db];
            }
            NSLog(@"数据库准备完成");
            progressCallback(1.0f);
        }];
    }
    @catch (NSException *ex) {
        // 如果提供了errorCallback则将异常信息发给callback处理
        if (errorCallback) {
            ERPError *err = [ERPError makeError:ERPDbError_CannotInitialize description:ex.reason failureReason:ex.reason];
            errorCallback(err);
        }
        else {
            [ex raise];
        }
    }
    @finally {
        [queue close];
    }
}

+ (void)clear
{
    NSLog(@"清空本地数据库");
    FMDatabase *db = [ERPDataCache _db];
    @try {
        NSArray *tables = [ERPDataCache _dbSchema];
        for (NSArray *table in tables) {
            NSString *sqlDropTable = [NSString stringWithFormat:@"DROP TABLE %@", table[0]];
            [db executeUpdate:sqlDropTable];
        }
    }
    @finally {
        [db close];
    }
}

static NSMutableDictionary *codeMap;

+ (void)clearCodeDetailsInMemory
{
    if (codeMap) {
        [codeMap removeAllObjects];
    }
}

+ (void)saveLoginUser:(NSString *)uid userNo:(NSString *)userNo userName:(NSString *)userName password:(NSString *)pwd complete:(void(^)())complete error:(void(^)())error{
    if (!uid || [uid intValue] <= 0) {
        return;
    }
    static NSString *insertSql = @"INSERT INTO LOGIN_USER (USER_ID, USER_NO, USER_NAME, PWD) VALUES (?, ?, ?, ?)";
    NSLog(@"写入数据");
    FMDatabaseQueue *queue = [ERPDataCache _dbQueue];
    @try {
        [queue inTransaction:^(FMDatabase *db, BOOL *rollback) {
            // 清空code
            [db executeUpdate:@"DELETE FROM LOGIN_USER"];
            // 写入code
            [db executeUpdate:insertSql,uid,userNo,userName,pwd];
            NSLog(@"数据写入完成");
        }];
        [queue close];
        if (complete) {
            complete();
        }
    } @catch (NSException *ex) {
        NSLog(@"数据写入异常 : %@",[ex description]);
        if (error) {
            error();
        }
        [ex raise];
    } @finally {
        [queue close];
    }
}
+ (NSMutableDictionary *)getLoginUser {
    FMDatabase *db = [ERPDataCache _db];
    NSMutableDictionary *loginUser = [[NSMutableDictionary alloc] init];
    @try {
        NSString *sql =[NSString stringWithFormat:@"%@",@"SELECT * FROM LOGIN_USER"];
        FMResultSet *rs = [db executeQuery:sql];
        if (rs.next) {
            [loginUser setValue:[rs stringForColumn:@"USER_ID"] forKey:@"userId"];
            [loginUser setValue:[rs stringForColumn:@"USER_NO"] forKey:@"userNo"];
            [loginUser setValue:[rs stringForColumn:@"USER_NAME"] forKey:@"userName"];
            [loginUser setValue:[rs stringForColumn:@"PWD"] forKey:@"pwd"];
        }
        [rs close];
    } @catch (NSException *ex) {
        NSLog(@"数据查询异常 : %@",[ex description]);
    } @finally {
        [db close];
    }
    return loginUser;
}

@end


@implementation BaseCodeDetail
@end
