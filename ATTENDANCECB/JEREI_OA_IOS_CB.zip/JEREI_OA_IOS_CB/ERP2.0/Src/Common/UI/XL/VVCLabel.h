//
//  VVCLabel.h
//  XLForm
//
//  Created by jerei on 14/12/18.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLFormBaseCell.h"

@interface VVCLabel : UILabel
@property NSString *valueKey;
@property (weak) XLFormBaseCell *cellView;
@property BOOL singleValue;

+(void)bindTextFiled:(VVCLabel *)Label cellView:(XLFormBaseCell *)cellView;

+(void)autoBindLabelOnView:(XLFormBaseCell *)cell;
@end
