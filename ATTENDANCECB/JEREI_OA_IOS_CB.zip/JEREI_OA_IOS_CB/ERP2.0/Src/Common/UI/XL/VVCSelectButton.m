//
//  VVCSelectButton.m
//  XLForm
//
//  Created by jerei on 14/12/16.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//

#import "VVCSelectButton.h"
#import "VVCButtonOptionsViewController.h"
#import <UIKit/UIKit.h>
#import "XLFormOptionsObject.h"
#import "NSObject+XLFormAdditions.h"

@interface VVCSelectButton() <UIPopoverControllerDelegate>
@property (nonatomic) UIPopoverController *popoverController;

@end

@implementation VVCSelectButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(id)valueForUndefinedKey:(NSString *)key{
    return nil;
}

-(void)popOptions{
    NSArray *options = nil;
    if(self.optionsKey){
        options = [self.cellView.rowDescriptor.cellConfigAtConfigure valueForKeyPath:self.optionsKey];
    }
    
    options = options ?: self.cellView.rowDescriptor.selectorOptions;
    
    XLFormOptionsViewController *opts = nil;
    
    if(self.singleValue){
        opts = [[XLFormOptionsViewController alloc] initWithOptions:options style:UITableViewStyleGrouped];
    }else{
        VVCButtonOptionsViewController *optionsViewController = [[VVCButtonOptionsViewController alloc] initWithOptions:options style:UITableViewStyleGrouped];
        optionsViewController.valueKey = self.valueKey;
        optionsViewController.customValue = self.customValue;
        opts = optionsViewController;
    }
    
    opts.rowDescriptor = self.cellView.rowDescriptor;
    opts.title = self.cellView.rowDescriptor.selectorTitle;
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        //popover (only for ipad)
        self.popoverController = [[UIPopoverController alloc] initWithContentViewController:opts];
        self.popoverController.delegate = self.popDelegate ?: self;
        opts.popoverController = self.popoverController;
        NSLog(@"\n%f,%f\n",self.popSize.height,self.popSize.width);
        if(self.popSize.height > 0 && self.popSize.width >0) {
            self.popoverController.popoverContentSize = self.popSize;
        }
        [self.popoverController presentPopoverFromRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height) inView:self permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    } else {
        //push (for iphone)
        if (self.cellView.formViewController) {
            [self.cellView.formViewController.navigationController pushViewController:opts animated:YES];
        }
    }
    
}

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController
{
    [self.cellView.formViewController reloadFormRow:self.cellView.rowDescriptor];
}


+(void)bindButton:(VVCSelectButton *)button cellView:(XLFormBaseCell *)cell popDelegate:(id<UIPopoverControllerDelegate>)delegate{


    if(button.valueKey == nil && !button.singleValue)
        return;
    
    button.cellView = cell;
    id titleText = nil;
    
    if(button.singleValue){
        titleText = cell.rowDescriptor.value;
    }else
        titleText = [cell.rowDescriptor.value valueForKey:button.valueKey] ;
    
    
    if([titleText isKindOfClass:[XLFormOptionsObject class]]){
        titleText = [titleText formDisplayText];
    }
    titleText = [VVCSelectButton selectorValue:titleText button:button];
    if(button.suffix){
        titleText = [NSString stringWithFormat:@"%@%@",titleText,button.suffix];
    }
    if(![titleText isKindOfClass:[NSString class]]){
        titleText = [titleText stringValue];
    }
    [button setTitle:titleText forState:UIControlStateNormal];
    [button addTarget:button action:@selector(popOptions) forControlEvents:UIControlEventTouchUpInside];
    
    if((!titleText || [[self trimString:titleText] isEqualToString:@""]) && button.rightholder){
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        button.contentEdgeInsets = UIEdgeInsetsMake(2, 0, 0, 10);
        [button setTitle:button.rightholder forState:UIControlStateNormal];
        [button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    } else if(button.rightholder) {
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        button.contentEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
        [button setTitleColor:[button tintColor] forState:UIControlStateNormal];
    }
    
    if((!titleText || [[self trimString:titleText] isEqualToString:@""]) && button.placeholder){
        if (button.contentHorizontalAlignment == UIControlContentHorizontalAlignmentCenter) {
            [button setTitle:button.placeholder forState:UIControlStateNormal];
        } else {
            [button setTitle:[@"  " stringByAppendingString:button.placeholder] forState:UIControlStateNormal];
        }
        [button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    } else if(button.placeholder) {
        [button setTitleColor:[button tintColor] forState:UIControlStateNormal];
    }
    
    if(button.isBorder) {
        button.layer.borderWidth = 1;
        button.layer.cornerRadius = 5;
        button.layer.borderColor = [[UIColor colorWithRed:224/255.0 green:224/255.0 blue:224/255.0 alpha:1] CGColor];
        button.layer.backgroundColor = [[UIColor whiteColor] CGColor];
        if(titleText && ![[self trimString:titleText] isEqualToString:@""]) {
            if (button.contentHorizontalAlignment == UIControlContentHorizontalAlignmentCenter) {
                [button setTitle:titleText forState:UIControlStateNormal];
            } else {
                [button setTitle:[@"  " stringByAppendingString:titleText] forState:UIControlStateNormal];
            }
        }
    } else if (button.isRedBorder) {
        button.layer.borderWidth = 1;
        button.layer.cornerRadius = 7;
        button.layer.borderColor = [[UIColor colorWithRed:1 green:0 blue:0 alpha:0.4] CGColor];
    }
    
    if(delegate)
        button.popDelegate = delegate;
}

+(NSString *)trimString:(NSString *)inputStr {
    return [inputStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

+(id)selectorValue:(id)value button:(VVCSelectButton *)button{
    NSArray *options = nil;
    NSString *optionsKey = button.optionsKey;
    if(optionsKey){
        options = [button.cellView.rowDescriptor.cellConfigAtConfigure valueForKeyPath:optionsKey];
    }
    
    options = options ?: button.cellView.rowDescriptor.selectorOptions;
    
    if(options.count > 0){
        for(id obj in options){
            if([obj isKindOfClass:[XLFormOptionsObject class]]){
                if([value isEqual:[obj formValue]]){
                    value = [obj formDisplayText];
                }
            }
        }
    }
    return value;
    
}

+(void)autoBindButtonsOnView:(XLFormBaseCell *)cell{
    NSMutableArray *buttons = [[NSMutableArray alloc]init];
    NSDictionary *delegates = [cell.rowDescriptor.cellConfigAtConfigure valueForKeyPath:@"popDelegates"];
    
    [VVCSelectButton findVVCSelectButtons:cell buttons:buttons];
    for(VVCSelectButton *button in buttons){
        id<UIPopoverControllerDelegate> del = nil;
        NSString *delegateKey = [button valueForKey:@"delegateKey"];
        if(delegateKey && delegates){
            del = [delegates valueForKey:delegateKey];
        }
        [VVCSelectButton bindButton:button cellView:cell popDelegate:del];
            
    }
}




+(void)findVVCSelectButtons:(UIView *)uiView buttons:(NSMutableArray *)buttons{
    for(UIView *view in uiView.subviews){
        if([view isKindOfClass:[VVCSelectButton class]]){
            [buttons addObject:view];
        }else{
            [VVCSelectButton findVVCSelectButtons:view buttons:buttons];
        }
    }
}

@end
