//
//  VVCTextView.m
//  VolvoChecklist
//
//  Created by jerei on 15/1/7.
//  Copyright (c) 2015年 jerehsoft. All rights reserved.
//

#import "VVCTextView.h"

@implementation VVCTextView


- (void)textViewDidEndEditing:(UITextView *)textView{
    id value = textView.text;
    
    if(self.singleValue)
        self.cellView.rowDescriptor.value = value;
    else
        [self.cellView.rowDescriptor.value setValue:value forKey:self.valueKey];
    
    if((!value || [value isEqualToString:@""]) && self.placeholder){
        textView.text = self.placeholder;
        [textView setTextColor:[UIColor lightGrayColor]];
    }
}

-(void)textViewDidBeginEditing:(UITextView *)textView{
    [textView setTextColor:[self tintColor]];
    if (self.placeholder && [textView.text isEqualToString:self.placeholder]) {
        textView.text = nil;
    }
}

//- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
//    NSMutableString *currentText =[[NSMutableString alloc] initWithString:textView.text];
//    if(text.length > 0) {
//        [currentText appendString:text];
//    } else if (range.length > 0) {
//        currentText = [NSMutableString stringWithFormat:@"%@",[currentText substringWithRange:NSMakeRange(0, range.location)]];
//    }
//    NSRange subRange = [currentText rangeOfString:@"\n"];
//    int newLineCount = 0;
//    while (subRange.location != NSNotFound) {
//        [currentText replaceCharactersInRange:subRange withString:@""];
//        subRange = [currentText rangeOfString:@"\n"];
//        newLineCount ++;
//    }
//    currentText = nil;
//    if(newLineCount >= 2){
//        [textView setReturnKeyType:UIReturnKeyDone];
//        [textView resignFirstResponder];
//        [textView becomeFirstResponder];
//    } else {
//        [textView setReturnKeyType:UIReturnKeyDefault];
//        [textView resignFirstResponder];
//        [textView becomeFirstResponder];
//    }
//    if ([text isEqualToString:@"\n"] && newLineCount >= 3) {
//        [textView resignFirstResponder];
//        return NO;
//    }
//    return YES;
//}

+(void)bindTextFiled:(VVCTextView *)textField cellView:(XLFormBaseCell *)cellView{
    if(textField.valueKey == nil && !textField.singleValue)
        return;
    
    id value = nil;
    
    if(textField.singleValue)
        value = cellView.rowDescriptor.value;
    else
        value = [cellView.rowDescriptor.value valueForKey:textField.valueKey];
    
    id<UITextViewDelegate> obj = [cellView.rowDescriptor.cellConfigAtConfigure valueForKey:@"textDelegate"];
    
    if(obj){
        textField.delegate = obj;
    }else{
        textField.delegate = textField;
    }
    
    textField.cellView = cellView;
    
    if(textField.isBorder) {
        textField.layer.borderWidth = 1;
        textField.layer.cornerRadius = 7;
        textField.layer.borderColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.2] CGColor];
    }
    
    if(![value isKindOfClass:[NSString class]]){
        value = [value stringValue];
    }
    if(value) {
        textField.text = value;
    }
    
    if((!value || [value isEqualToString:@""]) && textField.placeholder){
        textField.text = textField.placeholder;
        [textField setTextColor:[UIColor lightGrayColor]];
    }
}

+(void)autoBindTextFieldOnView:(XLFormBaseCell *)cell{
    NSMutableArray *fields = [[NSMutableArray alloc]init];
    
    [VVCTextView findVVCTextField:cell fields:fields];
    for(VVCTextView *field in fields){
        [VVCTextView bindTextFiled:field cellView:cell];
    }
}

+(void)findVVCTextField:(UIView *)uiView fields:(NSMutableArray *)fields{
    for(UIView *view in uiView.subviews){
        if([view isKindOfClass:[VVCTextView class]]){
            [fields addObject:view];
        }else{
            [VVCTextView findVVCTextField:view fields:fields];
        }
    }
}

@end
