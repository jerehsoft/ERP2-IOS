//
//  VVCButtonOptionsViewController.m
//  XLForm
//
//  Created by jerei on 14/12/16.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//


#import "NSObject+XLFormAdditions.h"
#import "VVCButtonOptionsViewController.h"
#import "XLFormRightDetailCell.h"
#import "XLForm.h"
#import "NSObject+XLFormAdditions.h"
#import "NSArray+XLFormAdditions.h"

#define CELL_REUSE_IDENTIFIER2  @"OptionCell"

@interface VVCButtonOptionsViewController()<UITextFieldDelegate>

@property NSArray * options;
@property NSString * titleHeaderSection;
@property NSString * titleFooterSection;
@end

@implementation VVCButtonOptionsViewController

@synthesize titleHeaderSection = _titleHeaderSection;
@synthesize titleFooterSection = _titleFooterSection;
@synthesize rowDescriptor = _rowDescriptor;
@synthesize popoverController = __popoverController;
@synthesize options = _options;

- (id)initWithOptions:(NSArray *)options style:(UITableViewStyle)style
{

    return [self initWithOptions:options style:style titleHeaderSection:nil titleFooterSection:nil];
}

- (id)initWithOptions:(NSArray *)options style:(UITableViewStyle)style titleHeaderSection:(NSString *)titleHeaderSection titleFooterSection:(NSString *)titleFooterSection
{
    self = [super initWithStyle:style];
    if (self) {
        self.options = options;
        self.titleFooterSection = titleFooterSection;
        self.titleHeaderSection = titleHeaderSection;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // register option cell
    [self.tableView registerClass:[XLFormRightDetailCell class] forCellReuseIdentifier:CELL_REUSE_IDENTIFIER2];
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    if(self.customValue)
        return 2;
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section == 1)
        return 1;
    return [self.options count];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if(textField.text.length == 0)
        return NO;
    
    [self.rowDescriptor.value setValue:textField.text forKey:self.valueKey];
    [textField resignFirstResponder];
    if (self.popoverController){
        [self.popoverController dismissPopoverAnimated:YES];
        [self.popoverController.delegate popoverControllerDidDismissPopover:self.popoverController];
    }
    return NO;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    XLFormRightDetailCell * cell = [tableView dequeueReusableCellWithIdentifier:CELL_REUSE_IDENTIFIER2 forIndexPath:indexPath];
    if(indexPath.section == 1){
        

        if(indexPath.row == 0){
            UITextField *field = [[UITextField alloc]initWithFrame:CGRectMake(15, 7, 290, 30)];
            field.placeholder = @"Other";
            field.delegate = self;
            [cell.contentView addSubview:field];
            return cell;
        }
        
    }

    id cellObject =  [self.options objectAtIndex:indexPath.row];
    cell.textLabel.text = [self valueDisplayTextForOption:cellObject];
    if ([self.rowDescriptor.rowType isEqualToString:XLFormRowDescriptorTypeMultipleSelector] || [self.rowDescriptor.rowType isEqualToString:XLFormRowDescriptorTypeMultipleSelectorPopover]){
        cell.accessoryType = ([self selectedValuesContainsOption:cellObject] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone);
    }
    else{
        if ([[[self.rowDescriptor.value valueForKey:self.valueKey] valueData] isEqual:[cellObject valueData]]){
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        else{
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
    }
    return cell;
}


- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
    return self.titleFooterSection;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return self.titleHeaderSection;
}

#pragma mark - UITableViewDelegate


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 1){
        [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
        return;
    }
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    id cellObject =  [self.options objectAtIndex:indexPath.row];
    if ([self.rowDescriptor.rowType isEqualToString:XLFormRowDescriptorTypeMultipleSelector] || [self.rowDescriptor.rowType isEqualToString:XLFormRowDescriptorTypeMultipleSelectorPopover]){
        if ([self selectedValuesContainsOption:cellObject]){
            [self.rowDescriptor.value setValue:[self selectedValuesRemoveOption:cellObject] forKey:self.valueKey];
//            [self.rowDescriptor.value valueForKey:self.valueKey] = [self selectedValuesRemoveOption:cellObject];
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        else{
//            [self.rowDescriptor.value valueForKey:self.valueKey] = [self selectedValuesAddOption:cellObject];
            [self.rowDescriptor.value setValue:[self selectedValuesRemoveOption:cellObject] forKey:self.valueKey];
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    }
    else{
        if ([[[self.rowDescriptor.value valueForKey:self.valueKey] valueData] isEqual:[cellObject valueData]]){
            if (!self.rowDescriptor.required){
//                [self.rowDescriptor.value valueForKey:self.valueKey] = nil;
                [self.rowDescriptor.value setValue:@"" forKey:self.valueKey];
            }
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        else{
            if ([self.rowDescriptor.value valueForKey:self.valueKey]){
                NSInteger index = [self.options formIndexForItem:[self.rowDescriptor.value valueForKey:self.valueKey]];
                if (index != NSNotFound){
                    NSIndexPath * oldSelectedIndexPath = [NSIndexPath indexPathForRow:index inSection:0];
                    UITableViewCell *oldSelectedCell = [tableView cellForRowAtIndexPath:oldSelectedIndexPath];
                    oldSelectedCell.accessoryType = UITableViewCellAccessoryNone;
                }
            }
            [self.rowDescriptor.value setValue:cellObject forKey:self.valueKey];
//            [self.rowDescriptor.value valueForKey:self.valueKey] = cellObject;
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        if (self.popoverController){
            [self.popoverController dismissPopoverAnimated:YES];
            [self.popoverController.delegate popoverControllerDidDismissPopover:self.popoverController];
        }
        else if ([self.parentViewController isKindOfClass:[UINavigationController class]]){
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Helper

-(NSMutableArray *)selectedValues
{
    if ([self.rowDescriptor.value valueForKey:self.valueKey] == nil){
        return [NSMutableArray array];
    }
    NSAssert([[self.rowDescriptor.value valueForKey:self.valueKey] isKindOfClass:[NSArray class]], @"XLFormRowDescriptor value must be NSMutableArray");
    return [NSMutableArray arrayWithArray:[self.rowDescriptor.value valueForKey:self.valueKey]];
}

-(BOOL)selectedValuesContainsOption:(id)option
{
    return ([self.selectedValues formIndexForItem:option] != NSNotFound);
}

-(NSMutableArray *)selectedValuesRemoveOption:(id)option
{
    for (id selectedValueItem in self.selectedValues) {
        if ([[selectedValueItem valueData] isEqual:[option valueData]]){
            NSMutableArray * result = self.selectedValues;
            [result removeObject:selectedValueItem];
            return result;
        }
    }
    return self.selectedValues;
}

-(NSMutableArray *)selectedValuesAddOption:(id)option
{
    NSAssert([self.selectedValues formIndexForItem:option] == NSNotFound, @"XLFormRowDescriptor value must not contain the option");
    NSMutableArray * result = self.selectedValues;
    [result addObject:option];
    return result;
}



-(NSString *)valueDisplayTextForOption:(id)option
{
    if (self.rowDescriptor.valueTransformer){
        NSAssert([self.rowDescriptor.valueTransformer isSubclassOfClass:[NSValueTransformer class]], @"valueTransformer is not a subclass of NSValueTransformer");
        NSValueTransformer * valueTransformer = [self.rowDescriptor.valueTransformer new];
        NSString * transformedValue = [valueTransformer transformedValue:option];
        if (transformedValue){
            return transformedValue;
        }
    }
    return [option displayText];
}



@end
