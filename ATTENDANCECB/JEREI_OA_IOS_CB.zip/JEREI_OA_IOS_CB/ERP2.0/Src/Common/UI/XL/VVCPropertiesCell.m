//
//  VVCIQLPPMainBandsCell.m
//  XLForm
//
//  Created by jerei on 14/12/16.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//

#import "VVCPropertiesCell.h"
#import "VVCButtonOptionsViewController.h"
#import "VVCSwitch.h"
#import "VVCTextView.h"



@implementation VVCPropertiesCell




-(void)configure{
    
    
}


-(void)update{
    
    
    if(self.rowDescriptor.value == nil && !self.singleValue)
        self.rowDescriptor.value = [[NSMutableDictionary alloc] init];

    
    
    [VVCSelectButton autoBindButtonsOnView:self];
    
    [VVCTextField autoBindTextFieldOnView:self];
    
    [VVCSwitch autoBindTextFieldOnView:self];
    
    [VVCTextView autoBindTextFieldOnView:self];
    
}

-(void)formDescriptorCellDidSelectedWithFormController:(XLFormViewController *)controller{
    [controller deselectFormRow:self.rowDescriptor];
}

+(CGFloat)formDescriptorCellHeightForRowDescriptor:(XLFormRowDescriptor *)rowDescriptor
{
    return 100.0f;
}


-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
@end
