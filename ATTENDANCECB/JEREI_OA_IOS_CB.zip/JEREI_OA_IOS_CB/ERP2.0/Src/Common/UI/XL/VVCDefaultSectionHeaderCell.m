//
//  VVCDefaultSectionHeaderCell.m
//  VolvoChecklist
//
//  Created by jerei on 14/12/26.
//  Copyright (c) 2014年 jerehsoft. All rights reserved.
//

#import "VVCDefaultSectionHeaderCell.h"

@implementation VVCDefaultSectionHeaderCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
