//
//  VVCSwitch.h
//  VolvoChecklist
//
//  Created by jerei on 14/12/29.
//  Copyright (c) 2014年 jerehsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLForm.h"

@interface VVCSwitch : UISwitch
@property NSString *valueKey;
@property (weak) XLFormBaseCell *cellView;


-(void)switchAction:(id)sender;


+(void)bindTextFiled:(VVCSwitch *)switchField cellView:(XLFormBaseCell *)cellView;
+(void)autoBindTextFieldOnView:(XLFormBaseCell *)cell;
@end
