//
//  VVCDefaultSectionHeaderCell.h
//  VolvoChecklist
//
//  Created by jerei on 14/12/26.
//  Copyright (c) 2014年 jerehsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLFormBaseCell.h"

@interface VVCDefaultSectionHeaderCell : XLFormBaseCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *infoButton;

@end
