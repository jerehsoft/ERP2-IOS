//
//  VVCSwitch.m
//  VolvoChecklist
//
//  Created by jerei on 14/12/29.
//  Copyright (c) 2014年 jerehsoft. All rights reserved.
//

#import "VVCSwitch.h"

@implementation VVCSwitch

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


-(void)switchAction:(id)sender{
    id value = @([self isOn]);
    [self.cellView.rowDescriptor.value setValue:value forKey:self.valueKey];
}

+(void)bindTextFiled:(VVCSwitch *)switchField cellView:(XLFormBaseCell *)cellView{
    
    switchField.valueKey = switchField.valueKey ?: [switchField valueForKey:@"valueKey"];
    if(switchField.valueKey == nil)
        return;
    switchField.cellView = cellView;
    
    id value = [cellView.rowDescriptor.value valueForKey:switchField.valueKey];
    [switchField setOn:[value boolValue]];
    [switchField addTarget:switchField action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    
}

+(void)autoBindTextFieldOnView:(XLFormBaseCell *)cell{
    NSMutableArray *fields = [[NSMutableArray alloc]init];
    
    [VVCSwitch findVVCTextField:cell fields:fields];
    for(VVCSwitch *field in fields){
        [VVCSwitch bindTextFiled:field cellView:cell];
    }
}

+(void)findVVCTextField:(UIView *)uiView fields:(NSMutableArray *)fields{
    for(UIView *view in uiView.subviews){
        if([view isKindOfClass:[VVCSwitch class]]){
            [fields addObject:view];
        }else{
            [VVCSwitch findVVCTextField:view fields:fields];
        }
    }
}

@end
