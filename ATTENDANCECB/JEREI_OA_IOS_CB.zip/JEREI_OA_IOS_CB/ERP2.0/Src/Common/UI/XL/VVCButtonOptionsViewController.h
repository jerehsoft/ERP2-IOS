//
//  VVCButtonOptionsViewController.h
//  XLForm
//
//  Created by jerei on 14/12/16.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//


#import "XLFormOptionsViewController.h"

@interface VVCButtonOptionsViewController : XLFormOptionsViewController

@property NSString *valueKey;
@property BOOL customValue;

@end
