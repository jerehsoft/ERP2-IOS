//
//  VVCTextView.h
//  VolvoChecklist
//
//  Created by jerei on 15/1/7.
//  Copyright (c) 2015年 jerehsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLFormBaseCell.h"

@interface VVCTextView : UITextView<UITextViewDelegate>

@property NSString *valueKey;
@property NSString *dataType;
@property (weak) XLFormBaseCell *cellView;
@property BOOL singleValue;
@property BOOL isBorder;
@property NSString *placeholder;

+(void)bindTextFiled:(VVCTextView *)textField cellView:(XLFormBaseCell *)cellView;

+(void)autoBindTextFieldOnView:(XLFormBaseCell *)cell;

@end
