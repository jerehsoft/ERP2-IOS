//
//  JSUINavigationController.m
//  BaseDev
//
//  Created by jereh on 15/12/1.
//  Copyright © 2015年 jerehsoft. All rights reserved.
//

#import "JSUINavigationController.h"

@interface JSUINavigationController () <UIGestureRecognizerDelegate>

@end

@implementation JSUINavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    UINavigationBar *appearance = [UINavigationBar appearance];
    // 设置导航栏背景
    UIImage * image = [UIImage imageWithColor:[UIColor blackColor]];
    [appearance setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    
    //1>设置全局导航条外观
    [self setupNav];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 *  让屏幕上面的电池等状态颜色变成高亮
 */
-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
//    return UIStatusBarStyleDefault;
}

#pragma mark - 自定义方法

/**
 *  设置全局导航条
 */
- (void)setupNav{
//    UINavigationBar * bar = [UINavigationBar appearanceWhenContainedIn:[JSUINavigationController class], nil];
    UINavigationBar * bar;
//    if ([UIDevice currentDevice].systemVersion.floatValue < 9.0) {
        bar = [UINavigationBar appearanceWhenContainedIn:[JSUINavigationController class], nil];
//    } else {
//        bar = [UINavigationBar appearanceWhenContainedInInstancesOfClasses:@[[JSUINavigationController class]]];
//    }
    
    //IOS7以上关闭导航栏半透明，否则遮挡内容
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        self.navigationBar.translucent = NO;
    }
    
    NSDictionary * dict = @{NSForegroundColorAttributeName:[UIColor colorWithRed:16/255.0 green:16/255.0 blue:16/255.0 alpha:1.0],
                            NSFontAttributeName:[UIFont boldSystemFontOfSize:18]
                            };
    [bar setTitleTextAttributes:dict];
    [bar setTintColor:[UIColor colorWithRed:16/255.0 green:16/255.0 blue:16/255.0 alpha:1.0]];
}
@end
