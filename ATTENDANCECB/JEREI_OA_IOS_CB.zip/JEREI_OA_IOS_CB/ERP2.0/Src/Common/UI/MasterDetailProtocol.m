//
//  MasterDetailProtocol.m
//  ERP2.0
//
//  Created by jerei on 14-8-5.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "MasterDetailProtocol.h"

@implementation MasterDetailUtils

+ (SEL)_parepareDetailSelector
{
    SEL sel = NSSelectorFromString(@"prepareDetailViewWithData:");
    return sel;
}

+ (BOOL)_testDetailViewController:(id)detailViewController
{
    if (detailViewController && [detailViewController conformsToProtocol:@protocol(DetailViewProtocol)]) {
        return YES;
    } else {
        NSLog(@"detailViewController is nil or does not conform to protocol DetailViewProtocol");
        return NO;
    }
}

+ (void)passArgsToDetail:(id<DetailViewProtocol>)detailViewController withArgument:(id)arg1
{
    if ([MasterDetailUtils _testDetailViewController:detailViewController]) {
        SuppressPerformSelectorLeakWarning
        (
         [detailViewController performSelector:[MasterDetailUtils _parepareDetailSelector]
                                    withObject:arg1];
         );
    }
}

+ (void)passArgsToDetail:(id<DetailViewProtocol>)detailViewController withArgument:(id)arg1 withArgument:(id)arg2
{
    if ([MasterDetailUtils _testDetailViewController:detailViewController]) {
        SuppressPerformSelectorLeakWarning
        (
         [detailViewController performSelector:[MasterDetailUtils _parepareDetailSelector]
                                    withObject:arg1
                                    withObject:arg2];
         );
    }
}

+ (BOOL)validateDataForDetail:(id<NestedDetailViewProtocol>)detailViewController
{
    BOOL isDataValid = YES;
    isDataValid = (BOOL)[detailViewController performSelector:@selector(validateDetailData)];
    return isDataValid;
}

+ (id)retrieveDataFromDetail:(id<NestedDetailViewProtocol>)detailViewController
{
    SEL retrieveDataSel = @selector(retrieveDataFromDetail);
    id data;
    SuppressPerformSelectorLeakWarning
    (
     data = [detailViewController performSelector:retrieveDataSel];
     );
    return data;
}
@end
