//
//  UIImage+Scale.h
//  BaseDev
//
//  Created by jereh on 16/3/2.
//  Copyright © 2016年 jerehsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (UIImageScale)
-(UIImage*)getSubImage:(CGRect)rect;
-(UIImage*)scaleToSize:(CGSize)size;
@end
