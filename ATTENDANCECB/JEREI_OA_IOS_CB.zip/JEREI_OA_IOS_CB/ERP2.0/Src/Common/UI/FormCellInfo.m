//
//  FormCellInfo.m
//  ERP2.0
//
//  Created by jerei on 14-8-29.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "FormCellInfo.h"
#import "Controllers/TableFormViewController_Validation.h"

@implementation FormCellInfo
- (NSString *)description
{
    NSString *desc = [NSString stringWithFormat:@"[CELL: %zd:%zd '%@' -> %@]", [self.indexPath section], [self.indexPath row], self.sectionTitle, self.cell];
    return desc;
}

- (void)setIsCurrent:(BOOL)isCurrent
{
    _isCurrent = isCurrent;
    [self.cell setIsCurrent:_isCurrent];
}

- (FormViewCell *)cell
{
    FormViewCell *cell = [self.formController cellForFormCellInfo:self];
    return cell;
}

@end

