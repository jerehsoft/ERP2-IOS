//
//  UIWebView+Alert.h
//  ERP2.0
//
//  Created by jerehsoft on 15/12/16.
//  Copyright (c) 2015年 jerei. All rights reserved.
//

//#import <UIKit/UIKit.h>
//
//@interface UIWebView (JavaScriptAlert)
//- (void)webView:(UIWebView *)sender runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(CGRect)frame;
//- (BOOL)webView:(UIWebView *)sender runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(CGRect)frame;
//@end