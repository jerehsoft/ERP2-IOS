//
//  FormDataMapping.h
//  ERP2.0
//
//  Created by jerei on 14-8-11.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface _FormDataMappingEntry : NSObject
@property (nonatomic, retain) NSString *title;
@property (nonatomic, retain) id formatt;
- (instancetype)initWithTitle:(NSString *)title;
- (BOOL)isGroup;
@end


@interface FormDataMappingItem : _FormDataMappingEntry
@property (nonatomic, retain) NSString *key;
- (instancetype)initWithTitle:(NSString *)title forKey:(NSString *)key;
- (NSString *)descripionForData:(NSDictionary *)data;
@end


@interface FormDataMappingGroup : _FormDataMappingEntry
@property (nonatomic, readonly) NSArray *items;
@property (nonatomic, readonly) NSInteger itemCount;
- (FormDataMappingItem *)itemAtIndex:(NSInteger)index;
- (void)addItemWithTitle:(NSString *)title forKey:(NSString *)key;
@end


@interface FormDataMapping : NSObject
@property (nonatomic, readonly) NSArray *groups;
@property (nonatomic, readonly) NSInteger groupCount;
- (FormDataMappingGroup *)groupAtIndex:(NSInteger)index;
- (void)addGroupWithTitle:(NSString *)title;
- (void)addItemWithTitle:(NSString *)title forKey:(NSString *)key;
@end
