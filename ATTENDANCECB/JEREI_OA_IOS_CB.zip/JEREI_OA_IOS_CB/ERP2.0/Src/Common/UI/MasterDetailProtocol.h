//
//  MasterDetailProtocol.h
//  ERP2.0
//
//  Created by jerei on 14-8-1.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Erp2.h"

/*!
 @abstract master页面
 */
@protocol MasterViewProtocol <NSObject>

@required
/*!
 @abstract 刷新master
 */
- (void)reloadMasterView;

@end


/*!
 @abstract detail页面
 */
@protocol DetailViewProtocol <NSObject>

@required
/*!
 @abstract 由master主动向detail推送数据
 */
- (void)prepareDetailViewWithData:(id)detailData;
/*!
 @abstract detail验证自身数据
 */
- (BOOL)validateDetailData;

@end

/*!
 @abstract 嵌套明细页面，通常是嵌套在containerView中的viewController
 */
@protocol NestedDetailViewProtocol <DetailViewProtocol>

@required
/*!
 @abstract 由master主动从detail获取数据
 */
- (id)retrieveDataFromDetail;

@end

/*!
 @abstract 主从controller工具
 */
@interface MasterDetailUtils : NSObject

/*!
 @abstract master调用：向detailController传递数据
 */
+ (void)passArgsToDetail:(id<DetailViewProtocol>)detailViewController withArgument:(id)arg1;
/*!
 @abstract master调用：向detailController传递数据
 */
+ (void)passArgsToDetail:(id<DetailViewProtocol>)detailViewController withArgument:(id)arg1 withArgument:(id)arg2;
/*!
 @abstract master调用：从nestedDetailController获取数据
 */
+ (id)retrieveDataFromDetail:(id<NestedDetailViewProtocol>)detailViewController;
/*!
 @abstract master调用：请求detail验证数据，返回YES为数据合法，NO为数据不合法
 */
+ (BOOL)validateDataForDetail:(id<NestedDetailViewProtocol>)detailViewController;

@end