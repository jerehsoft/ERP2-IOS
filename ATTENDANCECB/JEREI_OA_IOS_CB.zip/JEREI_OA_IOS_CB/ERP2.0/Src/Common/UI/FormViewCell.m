//
//  FormViewCell.m
//  ERP2.0
//
//  Created by jerei on 14-8-29.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "FormViewCell.h"


@interface FormViewCell()
{
    NSString *_propertyLabelText;
    
    __weak UIView *_inputView;
}
@end

@implementation FormViewCell

@synthesize propertyLabelText = _propertyLabelText;

- (NSString *)propertyLabelText
{
    if (!_propertyLabelText) {
        // 如果没有指定labelText则从label中获取
        _propertyLabelText = [self.textLabel text];
        if (!_propertyLabelText || !_propertyLabelText.length) {
            // 如果没有默认label，则查找第一个可见的label
            [JSUIUtils traverse:self
              withViewProcessor:^BOOL(UIView *uiView, int viewDepth) {
                  if (!uiView.hidden &&
                      [uiView isKindOfClass:[UILabel class]] &&
                      ![@"UITextFieldLabel" isEqualToString:NSStringFromClass([uiView class])]) {
                      _propertyLabelText = ((UILabel *)uiView).text;
                      return NO;
                  }
                  return YES;
              }];
            if (!_propertyLabelText || !_propertyLabelText.length) {
                _propertyLabelText = self.cellInfo.sectionTitle;
            }
        }
    }
    return _propertyLabelText;
}

#pragma mark Initialization
- (void)__setup
{
    _type = @"NSString";
    _listIdPropertyName = nil;
    _listTextPropertyName = @"text";
}

- (instancetype)init
{
    if (self = [super init]) {
        [self __setup];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {
        [self __setup];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self __setup];
    }
    return self;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self __setup];
    }
    return self;
}

- (void)dealloc
{
    _type = nil;
    _listIdPropertyName = nil;
    _listTextPropertyName = nil;
    _dependentPropertyNames = nil;
}

#pragma mark Properties
@synthesize propertyClass = _class;
@synthesize propertyType = _type;
@synthesize propertyListTextPropertyName = _listTextPropertyName;
@synthesize propertyListIdPropertyName = _listIdPropertyName;
@synthesize propertyDependencies = _propertyDependencies;
@synthesize dependentPropertyNames = _dependentPropertyNames;

- (void)setPropertyDependencies:(NSString *)propertyDependencies
{
    _propertyDependencies = propertyDependencies;
    NSMutableSet *dependencies = [NSMutableSet setWithCapacity:3];
    if (_propertyDependencies) {
        _propertyDependencies = [_propertyDependencies trim];
        
        NSCharacterSet *separators = [NSCharacterSet characterSetWithCharactersInString:@";,"];
        for (NSString *pd in [_propertyDependencies componentsSeparatedByCharactersInSet:separators]) {
            NSString *propDependency = [pd trim];
            if (propDependency.length) {
                [dependencies addObject:propDependency];
            }
        }
    }
    _dependentPropertyNames = dependencies;
}

- (void)setPropertyType:(NSString *)propertyType
{
    _type = propertyType;
    _class = _type ? NSClassFromString(_type) : nil;
}

- (void)setIsCurrent:(BOOL)isCurrent
{
    _isCurrent = isCurrent;
    if (!isCurrent) {
        // 将inputView移除，避免事件延迟触发
        [_inputView removeFromSuperview];
    }
}

- (EnumFormViewCellInputType)defaultInputType
{
    if (self.propertyListDataSelector && self.propertyListDataSelector.length) {
        return FormViewCellInputTypeList;
    }
    else if (self.propertyClass == [NSDate class]) {
        return FormViewCellInputTypeDate;
    }
    else {
        return FormViewCellInputTypeDefault;
    }
}

- (NSString *)description
{
    NSString *desc = [NSString stringWithFormat:@"<FormViewCell : propertyName = %@, propertyType = %@, propertyValidator = %@, cell = %@>", self.propertyName, self.propertyType, self.propertyValidator, [super description]];
    return desc;
}

#pragma mark Methods
- (NSArray *)listDataFromProvider:(id)listDataProvider
{
    NSArray *listData;
    SEL selectDataSelector = NSSelectorFromString(self.propertyListDataSelector);
    if ([listDataProvider respondsToSelector:selectDataSelector]) {
        SuppressPerformSelectorLeakWarning
        (
         listData = [listDataProvider performSelector:selectDataSelector withObject:self];
         );
    }
    else {
        NSLog(@"view controller does not respond to selector %@", self.propertyListDataSelector);
        listData = nil;
    }
    return listData;
}

- (BOOL)dependsOn:(NSString *)propertyName
{
    return _dependentPropertyNames && [_dependentPropertyNames containsObject:propertyName];
}

#pragma mark 输入view/accessoryView和跳转控制
- (BOOL)canBecomeFirstResponder
{
    BOOL canBecomeFr = NO;
    if (self.cellInfo.inputHandler) {
        // 注意：这里不能计入cell内部可编辑的文本控件，否则会影响TableFormViewController的cell之间的导航
        if ([self.cellInfo.inputHandler respondsToSelector:@selector(canBecomeFirstResponder:countTextFieldsIn:)]) {
            canBecomeFr = [self.cellInfo.inputHandler canBecomeFirstResponder:self countTextFieldsIn:NO];
        }
    }
    return canBecomeFr;
}

- (BOOL)becomeFirstResponder
{
    [super becomeFirstResponder];
    // 如果当前cell在table的不可见区域，将无法成为firstResponder，所以这里要返回canBecomeFirstResponder的结果
    BOOL canBecomeFr = [self canBecomeFirstResponder];
    return canBecomeFr;
}

- (BOOL)canResignFirstResponder
{
    return YES;
}

- (UIView *)inputView
{
    if (self.cellInfo.inputHandler && [self.cellInfo.inputHandler respondsToSelector:@selector(inputViewForCell:)]) {
        _inputView = [self.cellInfo.inputHandler inputViewForCell:self];
    }
    else {
        _inputView = nil;
    }
    return _inputView;
}

- (UIView *)inputAccessoryView
{
    UIView *view = nil;
    if (self.cellInfo.inputHandler && [self.cellInfo.inputHandler respondsToSelector:@selector(inputAccessoryViewForCell:)]) {
        view = [self.cellInfo.inputHandler inputAccessoryViewForCell:self];
    }
    return view;
}

@end


