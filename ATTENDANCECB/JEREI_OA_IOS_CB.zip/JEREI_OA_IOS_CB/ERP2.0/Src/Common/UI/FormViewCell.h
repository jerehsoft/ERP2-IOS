//
//  FormViewCell.h
//  ERP2.0
//
//  Created by jerei on 14-8-29.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FormCellInfo.h"
#import <UIKit/UIKit.h>

@class FormCellInfo;

/*!
 @abstract FormViewCell输入视图类型，此类型将根据cell的属性类型或所包含的输入组件类型来判断
 */
typedef enum {
    FormViewCellInputTypeDefault,  // 不确定输入视图，系统自动处理
    FormViewCellInputTypeList, // 列表数据选择，对应cell应指定propertyList*相关属性
    FormViewCellInputTypeDate  // 日期选择，对应cell的propertyType为NSDate
} EnumFormViewCellInputType;

/*!
 @abstract 表单的单元格，需要指定对应的表单属性，TableFormViewController将根据表单属性决定如何编辑该单元格
 */
@interface FormViewCell : UITableViewCell

// 属性显示名
@property (nonatomic, retain) NSString *propertyLabelText;
// 数据属性名
@property (nonatomic, retain) NSString *propertyName;
// 数据属性类型
@property (nonatomic, retain) NSString *propertyType;
// 数据格式
@property (nonatomic, retain) NSString *propertyPattern;
// 是否必填
@property (nonatomic, assign) BOOL propertyRequired;
// 验证器
@property (nonatomic, retain) NSString *propertyValidator;
// 验证器参数，如果验证器有多个参数，则参数中间以:分隔，如果参数中需要包含:，则在:之前使用字符\来转义
@property (nonatomic, retain) NSString *propertyValidatorParams;
// 验证失败时的消息
@property (nonatomic, retain) NSString *propertyValidatorMessage;
// 选择控件的数据提供方法
@property (nonatomic, retain) NSString *propertyListDataSelector;
// 选择数据源的主键属性名，如果为nil则表示使用数据本身
@property (nonatomic, retain) NSString *propertyListIdPropertyName;
// 选择数据源的文字属性名，如果为nil则使用名称'name'
@property (nonatomic, retain) NSString *propertyListTextPropertyName;
// 依赖的属性名称列表
@property (nonatomic, retain) NSString *propertyDependencies;


// 指定用于输入和展现的控件tag，如果没有指定则首先尝试查找第一个输入控件，然后尝试使用detailLabel
@property (nonatomic, retain) NSNumber *inputViewTag;

// 依赖的目标属性清单，由propertyDependencies拆分生成
@property (nonatomic, readonly) NSSet *dependentPropertyNames;

// 对应propertyType的class
@property (nonatomic, readonly) Class propertyClass;

/*!
 @abstract 默认输入控件类型
 */
@property (nonatomic, readonly) EnumFormViewCellInputType defaultInputType;


/*!
 @abstract 从列表数据源读取列表数据
 */
- (NSArray *)listDataFromProvider:(id)listDataProvider;

/*!
 @abstract 检查是否依赖于指定属性
 */
- (BOOL)dependsOn:(NSString *)propertyName;

/*!
 @abstract 是否当前选定的cell
 */
@property (nonatomic, assign) BOOL isCurrent;

@property (nonatomic, assign) FormCellInfo *cellInfo;

@end

