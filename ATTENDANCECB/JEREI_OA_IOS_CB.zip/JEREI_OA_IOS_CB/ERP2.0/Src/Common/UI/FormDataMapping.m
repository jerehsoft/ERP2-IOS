//
//  FormDataMapping.m
//  ERP2.0
//
//  Created by jerei on 14-8-11.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "FormDataMapping.h"
#import "StringUtils.h"


@implementation _FormDataMappingEntry

- (instancetype)initWithTitle:(NSString *)title
{
    if (self = [super init]) {
        self.title = title;
    }
    return self;
}

- (BOOL)isGroup
{
    return [self isKindOfClass:[FormDataMappingGroup class]];
}

@end


@interface FormDataMappingGroup()
{
    NSMutableArray *_items;
}
@end
@implementation FormDataMappingGroup
- (instancetype)initWithTitle:(NSString *)title
{
    if (self = [super initWithTitle:title]) {
        _items = [[NSMutableArray alloc] initWithCapacity:16];
    }
    return self;
}
- (NSArray *)items
{
    return [NSArray arrayWithArray:_items];
}
- (NSInteger)itemCount
{
    return _items.count;
}
- (FormDataMappingItem *)itemAtIndex:(NSInteger)index
{
    return [_items objectAtIndex:index];
}
- (void)addItemWithTitle:(NSString *)title forKey:(NSString *)key
{
    FormDataMappingItem *item = [[FormDataMappingItem alloc] initWithTitle:title forKey:key];
    [_items addObject:item];
}
@end


@implementation FormDataMappingItem

- (instancetype)initWithTitle:(NSString *)title forKey:(NSString *)key
{
    assert(title && title.length);
    if (self = [super initWithTitle:title]) {
        assert(key && key.length);
        self.key = key;
    }
    return self;
}

- (NSString *)descripionForData:(NSDictionary *)data
{
    NSString *text = [NSString stringWithFormat:@"%@: %@", self.title, [NSString stringWrapped:[data valueForKey:self.key]]];
    return text;
}
@end


@interface FormDataMapping()
{
    NSMutableArray *_groups;
}
@end
@implementation FormDataMapping

- (NSArray *)groups
{
    return [[NSArray alloc] initWithArray:_groups];
}
- (NSInteger)groupCount
{
    return _groups.count;
}
- (FormDataMappingGroup *)groupAtIndex:(NSInteger)index
{
    return [_groups objectAtIndex:index];
}
- (id)init
{
    if (self = [super init]) {
        _groups = [[NSMutableArray alloc] initWithCapacity:16];
    }
    return self;
}

- (void)addGroupWithTitle:(NSString *)title
{
    FormDataMappingGroup *group = [[FormDataMappingGroup alloc] initWithTitle:title];
    [_groups addObject:group];
}

- (void)addItemWithTitle:(NSString *)title forKey:(NSString *)key
{
    // 向最后一个group添加item，如果没有group则创建一个匿名的group
    FormDataMappingGroup *group = [_groups lastObject];
    if (!group) {
        group = [[FormDataMappingGroup alloc] initWithTitle:nil];
        [_groups addObject:group];
    }
    [group addItemWithTitle:title forKey:key];
}

@end
