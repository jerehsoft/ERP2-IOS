//
//  UIWebView+Alert.m
//  ERP2.0
//
//  Created by jerehsoft on 15/12/16.
//  Copyright (c) 2015年 jerei. All rights reserved.
//

//#import <Foundation/Foundation.h>
//#import "UIWebView+Alert.h"
//#import "JSUIUtils.h"
//
//@implementation UIWebView (JavaScriptAlert)
//- (void)webView:(UIWebView *)sender runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(CGRect)frame {
//    [JSUIUtils alert:message withTitle:@"温馨提示"];
//}
//- (BOOL)webView:(UIWebView *)sender runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(CGRect)frame{
//    __block BOOL isOK;
//    [JSUIUtils alertOKCancel:message withTitle:@"温馨提示" buttonBlock:^(BOOL isCancel) {
//        if (isCancel) {
//            isOK = NO;
//        } else {
//            isOK = YES;
//        }
//    }];
//    return isOK;
//}
//@end