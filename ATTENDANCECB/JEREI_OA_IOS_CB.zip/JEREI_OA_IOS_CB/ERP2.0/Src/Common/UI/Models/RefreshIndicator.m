//
//  RefreshIndicator.m
//  ERP2.0
//
//  Created by 丁未汀 on 9/9/14.
//  Copyright (c) 2014 jerei. All rights reserved.
//

#import "RefreshIndicator.h"



@interface RefreshIndicator()
{
    NSString *_defaultMessage;
    NSString *_releaseMessage;
    NSString *_refreshMessage;
    NSString *_finishedMessage;
    
    __weak UILabel *_textLabel;
    __weak UIActivityIndicatorView *_indicator;
    __weak UIImageView *_refreshView;
    EnumRefreshIndicatorState _state;
}
@end

@implementation RefreshIndicator

- (id)initWithFrame:(CGRect)frame defaultMessage:(NSString *)defaultMessage releaseMessage:(NSString *)releaseMessage refreshMessage:(NSString *)refreshMessage finishedMessage:(NSString *)finishedMessage
{
    self = [super initWithFrame:frame];
    if (self) {
        _defaultMessage = defaultMessage;
        _releaseMessage = releaseMessage;
        _refreshMessage = refreshMessage;
        _finishedMessage = finishedMessage;
        
        _state = -1;
        
        UILabel *txtLabel = [[UILabel alloc] initWithFrame:frame];
        [txtLabel setFont:[UIFont systemFontOfSize:[UIFont systemFontSize]]];
        [txtLabel setTextAlignment:NSTextAlignmentLeft];
        [txtLabel setTextColor:[UIColor colorWithRed:0 green:((9.0 * 16 + 2) / 255) blue:0 alpha:1]];
        [self addSubview:txtLabel];
        
        UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        indicator.hidesWhenStopped = NO;
        indicator.hidden = NO;
        [self addSubview:indicator];
        
        UIImageView *refreshView;
        refreshView = [[UIImageView alloc] initWithFrame:frame];
        refreshView.contentMode = UIViewContentModeScaleAspectFit;
        refreshView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        
        _textLabel = txtLabel;
        _indicator = indicator;
        _refreshView = refreshView;
        
        [self setState:RefreshIndicatorStateDefault];
    }
    return self;
}

- (void)layoutSubviews
{
    float availWidth = self.frame.size.width * .8f;
    float availHeight = self.frame.size.height * .8f;
    float gap = 2.0f;
    
    CGRect textSize = [_textLabel.text boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, self.frame.size.height)
                                                    options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                                                 attributes:nil
                                                    context:nil];
    
    float textWidth = availWidth - availHeight - gap;
    textWidth += 10.0f;
    if (textWidth > textSize.size.width) {
        textWidth = textSize.size.width;
        textWidth += 10.0f;
        availWidth = textWidth + gap + availHeight;
    }
    
    float x = (self.frame.size.width - availWidth) / 2;
    float y = (self.frame.size.height - availHeight) / 2;
    
    _indicator.frame = CGRectMake(x, y, availHeight, availHeight);
    _refreshView.frame = CGRectMake(x, y, availHeight, availHeight);
    
    x += gap + availHeight;
    NSLog(@"Text -> %@, %f", _textLabel.text, textWidth);
    _textLabel.frame = CGRectMake(x, y, textWidth, availHeight);
    
    [super layoutSubviews];
}


- (void)setPullDistance:(float)pullDistance
{
    _pullDistance = pullDistance;
    if (_pullDistance >= self.frame.size.height) {
        [self setState:RefreshIndicatorStateReleaseToRefresh];
    }
    else {
        [self setState:RefreshIndicatorStateDefault];
    }
}

- (void)setState:(EnumRefreshIndicatorState)state pullOffset:(float)pullOffset
{
    CGFloat percent = 0;
    if (pullOffset < 0) {
        pullOffset = 0;
    }
    if (pullOffset > self.frame.size.height) {
        pullOffset = self.frame.size.height;
    }
    percent = pullOffset / self.frame.size.height;
    NSString *text = nil;
    if (state == RefreshIndicatorStateDefault) {
        text = _defaultMessage;
        [_refreshView stopAnimating];
    }
    else if (state == RefreshIndicatorStateRefreshing) {
        text = _refreshMessage;
        [_refreshView startAnimating];
    }
    else if (state == RefreshIndicatorStateReleaseToRefresh) {
        text = _releaseMessage;
        [_refreshView stopAnimating];
    }
    else if (state == RefreshIndicatorStateFinished) {
        text = _finishedMessage;
    }
    
    if (_state == state) {
        return;
    }
    
    _textLabel.text = text;
    _state = state;
    if (state == RefreshIndicatorStateRefreshing) {
        [_indicator startAnimating];
    }
    else {
        [_indicator stopAnimating];
    }
    [self setNeedsLayout];
}

@end
