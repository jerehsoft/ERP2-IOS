//
//  ErpSearchTableController.m
//  ERP2.0
//
//  Created by jerei on 14-7-30.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPSearchTableHelper.h"
#import "RefreshIndicator.h"

// tableCell reuse identifiers
static NSString *PAGING_CELL_ID = @"__pagingCell";
static NSString *TEMPLATE_CELL_ID = @"__templateCell";
static NSString *TEMPLATE_SUBTITLED_CELL_ID = @"__templateCellWithSubTitle";
static NSString *SECTION_HEADER_ID = @"__sectionHeader";

// 下拉刷新最小滚动距离
static int PULL_DOWN_THRESHOLD = 40;
static int PULL_DOWN_VIEW_TAG = 111;
static NSString *PULL_DOWN_TEXT_RELEASE_TO_RELOAD = @"松开刷新";
static NSString *PULL_DOWN_TEXT_PULL_DOWN_TO_RELOAD = @"下拉刷新";
static NSString *PULL_DOWN_TEXT_RELOADING = @"正在刷新";
static NSString *PULL_DOWN_TEXT_LOADED = @"刷新完成";

// title for empty cell
static NSString *TITLE_NONE = @"<UNTITLED>";




@interface ERPSearchTableHelper()
{
    // 控件引用
    UITableView *_tableView;
    UISearchBar *_searchBar;
    
    // 自动创建的控件
    UIButton *_refreshBtn;
    
    // 保存原始数据
    NSMutableArray *_rows;
    // 保存分组数据
    NSMutableArray *_groups;
    
    // 搜索关键字，需要在每次翻页时保持上次使用的关键字，只有在下拉刷新或者重置时才使用searchBar.text替换此关键字
    NSString *_keyword;
    
    
    // 是否有更多数据待加载
    int _hasMoreData;
    
    // delegate的tableCell布局方法
    SEL _delegateCellLayoutSel;
    // delegate的获取cell的方法
    SEL _delegateCellGenerationSel;
    // delegate预处理数据的方法
    SEL _delegatePreprocessDataSel;
    // delegate接收cell布局完成通知
    SEL _delegateAfterCellLayoutSel;
    // delegate接收数据更新通知
    SEL _delegateDataUpdatedSel;
}

// 指示是否正在加载数据，同步在setter中实现
@property (nonatomic, readonly) BOOL loading;

@end


@implementation ERPSearchTableHelper

@synthesize mode = _mode;
@synthesize pageSize = _pageSize;
@synthesize delegate = _delegate;
@synthesize subTitleProperty = _subTitleProperty;

- (BOOL)loading
{
    RefreshIndicator *indicator = (RefreshIndicator *)[_tableView viewWithTag:PULL_DOWN_VIEW_TAG];
    return indicator.state == RefreshIndicatorStateRefreshing;
}

#pragma mark 为ERPSearchTableHelper_Paged.h提供的翻页相关属性
- (NSInteger)pageId
{
    return _pageId;
}
- (NSInteger)totalRowCount
{
    return _totalRowCount;
}
- (NSInteger)pageCount
{
    return (int)ceilf(_totalRowCount * 1.0f / _pageSize);
}

#pragma mark 初始化
- (instancetype)initWithTable:(UITableView *)tableView searchBar:(UISearchBar *)searchBar
{
    return [self initWithTable:tableView searchBar:searchBar mode:ERPSearchTableModeScrolling];
}

- (instancetype)initWithTable:(UITableView *)tableView searchBar:(UISearchBar *)searchBar mode:(ERPSearchTableMode)mode
{
    if (self = [self init]) {
        _mode = mode;
        
        _tableView = tableView;
        _searchBar = searchBar;
        
        _rows = [[NSMutableArray alloc] initWithCapacity:32];
        _groups = [[NSMutableArray alloc] initWithCapacity:16];
        
        [self __setup];
        [self __setupTableView];
        [self __setupSearchBar];
    }
    return self;
}

- (void)dealloc
{
    [self __releaseSearchBar];
    [self __releaseTableView];
    
    _tableView = nil;
    _searchBar = nil;
    [self printDealloc];
}


- (void)__setup
{
    _pageSize = SEARCH_TABLE_DEFAULT_PAGE_SIZE;
    _pageId = 1;
    _totalRowCount = 0;
    _hasMoreData = 0;
    _keyword = nil;
    self.showCellSubTitle = YES;
    
    [self setupPuller];
}

- (void)__setupTableView
{
    if (!_tableView)
        return;
    
    // 允许选择时才能高亮cell
    _tableView.allowsSelection = YES;
    _tableView.allowsMultipleSelection = NO;
    
    _tableView.delegate = self;
    _tableView.dataSource = self;
}
- (void)__releaseTableView
{
    if (!_tableView)
        return;
    
    _tableView.delegate = nil;
    _tableView.dataSource = nil;
}
- (void)__setupSearchBar
{
    if (!_searchBar)
        return;
    _searchBar.delegate = self;
    
    // 调整searchBar样式
    // 隐藏放大镜
    NSArray *texts = [JSUIUtils viewsInView:_searchBar withMatcher:^BOOL(UIView *view) {
        return [view isKindOfClass:[UITextField class]];
    }];
    if (texts.count) {
        UITextField *text = (UITextField *)texts[0];
        text.leftView.frame = CGRectZero;
        text.leftView.hidden = YES;
        if (!text.placeholder || !text.placeholder.length) {
            text.placeholder = @"请输入关键字";
        }
    }
    
    // 将searchBar包装在view中，添加刷新按钮
    UIView *searchView = [[UIView alloc]initWithFrame: _searchBar.frame];
    [_searchBar.superview addSubview:searchView];
    [_searchBar removeFromSuperview];
    
    // 容器背景
    [UIImage imageNamed:nil];
    NSArray *bgs = [JSUIUtils viewsInView:_searchBar withMatcher:^BOOL(UIView *view) {
        return [view isKindOfClass:[UIImageView class]] && [NSStringFromClass([view class]) isEqualToString:@"UISearchBarBackground"];
    }];
    if (bgs.count) {
        UIImageView *bg = (UIImageView *)bgs[0];
        UIImage *img = bg.image;
        if (img)
            searchView.backgroundColor = [UIColor colorWithPatternImage:img];
    }
    
    float searchTextHeight = 20.0f, searchTextMarginX = 8.0f;
    [JSUIUtils inspect:_searchBar];
    
    // 调整searchBar尺寸，为refreshBtn留出位置
    float btnHeight = _searchBar.frame.size.height, btnWidth = btnHeight - searchTextMarginX;
    _searchBar.frame = CGRectMake(0, 0, _searchBar.frame.size.width - btnWidth, _searchBar.frame.size.height);
    [searchView addSubview:_searchBar];
    
    // 刷新按钮
    CGRect rbFrame = CGRectMake(_searchBar.frame.size.width - searchTextMarginX + (btnHeight - searchTextHeight) / 2, (btnHeight - searchTextHeight) / 2, searchTextHeight, searchTextHeight);
    _refreshBtn = [[UIButton alloc] initWithFrame:rbFrame];
    UIImage *rbImg = [UIImage imageNamed:@"icon_search_light.png"];
    [_refreshBtn setImage:rbImg forState:UIControlStateNormal];
    [_refreshBtn addTarget:self action:@selector(_refreshBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [searchView addSubview:_refreshBtn];
}
- (void)__releaseSearchBar
{
    if (!_searchBar)
        return;
    _searchBar.delegate = nil;
    if (_refreshBtn) {
        [_refreshBtn removeTarget:self action:@selector(_refreshBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    _refreshBtn = nil;
}

- (void)_refreshBtnClicked:(id)sender
{
    [self reloadData];
}

- (void)setDelegate:(id<ERPSearchTableDelegate>)delegate
{
    _delegate = delegate;
    
    // 检查delegate是否实现了某些方法，初始化调用标记，避免在后面的方法中重复判断，优化性能
    _delegateCellLayoutSel = [self _findResponseSelector:_delegate selector:@selector(layoutTableCell:withData:)];
    _delegateCellGenerationSel = [self _findResponseSelector:_delegate selector:@selector(cellFromTableView:forData:)];
    _delegatePreprocessDataSel = [self _findResponseSelector:_delegate selector:@selector(preprocessData:)];
    _delegateAfterCellLayoutSel = [self _findResponseSelector:_delegate selector:@selector(afterLayoutTableCell:withData:)];
    _delegateDataUpdatedSel = [self _findResponseSelector:_delegate selector:@selector(dataUpdated)];
}

- (SEL)_findResponseSelector:(id<ERPSearchTableDelegate>)delegate selector:(SEL)selector
{
    return delegate && [delegate respondsToSelector:selector] ? selector : 0;
}

- (void)setSubTitleProperty:(NSString *)subTitleProperty
{
    _subTitleProperty = subTitleProperty;
    self.showCellSubTitle = (subTitleProperty != nil);
}



#pragma mark 数据处理
// 获取组数据
- (GroupedDataModel *)_groupedDataForSection:(NSInteger)section
{
    if (section > _groups.count - 1) {
        NSLog(@"warning<ErpSearchTableController> : invalid section index %ld for grouped data", section);
        return nil;
    }
    else {
        GroupedDataModel *gdata = (GroupedDataModel *)[_groups objectAtIndex:section];
        if (!gdata)
            NSLog(@"warning<ErpSearchTableController> : no data for section %ld", (long)section);
        return gdata;
    }
}

- (void)reloadData
{
    [_searchBar resignFirstResponder];
    [self loadDataAtPage:1 keyword:[[_searchBar text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
}

- (void)loadMoreData
{
    [self loadDataAtPage:_pageId + 1 keyword:_keyword];
}

- (void)reset
{
    // TODO 检验同步状态，防止线程冲突
    [self __setup];
    [_rows removeAllObjects];
    [_groups removeAllObjects];
    [_searchBar setText:nil];
    [_tableView reloadData];
}

// 加载数据
- (void)loadDataAtPage:(NSInteger)pageId
{
    [self loadDataAtPage:pageId keyword:_keyword];
}

// 如果pageId为1，则加载后清除之前的数据
- (void)loadDataAtPage:(NSInteger)pageId keyword:(NSString *)keyword
{
    if (self.loading) {
        // TODO toast提示
        NSLog(@"still loading...");
        return;
    }
    
    NSLog(@"加载列表数据 : pageId = %ld, pageSize = %ld, keyword = %@", (long)pageId, (long)self.pageSize, keyword);
    _keyword = keyword;
    
    if (_mode == ERPSearchTableModePaging) {
        // 如果是翻页模式，则首先清空数据
        [_groups removeAllObjects];
        [_rows removeAllObjects];
        [_tableView reloadData];
    }
    
    NSDictionary *paramsFromDelegate = [self.delegate parametersForListAction];
    NSDictionary *params = [[NSMutableDictionary alloc] initWithDictionary:paramsFromDelegate];
    [params setValue:@(pageId) forKey:PARAM_KEY_PAGE];
    [params setValue:@(self.pageSize) forKey:PARAM_KEY_ROWS];
    NSString *kwName = [self keyWord];
    if(!kwName)kwName = PARAM_KEY_KEYWORD;
    [params setValue:_keyword forKey:kwName];
    
    NSDictionary *headers = nil;
    if ([self.delegate respondsToSelector:NSSelectorFromString(@"headersForListAction:")])
        headers = [self.delegate headersForListAction];
    
    // TODO 通知delegate发生异常
    __block NSInteger pageSize = self.pageSize;
    __weak ERPSearchTableHelper *weakSelf = self;
    void (^success)(NSDictionary *) = ^(NSDictionary *responseData) {
        NSLog(@"加载数据成功 : pageId = %ld, total = %@", (long)pageId, [responseData valueForKey:@"total"]);
        ERPListActionResponseData *listData;
        listData = [ERPListActionResponseData parseDictionary:responseData pageSize:pageSize rowsName:weakSelf.rowsName];
        [weakSelf _fillData:listData pageId:pageId];
        [weakSelf dataLoaded];
    };
    void (^failed)(MKNetworkOperation *, NSError *) = ^(MKNetworkOperation *operation, NSError *error) {
        [weakSelf setPullerState:RefreshIndicatorStateDefault];
        NSLog(@"加载数据失败 : %@", error);
        NSString *errorMessage = [[error userInfo] valueForKey:NSLocalizedDescriptionKey];
        [JSUIUtils alert:errorMessage withTitle:@"无法加载数据"];
    };
    
    [self setPullerState:RefreshIndicatorStateRefreshing];
    [[ERPWebRequest mainSiteRequest] requestDataWithRelativeURI:self.listActionUri
                                                     withParams:params
                                                    withHeaders:headers
                                                 successHandler:success
                                                   errorHandler:failed];
}

// 处理数据，分组
- (void)_fillData:(ERPListActionResponseData *)listData pageId:(NSInteger)pageId
{
    // 先由delegate预处理数据
    if (_delegatePreprocessDataSel)
        listData.rows = [self.delegate preprocessData:listData.rows];
    
    BOOL isAppend = pageId > 1;
    if (isAppend)
        [_rows addObjectsFromArray:listData.rows];
    else
        [_rows setArray:listData.rows];
    
    // TODO 直接向group中插入数据，并根据数据的精确位置展现动画
    
    // 计算行数差异，直接刷新新增的行
    //    // 插入的新行
    //    NSMutableArray *addedRowIndexPaths = [NSMutableArray arrayWithCapacity:_rows.count];
    //    // 插入的section
    //    NSMutableIndexSet *addedSections = [[NSMutableIndexSet alloc] init];
    //
    //    uint sectionCount = [self numberOfSectionsInTableView:_tableView] - _hasMoreData;
    //    NSMutableArray *rowCounts = [NSMutableArray arrayWithCapacity:sectionCount];
    //    for (uint s = 0; s < sectionCount; ++s)
    //        [rowCounts addObject:@([self tableView:_tableView numberOfRowsInSection:s])];
    
    [self _regroupData];
    //    uint sectionCount2 = [self numberOfSectionsInTableView:_tableView] - _hasMoreData;
    //    for (uint s = 0; s < sectionCount2; ++s) {
    //        if (s >= sectionCount) {
    //            [addedSections addIndex:s];
    //        }
    //        else {
    //            uint rowCount2 = [self tableView:_tableView numberOfRowsInSection:s];
    //            uint rowCount = [[rowCounts objectAtIndex:s] unsignedIntegerValue];
    //            for (uint r = rowCount; r < rowCount2; ++r) {
    //                [addedRowIndexPaths addObject:[NSIndexPath indexPathForRow:r inSection:s]];
    //            }
    //        }
    //    }
    
    //[self _dumpData];
    
    _pageId = pageId;
    _totalRowCount = listData.total;
    _hasMoreData = _totalRowCount > _rows.count ? 1 : 0;
    
    [_tableView reloadData];
    
    //    if (isAppend) {
    //        if (addedRowIndexPaths) {
    //            [_tableView insertRowsAtIndexPaths:addedRowIndexPaths withRowAnimation:YES];
    //        }
    //        if (addedSections.count) {
    //            [_tableView insertSections:addedSections withRowAnimation:YES];
    //        }
    //    }
    //    else {
    //        [_tableView reloadData];
    //    }
}

- (void)dataLoaded
{
    // 通知delegate数据已更新
    if (_delegateDataUpdatedSel)
        [self.delegate dataUpdated];
    
    [self setPullerState:RefreshIndicatorStateFinished];
    CGPoint contentOffset = _tableView.contentOffset;
    if (contentOffset.y < 0)
        contentOffset = CGPointZero;
    [self setPullerLayoutWithContentInsets:UIEdgeInsetsZero withContentOffset:contentOffset];
}


// 分组数据
- (void)_regroupData
{
    [_groups removeAllObjects];
    // 按groupProperty分组
    NSMutableDictionary *groupMap = [[NSMutableDictionary alloc] initWithCapacity:10];
    for (NSDictionary *row in _rows) {
        NSString *groupTitle = [self groupTitleForRow:row];
        GroupedDataModel *group = [groupMap valueForKey:groupTitle];
        if (!group) {
            group = [[GroupedDataModel alloc] init];
            group.title = groupTitle;
            // 副标题
            NSString *groupSubTitle = [self groupSubTitleForRow:row];
            group.subTitle = groupSubTitle;
            
            // 如果组标题为nil则统一归到一个组中
            [groupMap setValue:group forKey:[ObjectUtils isNilOrNull:groupTitle defaultObject:[NSNull null]]];
            [_groups addObject:group];
        }
        [group.data addObject:row];
    }
}

- (void)_dumpData
{
    NSLog(@"Dumping data:");
    __NSLog(@"--------------GROUPS");
    for (int i = 0; i < _groups.count; ++i) {
        GroupedDataModel *g = [_groups objectAtIndex:i];
        __NSLog(@">> %d -> %@, %@", i, g.title, g.subTitle);
        for (int j = 0; j < g.data.count; ++j) {
            NSDictionary *r = [g.data objectAtIndex:j];
            __NSLog(@"   > %d -> %@ : %@", j, [r valueForKey:self.keyProperty], [r valueForKey:@"_title"]);
        }
    }
    __NSLog(@"--------------DATA");
    for (int i = 0; i < _rows.count; ++i) {
        NSDictionary *r = [_rows objectAtIndex:i];
        __NSLog(@">> %d -> %@ : %@", i, [r valueForKey:self.keyProperty], [r valueForKey:@"_title"]);
    }
}

#pragma mark TableView 辅助方法
- (BOOL)_isPagingSection:(NSInteger)section
{
    return section >= _groups.count;
}

- (NSDictionary *)_dataForIndexPath:(NSIndexPath *)indexPath
{
    if ([self _isPagingSection:indexPath.section])
        return nil;
    else
        return [((GroupedDataModel *)[_groups objectAtIndex:indexPath.section]).data objectAtIndex:indexPath.row];
}

#pragma mark 分组
- (NSString *)groupTitleForRow:(NSDictionary *)row
{
    if (!self.groupProperty)
        return nil;
    return [[row valueForKey:self.groupProperty] description];
}
- (NSString *)groupSubTitleForRow:(NSDictionary *)row
{
    return nil;
}


#pragma mark TableView section标题
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    NSString *text = [self _tableView:tableView titleForHeaderInSection:section];
    return (text && text.length) ? tableView.sectionHeaderHeight : 0;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSString *text = [self _tableView:tableView titleForHeaderInSection:section];
    if (!text || !text.length)
        return nil;
    
    UITableViewHeaderFooterView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:SECTION_HEADER_ID];
    if (!headerView) {
        headerView = [[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:SECTION_HEADER_ID];
        
        const int PADDING_H = 13;
        int subTitleWidth = tableView.bounds.size.width / 2;
        CGRect subFrame = CGRectMake(subTitleWidth - PADDING_H, 0, subTitleWidth, tableView.sectionHeaderHeight);
        UILabel *subTitle = [[UILabel alloc] initWithFrame:subFrame];
        subTitle.textAlignment = NSTextAlignmentRight;
        subTitle.font = [UIFont systemFontOfSize:[UIFont smallSystemFontSize] - 1];
        subTitle.textColor = [UIColor colorWithHexRGB:@"aaa"];
        subTitle.tag = 99;
        [headerView addSubview:subTitle];
    }
    headerView.textLabel.text = text;
    
    UILabel *subTitle = (UILabel *)[headerView viewWithTag:99];
    GroupedDataModel *gdata = [self _groupedDataForSection:section];
    subTitle.text = gdata ? gdata.subTitle : nil;
    
    return headerView;
}

// 如果提供了titleForHeaderInSection则不调用viewForHeaderInSection
- (NSString *)_tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if ([self _isPagingSection:section]) {
        // 虚拟section，只包含翻页链接
        return nil;
    } else {
        // 数据section
        GroupedDataModel *gdata = [self _groupedDataForSection:section];
        return gdata && gdata.title ? gdata.title : nil;
    }
}


#pragma mark TableView 数据源
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([self _isPagingSection:section]) {
        // 虚拟section，只包含翻页链接
        return 1;
    } else {
        GroupedDataModel *gdata = [self _groupedDataForSection:section];
        return (gdata == nil) ? 0 : gdata.data.count;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSInteger groupCount = ((_groups == nil) ? 0 : _groups.count);
    // 如果连续滚动则增加一个加载指示用的虚拟section
    // 如果存在更多数据，则添加一个虚拟section，用来做翻页链接，该链接不交给delegate处理
    if (_mode == ERPSearchTableModeScrolling)
        groupCount += _hasMoreData;
    return groupCount;
}


#pragma mark TableView 单元格
- (UITableViewCell *)_getPagingCell:(UITableView *)tableView
{
    // 生成一个虚拟的cell用来翻页
    UITableViewCell *cell;
    cell = [tableView dequeueReusableCellWithIdentifier:PAGING_CELL_ID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:PAGING_CELL_ID];
        cell.textLabel.font = [UIFont systemFontOfSize:[UIFont smallSystemFontSize]];
        cell.textLabel.textColor = [UIColor grayColor];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.backgroundColor = [UIColor colorWithRed:.9 green:.9 blue:.9 alpha:1];
    }
    
    NSString *text;
    if (self.loading)
        text = @"正在加载...";
    else
        text = [NSString stringWithFormat:@"剩余%lu条记录，点击加载更多...", _totalRowCount - _rows.count];
    cell.textLabel.text = text;
    return cell;
}

// 设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self _isPagingSection:indexPath.section]) {
        return 30;
    } else {
        return tableView.rowHeight;
    }
}

// 生成cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self _isPagingSection:indexPath.section]) {
        // 翻页section
        return [self _getPagingCell:tableView];
    }
    
    NSDictionary *row = [self _dataForIndexPath:indexPath];
    UITableViewCell *cell;
    if (_delegateCellLayoutSel) {
        // delegate负责布局
        if (_delegateCellGenerationSel) {
            // 由delegate生成cell
            cell = [self.delegate cellFromTableView:tableView forData:row];
        } else {
            cell = [tableView dequeueReusableCellWithIdentifier:TEMPLATE_CELL_ID];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                              reuseIdentifier:TEMPLATE_CELL_ID];
            }
        }
        [self.delegate layoutTableCell:cell withData:row];
    } else {
        // 默认布局
        if (!self.titleProperty)
            NSLog(@"must specify titleProperty for ErpSearchTableController without delegate layout method");
        NSString *title = (row && self.titleProperty) ? (NSString *)[row objectForKey:self.titleProperty] : TITLE_NONE;
        
        if (self.showCellSubTitle) {
            cell = [tableView dequeueReusableCellWithIdentifier:TEMPLATE_SUBTITLED_CELL_ID];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                              reuseIdentifier:TEMPLATE_SUBTITLED_CELL_ID];
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                cell.textLabel.font = [UIFont systemFontOfSize:[UIFont labelFontSize] * .9];
                cell.detailTextLabel.textColor = [UIColor grayColor];
                /* TODO 垂直居中对齐detailTextLabel
                 UIFont *font = [UIFont systemFontOfSize:[UIFont smallSystemFontSize]];
                 cell.detailTextLabel.font = font;
                 */
            }
        } else {
            cell = [tableView dequeueReusableCellWithIdentifier:TEMPLATE_CELL_ID];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                              reuseIdentifier:TEMPLATE_CELL_ID];
            }
        }
        
        cell.textLabel.text = title;
        if (self.showCellSubTitle) {
            NSString *subTitle;
            if (row && self.subTitleProperty)
                subTitle = (NSString *)[row objectForKey:self.subTitleProperty];
            cell.detailTextLabel.text = subTitle;
        }
    }
    
    if (_delegateAfterCellLayoutSel)
        [self.delegate afterLayoutTableCell:cell withData:row];
    
    return cell;
}


#pragma mark TableView 行为
// 行选中事件
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // TODO 与数据加载同步，防止在读取数据时访问冲突
    // 取消选中状态
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self _performActionForIndexPath:indexPath];
}

- (void)_performActionForIndexPath:(NSIndexPath *)indexPath
{
    if ([self _isPagingSection:indexPath.section]) {
        [self loadMoreData];
    } else {
        NSDictionary *row = [self _dataForIndexPath:indexPath];
        if ([self.delegate respondsToSelector:@selector(didSelectRow:)])
            [self.delegate didSelectRow:row];
        else
            [JSUIUtils alert:[NSString stringWithFormat:@"%@", row] withTitle:nil];
    }
}


#pragma mark SearchBar 行为
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self reloadData];
}


#pragma mark ScrollView 行为：下拉刷新
// TODO 由indicator来计算pull距离，并返回状态
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (_mode != ERPSearchTableModeScrolling)
        return;
    
    if (![self loading])
        [self pullerPulling];
}
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (_mode != ERPSearchTableModeScrolling)
        return;
    
    if (![self loading])
        [self pullerReleased];
}

- (void)setupPuller
{
    RefreshIndicator *pullText = (RefreshIndicator *)[_tableView viewWithTag:PULL_DOWN_VIEW_TAG];
    if (!pullText) {
        CGRect tframe = CGRectMake(0, -PULL_DOWN_THRESHOLD, _tableView.frame.size.width, PULL_DOWN_THRESHOLD);
        pullText = [[RefreshIndicator alloc] initWithFrame:tframe
                                            defaultMessage:PULL_DOWN_TEXT_PULL_DOWN_TO_RELOAD
                                            releaseMessage:PULL_DOWN_TEXT_RELEASE_TO_RELOAD
                                            refreshMessage:PULL_DOWN_TEXT_RELOADING
                                           finishedMessage:PULL_DOWN_TEXT_LOADED];
        pullText.tag = PULL_DOWN_VIEW_TAG;
        [_tableView addSubview:pullText];
        [_tableView bringSubviewToFront:pullText];
    }
    [self setPullerState:RefreshIndicatorStateDefault];
}
- (void)setPullerState:(EnumRefreshIndicatorState)state
{
    RefreshIndicator *refreshIndicator = (RefreshIndicator *)[_tableView viewWithTag:PULL_DOWN_VIEW_TAG];
    [refreshIndicator setState:state];
}
- (void)pullerPulling
{
    if (_tableView.contentOffset.y < -PULL_DOWN_THRESHOLD) {
        [self setPullerState:RefreshIndicatorStateReleaseToRefresh];
    }
    else {
        [self setPullerState:RefreshIndicatorStateDefault];
    }
}
- (void)pullerReleased
{
    if (_tableView.contentOffset.y < -PULL_DOWN_THRESHOLD) {
        [self reloadData];
        CGPoint cp = _tableView.contentOffset;
        [self setPullerLayoutWithContentInsets:UIEdgeInsetsMake(PULL_DOWN_THRESHOLD, 0, 0, 0)
                             withContentOffset:CGPointMake(0, cp.y + PULL_DOWN_THRESHOLD)];
    }
    else {
        [self setPullerState:RefreshIndicatorStateDefault];
        UIEdgeInsets ue = _tableView.contentInset;
        CGPoint cp = _tableView.contentOffset;
        [self setPullerLayoutWithContentInsets:UIEdgeInsetsZero withContentOffset:CGPointMake(0, cp.y - ue.top)];
    }
}

- (void)setPullerLayoutWithContentInsets:(UIEdgeInsets)insets withContentOffset:(CGPoint)contentOffset
{
    [UIView beginAnimations:@"Curl" context:nil];
    [UIView setAnimationDuration:.2f];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    _tableView.contentInset = insets;
    [_tableView setContentOffset:contentOffset animated:YES];
    [UIView commitAnimations];
}

@end


