//
//  ChildPropertyPickerDataModel.h
//  ERP2.0
//
//  Created by jerei on 14-8-6.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Erp2.h"

@interface ChildPropertyPickerDataModel : NSObject<UIPickerViewDataSource, UIPickerViewDelegate>

/*!
 @abstract 数据集合，通常可以用dictionary作为值
 */
@property (nonatomic, readonly, copy) NSArray *data;
/*!
 @abstract 访问下级数据所使用的属性名称（对于dictionary来说是键名）
 */
@property (nonatomic, readonly, copy) NSString *childProperty;
/*!
 @abstract 匹配数据所使用的属性名，如果不指定则使用数据本身
 */
@property (nonatomic, readonly, copy) NSString *idProperty;
/*!
 @abstract 显示所使用的属性名称，如果不指定则使用对象的description
 */
@property (nonatomic, readonly, copy) NSString *textProperty;
/*!
 @abstract 数据访问层数
 */
@property (nonatomic, readonly, assign) NSInteger depth;

- (instancetype)initWithData:(NSArray *)data idProperty:(NSString *)idProperty textProperty:(NSString *)textProperty childProperty:(NSString *)childProperty depthOfData:(NSInteger)depth;

/*!
 @abstract selectedObjectsForAllComponents
 @param pickerView model所对应的pickerView
 @result 返回所有component对应的选择的数据，如果某个component没有选择数据，则该值为NSNull
 */
- (NSArray *)selectedObjectsForAllComponents:(UIPickerView *)pickerView;

/*!
 @abstract 获取某项数据的文本
 @param model中的某条数据
 @result 返回数据的显示文字
 */
- (NSString *)titleForDataItem:(id)dataItem;

/*!
 @abstract 为所有列指定选择数据
 @param pickerView
 @param selectedObjects 选定的对象的列表，列表长度可以小于列长度
 @param animated
 @param objectMatcher 负责匹配选择对象的block
 @result 是否找到匹配项
 */
- (BOOL)selectObjectsForAllComponents:(UIPickerView *)pickerView selectedObjects:(NSArray *)selectedObjects animated:(BOOL)animated objectMatcher:(BOOL(^)(id obj1, id obj2))objectMatcher;

/*!
 @param pickerView
 @abstract 为所有列指定选择数据
 @param selectedIndicies 选定的对象的索引列表，列表长度可以小于列长度
 @param animated
 */
- (void)selectObjectsByIndexForAllComponents:(UIPickerView *)pickerView selectedIndicies:(NSArray *)selectedIndicies animated:(BOOL)animated;
@end
