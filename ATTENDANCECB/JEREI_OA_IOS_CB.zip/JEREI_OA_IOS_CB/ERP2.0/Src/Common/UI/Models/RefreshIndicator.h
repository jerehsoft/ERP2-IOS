//
//  RefreshIndicator.h
//  ERP2.0
//
//  Created by 丁未汀 on 9/9/14.
//  Copyright (c) 2014 jerei. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    RefreshIndicatorStateDefault,
    RefreshIndicatorStateReleaseToRefresh,
    RefreshIndicatorStateRefreshing,
    RefreshIndicatorStateFinished
} EnumRefreshIndicatorState;


@interface RefreshIndicator : UIView

@property (nonatomic, assign) BOOL refreshing;
@property (nonatomic, assign) float pullDistance;
@property (nonatomic, assign) EnumRefreshIndicatorState state;

- (instancetype)initWithFrame:(CGRect)frame defaultMessage:(NSString *)defaultMessage releaseMessage:(NSString *)releaseMessage refreshMessage:(NSString *)refreshMessage finishedMessage:(NSString *)finishedMessage;
- (void)setState:(EnumRefreshIndicatorState)state pullOffset:(float)pullOffset;

@end
