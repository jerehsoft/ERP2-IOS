//
//  ChildPropertyPickerDataModel.m
//  ERP2.0
//
//  Created by jerei on 14-8-6.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ChildPropertyPickerDataModel.h"


@interface ChildPropertyPickerDataModel()
{
    NSMutableArray *_dataForComponents;
}

@end

@implementation ChildPropertyPickerDataModel

@synthesize data = _data;
@synthesize idProperty = _idProperty;
@synthesize textProperty = _textProperty;
@synthesize childProperty = _childProperty;
@synthesize depth = _depth;

- (instancetype)initWithData:(NSArray *)data idProperty:(NSString *)idProperty textProperty:(NSString *)textProperty childProperty:(NSString *)childProperty depthOfData:(NSInteger)depth
{
    if (self = [super init]) {
        _data = [data copy];
        if (!_data)
            _data = @[];
        _idProperty = idProperty;
        _textProperty = textProperty;
        _childProperty = childProperty;
        _depth = MAX(depth, 1);
        _dataForComponents = [[NSMutableArray alloc] initWithCapacity:_depth];
        // 初始化数据
        [_dataForComponents addObject:_data];
        for (int i = 1; i < _depth; ++i)
            [_dataForComponents addObject:[NSNull null]];
        [self _updateStatusForComponents:0 selectedRow:0];
    }
    return self;
}

- (void)dealloc
{
    _data = nil;
    _dataForComponents = nil;
    _textProperty = nil;
    _childProperty = nil;
    [self printDealloc];
}

#pragma mark 数据选择
- (NSArray *)selectedObjectsForAllComponents:(UIPickerView *)pickerView
{
    NSMutableArray *allSelected = [NSMutableArray arrayWithCapacity:_depth];
    for (int i = 0; i < _depth; ++i) {
        NSArray *list = [_dataForComponents objectAtIndex:i];
        if ([list isNull]) {
            [allSelected setObject:[NSNull null] atIndexedSubscript:i];
        } else {
            // 当前选择的数据
            NSInteger row = [pickerView selectedRowInComponent:i];
            id selected = (!list || row >= list.count) ? [NSNull null] : [list objectAtIndex:row];
            [allSelected setObject:selected atIndexedSubscript:i];
        }
    }
    return allSelected;
}

- (BOOL)selectObjectsForAllComponents:(UIPickerView *)pickerView selectedObjects:(NSArray *)selectedObjects animated:(BOOL)animated objectMatcher:(BOOL(^)(id obj1, id obj2))objectMatcher
{
    if (!objectMatcher) {
        objectMatcher = ^(id obj1, id obj2) {
            return [obj1 isEqual:obj2];
        };
    }
    
    BOOL matchFound = YES;
    NSMutableArray *selectedIndicies = [NSMutableArray arrayWithCapacity:selectedObjects.count];
    NSArray *objects = self.data;
    for (NSInteger i = 0, j = MIN(_depth, selectedObjects.count); i < j; ++i) {
        id selectedObject = [selectedObjects objectAtIndex:i];
        NSUInteger selectedIndex = [objects indexOfObjectPassingTest:^BOOL(id obj, NSUInteger idx, BOOL *stop) {
            return objectMatcher(obj, selectedObject);
        }];
        if (selectedIndex != NSNotFound) {
            id object = [objects objectAtIndex:selectedIndex];
            [selectedIndicies addObject:@(selectedIndex)];
            if (i < j - 1) {
                objects = [self _childRowsOfObject:object];
            }
        }
        else {
            NSLog(@"数据中未找到匹配，depth=%zd", i);
            matchFound = NO;
            break;
        }
    }
    [self selectObjectsByIndexForAllComponents:pickerView selectedIndicies:selectedIndicies animated:animated];
    return matchFound;
}
- (void)selectObjectsByIndexForAllComponents:(UIPickerView *)pickerView selectedIndicies:(NSArray *)selectedIndicies animated:(BOOL)animated
{
    for (int i = 0; i < selectedIndicies.count; ++i) {
        NSNumber *index = [selectedIndicies objectAtIndex:i];
        [pickerView selectRow:index.intValue inComponent:i animated:animated];
    }
}


- (NSString *)titleForDataItem:(id)dataItem
{
    if (_textProperty)
        return (NSString *)[dataItem valueForKey:_textProperty];
    else
        return [dataItem description];
}

#pragma mark 数据访问工具方法

- (NSArray *)_childRowsOfObjectByIndicies:(NSArray *)indicies
{
    NSAssert(indicies.count >= _depth, @"索引列表长度不能超过depth - 1");
    NSArray *objects = self.data;
    int i = 0;
    for (NSNumber *index in indicies) {
        if ([ObjectUtils isNilOrNull:index]) {
            NSLog(@"索引%d为空，查找终止，可能会意外返回上层的数据", i);
            return nil;
        }
        int idx = [index intValue];
        id object = [objects objectAtIndex:idx];
        objects = [self _childRowsOfObject:object];
        if (i == indicies.count - 1)
            return objects;
        ++i;
    }
    return nil;
}

- (NSArray *)_childRowsOfObject:(id)object
{
    if ([object isNull])
        return @[];
    
    BOOL isKeyValueCodingObject = [object isKindOfClass:[NSDictionary class]] || [object respondsToSelector:@selector(valueForKey:)];
    if (!isKeyValueCodingObject)
        isKeyValueCodingObject = [object respondsToSelector:NSSelectorFromString(self.childProperty)];
    NSArray *childList;
    if (isKeyValueCodingObject) {
        childList = (NSArray *)[NSObject isNilOrNull:[object valueForKey:self.childProperty] defaultObject:@[]];
    } else {
        childList = @[];
    }
    return childList;
}

- (void)_updateStatusForComponents:(NSInteger)component selectedRow:(NSInteger)row
{
    if (component >= _depth - 1)
        return;
    
    NSArray *list = [_dataForComponents objectAtIndex:component];
    id childList = [NSNull null];
    if (![list isNull]) {
        id picked = row >= list.count ? nil : [list objectAtIndex:row];
        childList = [self _childRowsOfObject:picked];
        if (!childList)
            childList = [NSNull null];
    }
    // 更新下一级数据
    [_dataForComponents setObject:childList atIndexedSubscript:component + 1];
    // 更新后续选择
    [self _updateStatusForComponents:component + 1 selectedRow:0];
}


#pragma mark PickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return _depth;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSArray *pickList = [_dataForComponents objectAtIndex:component];
    NSInteger rows = [pickList isNull] ? 0 : pickList.count;
    return rows;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSString *title;
    NSArray *pickList = (NSArray *)[_dataForComponents objectAtIndex:component];
    if (![pickList isNull]) {
        id object = [pickList objectAtIndex:row];
        title = [self titleForDataItem:object];
    }
    return title;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    [self _updateStatusForComponents:component selectedRow:row];
    while (component < _depth - 1)
        [pickerView reloadComponent:++component];
}

@end



/* testing code
 NSMutableArray *data1 = [NSMutableArray arrayWithCapacity:5];
 for (int i = 0; i < 5; ++i) {
 NSMutableDictionary *row = [NSMutableDictionary dictionaryWithObjectsAndKeys:@(i), [NSString stringWrapped:@(i)], nil];
 [row setValue:[NSString stringWithFormat:@"%d", i] forKey:@"name"];
 NSMutableArray *children = [NSMutableArray arrayWithCapacity:i];
 for (int j = 0; j < i + 3; ++j) {
 NSMutableDictionary *row2 = [NSMutableDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d_%d", i, j], @"name", nil];
 NSMutableArray *children2 = [NSMutableArray arrayWithCapacity:j + 2];
 for (int k = 0; k < j + 2; ++k) {
 NSDictionary *row3 = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d_%d_%d", i, j, k], @"name", nil];
 [children2 addObject:row3];
 }
 [row2 setObject:children2 forKey:@"children"];
 [children addObject:row2];
 }
 if (i > 1)
 [row setValue:children forKey:@"children"];
 [data1 addObject:row];
 }
 NSLog(@"%@", data1);
 ChildPropertyPickerDataModel *model = [[ChildPropertyPickerDataModel alloc] initWithData:data1 textProperty:@"name" childProperty:@"children" depthOfData:3];
 _temp = model;
 CGRect pf = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 200);
 UIPickerView *pv = [[UIPickerView alloc] initWithFrame:pf];
 pv.backgroundColor = [UIColor whiteColor];
 pv.dataSource = model;
 pv.delegate = model;
 [self.view addSubview:pv];
 */