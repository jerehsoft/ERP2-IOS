//
//  GroupedDataModel.h
//  ERP2.0
//
//  Created by jerei on 14-8-12.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract 分组数据模型
 */
@interface GroupedDataModel : NSObject

// 分组标题
@property (nonatomic, retain) NSString *title;
// 分组副标题
@property (nonatomic, retain) NSString *subTitle;
// 组内数据
@property (nonatomic, retain) NSMutableArray *data;

@end

