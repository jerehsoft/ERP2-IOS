//
//  ERPDateGroupedSearchTableHelper.m
//  ERP2.0
//
//  Created by jerei on 14-8-12.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPDateGroupedSearchTableHelper.h"

@implementation ERPDateGroupedSearchTableHelper
{
    NSCalendar *_calendar;
    NSDateFormatter *_dateFormatter;
}

- (ERPSearchTableHelper *)initWithTable:(UITableView *)tableView searchBar:(UISearchBar *)searchBar
{
    if (self = [super initWithTable:tableView searchBar:searchBar]) {
        _calendar = [ERPDefaults defaultCalendar];
        _dateFormatter = [[NSDateFormatter alloc] init];
        [_dateFormatter setDateFormat:@"yyyy年MM月dd日"];
    }
    return self;
}
#pragma mark 分组
- (NSString *)groupTitleForRow:(NSDictionary *)row
{
    NSString *todayTitle = [_dateFormatter stringFromDate:[NSDate date]];
    
    // 从json字符串解析的dictionary中的null均为NSNull
    id groupKey = [ObjectUtils isNilOrNull:[row valueForKey:self.groupProperty] defaultObject:nil];
    NSString *dateStr = (NSString *)groupKey;
    NSDate *date = [NSDate dateFromString:dateStr];
    NSString *groupTitle = [_dateFormatter stringFromDate:date];
    if ([todayTitle isEqualToString:groupTitle])
        groupTitle = @"今天";
    else if (!date)
        groupTitle = @"其他";
    return groupTitle;
}

- (NSString *)groupSubTitleForRow:(NSDictionary *)row
{
    NSString *subTitle;
    id groupKey = [ObjectUtils isNilOrNull:[row valueForKey:self.groupProperty] defaultObject:nil];
    NSString *dateStr = (NSString *)groupKey;
    if (dateStr && dateStr.length) {
        NSDate *date = [NSDate dateFromString:dateStr];
        NSDateComponents *dateComps = [_calendar components:NSCalendarUnitWeekday fromDate:date];
        NSString *weekday = [DateUtils weekDayName:dateComps.weekday];
        subTitle = [[[[date lunarCalendarDate] stringByReplacingOccurrencesOfString:@" "
                                                                         withString:@""]
                     stringByAppendingString:@"  周"] stringByAppendingString:weekday];
    }
    else {
        subTitle = @"";
    }
    return subTitle;
}
@end
