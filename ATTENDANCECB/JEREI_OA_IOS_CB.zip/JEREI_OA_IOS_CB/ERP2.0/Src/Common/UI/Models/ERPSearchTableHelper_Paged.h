//
//  ERPSearchTableHelper_Paged.h
//  ERP2.0
//
//  Created by jerei on 14-8-14.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPSearchTableHelper.h"

// 提供翻页的protected方法
// 如果不需要翻页方法，可以只包含ERPSearchTableHelper.h
@interface ERPSearchTableHelper (Paged)

@property (nonatomic, readonly, getter = pageId) NSInteger pageId;
@property (nonatomic, readonly, getter = totalRowCount) NSInteger totalRowCount;
@property (nonatomic, readonly, getter = pageCount) NSInteger pageCount;

// 加载数据
- (void)loadDataAtPage:(NSInteger)pageId;

// 如果pageId为1，则加载后清除之前的数据
- (void)loadDataAtPage:(NSInteger)pageId keyword:(NSString *)keyword;

@end
