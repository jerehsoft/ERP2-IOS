//
//  ErpSearchTableController.h
//  ERP2.0
//
//  Created by jerei on 14-7-30.
//  Copyright (c) 2014年 jerei. All rights reserved.
//
#import "Erp2.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "GroupedDataModel.h"
#import "JSUIUtils.h"

// 列表action分页参数
#define PARAM_KEY_PAGE @"page"
#define PARAM_KEY_ROWS @"rows"
#define PARAM_KEY_KEYWORD @"filter.keyWord"
#define SEARCH_TABLE_DEFAULT_PAGE_SIZE 20


/*!
 @abstract 处理SearchTableHelper事件和提供支持方法
 */
@protocol ERPSearchTableDelegate<NSObject>

@required
/*!
 @abstract 提供调用列表action时的http参数，必需提供的有bussinessNo,authNo,order(ASC|DESC),sort(排序字段)
 */
- (NSDictionary *)parametersForListAction;
/*!
 @abstract 选中数据
 */
- (void)didSelectRow:(NSDictionary *)row;

@optional
/*!
 @abstract 提供调用列表action时的http headers，可以返回nil
 */
- (NSDictionary *)headersForListAction;

/*!
 @abstract 由delegate负责生成tableCell，只有在delegate同时负责布局的时候才使用
 */
- (UITableViewCell *)cellFromTableView:(UITableView *)tableView forData:(NSDictionary *)data;
/*!
 @abstract 由delegate布局tableCell，如果没有为SearchTableController提titleProperty，则应该由delegate负责布局cell
 */
- (void)layoutTableCell:(UITableViewCell *)cell withData:(NSDictionary *)data;
/*!
 @abstract cell布局完成之后调用
 */
- (void)afterLayoutTableCell:(UITableViewCell *)cell withData:(NSDictionary *)data;

/*!
 @abstract 在controller加载数据之后对数据进行预处理，并返回新的数据
 */
- (NSArray *)preprocessData:(NSArray *)data;

/*!
 @abstract 数据更新通知
 */
- (void)dataUpdated;

@end

/*!
 @abstract 搜索列表行为
 */
typedef enum {
    ERPSearchTableModeScrolling = 0,    // 连续滚动，允许下拉刷新和列表末尾加载更多
    ERPSearchTableModePaging = 1    // 翻页
} ERPSearchTableMode;

/*!
 @abstract 分组搜索列表helper，部分翻页的属性和方法在ERPSearchTableHelper_Paged.h中提供
 */
@interface ERPSearchTableHelper : NSObject<UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate>
{
    // 翻页状态
    NSInteger _pageId;
    NSInteger _pageSize;
    NSInteger _totalRowCount;
}

// 翻页模式
@property (nonatomic, readonly) ERPSearchTableMode mode;

@property (nonatomic, retain) id<ERPSearchTableDelegate> delegate;

/*!
 @abstract 列表action的相对地址
 */
@property (nonatomic, retain) NSString *listActionUri;
/*!
 @abstract 分页大小
 */
@property (nonatomic, assign) NSInteger pageSize;
/*!
 @abstract 数据的主键属性
 */
@property (nonatomic, retain) NSString *keyProperty;
/*!
 @abstract 用于在cell中显示的属性
 */
@property (nonatomic, retain) NSString *titleProperty;
/*!
 @abstract 用于在cell中显示的副标题属性
 */
@property (nonatomic, retain) NSString *subTitleProperty;
/*!
 @abstract 用于分组cell的属性，配合groupTitleForRow/groupSubTitleForRow生成分组的标题
 */
@property (nonatomic, retain) NSString *groupProperty;
/*!
 关键字属性名
 */
@property (nonatomic, retain) NSString *keyWord;

@property (nonatomic, copy) NSString *rowsName;

/*!
 @abstract 是否显示cell的副标题
 */
@property (nonatomic, assign) BOOL showCellSubTitle;

/*!
 @abstract 下拉动画图片
 */
@property (nonatomic, strong)NSArray *loadingImgs;
@property (nonatomic, strong)NSArray *drawingImgs;

- (instancetype)initWithTable:(UITableView *)tableView searchBar:(UISearchBar *)searchBar;
- (instancetype)initWithTable:(UITableView *)tableView searchBar:(UISearchBar *)searchBar mode:(ERPSearchTableMode)mode;

/*!
 @abstract 重载点：分组标题
 */
- (NSString *)groupTitleForRow:(NSDictionary *)row;
/*!
 @abstract 重载点：分组副标题
 */
- (NSString *)groupSubTitleForRow:(NSDictionary *)row;

/*!
 @abstract 重新加载数据，重置pageid和数据，保留搜索条件
 */
- (void)reloadData;
/*!
 @abstract 加载下一页数据
 */
- (void)loadMoreData;

/*!
 @abstract 重置所有状态，清除数据
 */
- (void)reset;

/*!
 处理数据，分组
 */
- (void)_fillData:(ERPListActionResponseData *)listData pageId:(NSInteger)pageId;

/*!
 通知数据加载完成
 */
- (void)dataLoaded;

@end
