//
//  GroupedDataModel.m
//  ERP2.0
//
//  Created by jerei on 14-8-12.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "GroupedDataModel.h"


@implementation GroupedDataModel

- (id)init
{
    if (self = [super init]) {
        self.data = [[NSMutableArray alloc] initWithCapacity:10];
    }
    return self;
}

@end