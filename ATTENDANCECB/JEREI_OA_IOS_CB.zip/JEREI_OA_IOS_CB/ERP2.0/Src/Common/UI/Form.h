//
//  Form.h
//  ERP2.0
//
//  Created by jerei on 14-8-29.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "FormDataMapping.h"


@interface FormDataTableViewDeleate : NSObject<UITableViewDataSource, UITableViewDelegate>
- (instancetype)initWithData:(NSDictionary *)data mappingForData:(FormDataMapping *)mapping;
@end

@protocol ControlValueChangeListener <NSObject>
- (void)valueChangedForControl:(UIControl *)control;
- (void)textChangedForTextInput:(NSNotification *)textInputNotification;
@end

@protocol InputFocusDelegate <NSObject>
- (void)textInputFocused:(NSNotification *)textInputNotification;
- (void)controlFocused:(UIView *)control;
@end

@protocol FormValueDelegate <NSObject>
- (void)valueDidChange:(id)newValue oldValue:(id)oldValue forKey:(NSString *)key;
@end




@class FormCellInfo;
@class FormViewCell;

/*!
 @abstract cell输入组件控制
 */
@protocol FormViewCellInputHandler <NSObject>
@optional
/*!
 @abstract 为能够获取焦点的cell提供输入视图
 */
- (UIView *)inputViewForCell:(FormViewCell *)cell;
/*!
 @abstract 为能够获取焦点的cell提供键盘附件
 */
- (UIView *)inputAccessoryViewForCell:(FormViewCell *)cell;
/*!
 @abstract 检查cell是否能够获取焦点
 @param cell
 @param countTextFieldsIn 是否将cell内部可编辑的textField／textView计入
 */
- (BOOL)canBecomeFirstResponder:(FormViewCell *)cell countTextFieldsIn:(BOOL)countTextFieldsIn;
@end
