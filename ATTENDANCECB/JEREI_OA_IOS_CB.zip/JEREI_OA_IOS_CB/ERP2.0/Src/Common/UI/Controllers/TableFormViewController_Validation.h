//
//  TableFormViewController_Validation.h
//  ERP2.0
//
//  Created by 丁未汀 on 9/3/14.
//  Copyright (c) 2014 jerei. All rights reserved.
//

#import "TableFormViewController.h"

// 提供数据操作方法
@interface TableFormViewController(Validation)

/*!
 @abstract 验证指定属性
 @param propertyName
 @result 如果验证失败，则返回一个验证失败消息
 */
- (NSString *)validateValueForProperty:(NSString *)propertyName;

/*!
 @abstract 验证所有属性
 @result 返回验证失败的属性和验证消息组成的字典，以属性名为键。如果所有属性均验证成功则返回nil
 */
- (NSDictionary *)validateAllProperties;


/*!
 @abstract 验证单元格，并在单元格下方插入验证消息提示
 @param propertyName
 @result 是否验证通过
 */
- (BOOL)validateCellForProperty:(NSString *)propertyName;
/*!
 @abstract 验证全部单元格，并提示消息
 @result 是否全部验证通过
 */
- (BOOL)validateAllCells;

/*!
 @abstract 查找UI事件接收到的indexPath所对应的初始indexPath
 */
- (NSIndexPath *)initialIndexPathOf:(NSIndexPath *)uiIndexPath;
/*!
 @abstract 查找初始indexPath对应的在屏幕上的indexPath
 */
- (NSIndexPath *)arrangedIndexPathOf:(NSIndexPath *)initialIndexPath;

@end