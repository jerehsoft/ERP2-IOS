//
//  PagedSearchTableViewController.m
//  ERP2.0
//
//  Created by jerei on 14-8-14.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "PagedSearchTableViewController.h"
#import "FormDataMapping.h"

@interface PagedSearchTableViewController ()
{
    ERPSearchTableHelper *_searchController;
}

@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *btnFirstPage;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *btnPreviousPage;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *btnNextPage;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *btnLastPage;

@end

@implementation PagedSearchTableViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)dealloc
{
    _searchController.delegate = nil;
    _searchController = nil;
}

// 根据列表和单元格尺寸计算pageSize
- (int)_calculatePageSize
{
    //ios7 rowHeight是44，ios8 rowHeight默认-1，此处兼容性调整
    if(_tableView.rowHeight == -1){
        _tableView.rowHeight = 44;
    }
    int pageSize = (int)floor(_tableView.frame.size.height / _tableView.rowHeight);
    return pageSize;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.btnFirstPage.enabled =
    self.btnPreviousPage.enabled =
    self.btnNextPage.enabled =
    self.btnLastPage.enabled = NO;
    
    if (_searchBar) {
        CGRect frame = _searchBar.frame;
        frame.size.width = [UIScreen mainScreen].bounds.size.width;
        _searchBar.frame = frame;
    }
    _searchController = [[ERPSearchTableHelper alloc] initWithTable:self.tableView searchBar:self.searchBar mode:ERPSearchTableModePaging];
    _searchController.pageSize = [self _calculatePageSize];
    _searchController.delegate = self;
    
    if (self.blockForInitSearchController)
        self.blockForInitSearchController(_searchController);
    
    // 点击搜索框之外隐藏键盘
    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard:)];
    tapGR.delegate = self;
    [self.tableView addGestureRecognizer:tapGR];
    
    [_searchController reloadData];
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    // 若为UITableViewCellContentView（即点击了tableViewCell），则不截获Touch事件
    return ![JSUIUtils isViewInTableCell:touch.view];
}

- (void)hideKeyboard:(UITapGestureRecognizer *)sender
{
    [self.searchBar resignFirstResponder];
}

#pragma mark SearchTableControllerDelegate
- (NSDictionary *)parametersForListAction
{
    NSDictionary *params = nil;
    if (self.blockForSearchParams)
        params = self.blockForSearchParams();
    if (!params)
        params = @{};
    return params;
}

- (void)didSelectRow:(NSDictionary *)row
{
    if (self.blockForSelection)
        self.blockForSelection(row);
}

- (void)dataUpdated
{
    // 根据翻页状态更新翻页按钮样式
    NSInteger pageId = _searchController.pageId, pageCount = _searchController.pageCount;
    self.btnFirstPage.enabled =
    self.btnLastPage.enabled = pageCount > 0;
    self.btnPreviousPage.enabled = pageId > 1;
    self.btnNextPage.enabled = pageId < pageCount;
}

- (NSArray *)preprocessData:(NSArray *)data
{
    if (self.blockForPreProcessData)
        return self.blockForPreProcessData(data);
    else
        return data;
}

#pragma mark 按钮事件
- (IBAction)gotoFirstPage:(id)sender {
    [_searchController loadDataAtPage:1];
}
- (IBAction)gotoPreviousPage:(id)sender {
    [_searchController loadDataAtPage:_searchController.pageId - 1];
}
- (IBAction)gotoNextPage:(id)sender {
    [_searchController loadDataAtPage:_searchController.pageId + 1];
}
- (IBAction)gotoLastPage:(id)sender {
    [_searchController loadDataAtPage:_searchController.pageCount];
}
@end
