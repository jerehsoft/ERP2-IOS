//
//  PagedSearchTableViewController.h
//  ERP2.0
//
//  Created by jerei on 14-8-14.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSTableViewController.h"
#import "ERPSearchTableHelper_Paged.h"
#import "MasterDetailProtocol.h"
#import "JSViewController.h"
#import "JSUIUtils.h"

/*!
 @abstract 分页搜索tableViewController
 */
@interface PagedSearchTableViewController : JSViewController<ERPSearchTableDelegate, UIGestureRecognizerDelegate>

/*!
 @abstract 选定数据的回调block
 */
@property (nonatomic, copy) void(^blockForSelection)(id selectedValue);
/*!
 @abstract 用来初始化searchController的block，通常要为searchController设置listActionUrl,keyProperty,titleProperty等属性
 */
@property (nonatomic, copy) void(^blockForInitSearchController)(ERPSearchTableHelper *searchController);
/*!
 @abstract 用来为searchController提供初始查询参数的block
 */
@property (nonatomic, copy) NSDictionary*(^blockForSearchParams)();

@property (nonatomic, copy) NSArray*(^blockForPreProcessData)(NSArray * data);
@end
