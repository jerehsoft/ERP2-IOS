//
//  TableFormViewController.m
//  ERP2.0
//
//  Created by jerei on 14-8-11.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "TableFormViewController.h"
#import "TableFormViewController_DataManipulation.h"
#import "TableFormViewController_Validation.h"
#import "JSValidator.h"
//#import <Libs/KeyboardManager.framework/Headers/IQKeyboardManager.h>
#import "JSImage.h"
#import <KeyboardManager.h>

// 包含model的pickerView，用来在InputView中提供数据选择
// 对model进行强引用，避免自动释放
@interface StrongReferencedModelPickerView : UIPickerView<UIPickerViewDelegate>
{
    ChildPropertyPickerDataModel *__model;
    void (^dataSelectedCallback)(NSArray *selectedData, ChildPropertyPickerDataModel *model);
}
@property (nonatomic, readonly) ChildPropertyPickerDataModel *model;
- (instancetype)initWithModel:(ChildPropertyPickerDataModel *)model dataCallback:(void(^)(NSArray *selectedData, ChildPropertyPickerDataModel *model))callback;
@end

@implementation StrongReferencedModelPickerView
@synthesize model = __model;
- (instancetype)initWithModel:(ChildPropertyPickerDataModel *)model dataCallback:(void (^)(NSArray *selectedData, ChildPropertyPickerDataModel *model))callback
{
    if (self = [super init]) {
        __model = model;
        dataSelectedCallback = callback;
        self.dataSource = model;
        self.delegate = self;
    }
    return self;
}
- (void)dealloc
{
    __model = nil;
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [__model pickerView:pickerView titleForRow:row forComponent:component];
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    [__model pickerView:self didSelectRow:row inComponent:component];
    if (dataSelectedCallback) {
        NSArray *selectedData = [__model selectedObjectsForAllComponents:self];
        dataSelectedCallback(selectedData, __model);
    }
}
@end



@interface TableFormViewController ()<FormViewCellInputHandler>
{
    // 选择列表：当前数据列表
    NSArray *_currentSelectListData;
    
    // 记录对formdata的修改
    NSMutableDictionary *_formDataModifications;
    
    // FormViewCell.propertyName -> FormCellInfo映射
    NSDictionary *_propertyCellMap;
    
    // 属性A -> [ 引用属性A的属性B, 引用属性A的属性C, ... ]，按引用的距离正序排列
    NSDictionary *_propertyDependencyDestSrcListMap;
    
    // 是否已经初始化了cell键盘控制
    BOOL _formCellKeyboardConrolSet;
    
    // 表单项键盘附件
    UIToolbar *_inputAccessoryView;
    
    // section -> row -> FormCellInfo关系表
    // 如果按indexPath查找，应先根据indexPath.section找到section，然后从indexPath.row开始向后查找formCellInfo
    // 初始状态只有section和cell的映射，在验证时，在cell信息之后插入或删除validationMessage
    /*
     * <Section 0 Title>  ---  <Row 0 FormCellInfo>
     *                         [Row 0 Validation Message] 如果FormCellInfo.validationFailed则此行数据存在
     *                         <Row 1 FormCellInfo>
     *                         [Row 1 Validation Message]
     *                         <Row 2 FormCellInfo>
     *                         <Row 3 NSIndexPath> 非FormViewCell，只记录UITableViewCell的原始indexPath
     *                         <Row 4 FormCellInfo>
     *                         ...
     * <Section 1 Title>  ---  <Row 0 FormCellInfo>
     *                         <Row 1 FormCellInfo>
     *                         ...
     */
    NSMutableArray *_sectionRowList;
}
@end

@implementation TableFormViewController

- (void)__setup
{
    _currentSelectListData = nil;
    _formDataModifications = [NSMutableDictionary dictionaryWithCapacity:32];
    _propertyCellMap = nil;
    _propertyDependencyDestSrcListMap = nil;
    _formCellKeyboardConrolSet = NO;
    _inputAccessoryView = nil;
    _sectionRowList = nil;
}
- (void)__cleanup
{
    [ERPFormUtils unbindValueListener:self forFormController:self];
    [ERPFormUtils unbindFocusListener:self forFormController:self];
    self.formValueDelegate = nil;
    formData = nil;
    currentCellIndexPath = nil;
    _formDataModifications = nil;
    _currentSelectListData = nil;
    _propertyCellMap = nil;
    _propertyDependencyDestSrcListMap = nil;
    _inputAccessoryView = nil;
    _sectionRowList = nil;
}

- (id)init
{
    if (self = [super init]) {
        [self __setup];
    }
    return self;
}
- (id)initWithStyle:(UITableViewStyle)style
{
    if (self = [super initWithStyle:style]) {
        [self __setup];
    }
    return self;
}
- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {
        [self __setup];
    }
    return self;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        [self __setup];
    }
    return self;
}

- (void)dealloc
{
    [self __cleanup];
}

// 初始化form
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 关闭全局键盘管理，手动根据cell配置来管理键盘
    [[IQKeyboardManager sharedManager] setEnable:NO];
    
    // 映射属性到formCellInfo
    NSMutableDictionary *map = [NSMutableDictionary dictionaryWithCapacity:32];
    NSArray *formViewCells = [ERPFormUtils formCellInfosInFormController:self];
    for (FormCellInfo *fci in formViewCells) {
        [map setValue:fci forKey:fci.cell.propertyName];
    }
    _propertyCellMap = map;
    
    // 映射indexPath到formCellInfo
    NSInteger sectionCount = [self numberOfSectionsInTableView:self.tableView];
    NSMutableArray *sections = [NSMutableArray arrayWithCapacity:sectionCount];
    for (uint section = 0; section < sectionCount; ++section) {
        NSInteger rowCount = [self tableView:self.tableView numberOfRowsInSection:section];
        NSMutableArray *rows = [NSMutableArray arrayWithCopiesOfObjects:[NSNull null] count:(uint)rowCount];
        [sections addObject:rows];
        for (uint row = 0; row < rowCount; ++row) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:section];
            UITableViewCell *cell = [self tableView:self.tableView cellForRowAtIndexPath:indexPath];
            if ([cell isKindOfClass:[FormViewCell class]]) {
                FormViewCell *fvc = (FormViewCell *)cell;
                FormCellInfo *fci = [_propertyCellMap valueForKey:fvc.propertyName];
                [rows setObject:fci atIndexedSubscript:row];
            }
            else {
                [rows setObject:indexPath atIndexedSubscript:row];
            }
        }
    }
    _sectionRowList = sections;
    
    // 调整tableView的样式和行为以适应表单需要
    self.tableView.allowsMultipleSelection = NO;
    self.tableView.allowsSelection = YES;
    
    // 自动填表
    if ([self shouldAutoFillForm]) {
        [self fillForm];
    }
}

- (id)listDataProvider
{
    return self;
}


#pragma mark section - row映射
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger numberOfRows;
    if (!_sectionRowList)
        numberOfRows = [super tableView:tableView numberOfRowsInSection:section];
    else
        numberOfRows = [[_sectionRowList objectAtIndex:section] count];
    return numberOfRows;
}

#pragma mark indexPath映射
/*!
 @abstract 获取界面上的cell对应的初始indexPath，如果cell中包含的是验证消息，则返回nil，同时将messageForCell指向消息本身
 */
- (NSIndexPath *)initialIndexPathOf:(NSIndexPath *)uiIndexPath messageForCell:(NSString **)messageForCell
{
    if (messageForCell != NULL)
        *messageForCell = nil;
    
    if (!_sectionRowList)
        return uiIndexPath;
    
    // 查找界面上的cell所在的初始位置
    
    // 从ui传入的indexPath必定与_sectionRowList的索引对应
    // 如果指定位置是验证消息，则返回nil，如果是单元格，则返回单元格的初始indexPath
    NSArray *rowList = [_sectionRowList objectAtIndex:uiIndexPath.section];
    id rowObject = [rowList objectAtIndex:uiIndexPath.row];
    NSIndexPath *initialIndexPath;
    if ([rowObject isKindOfClass:[NSString class]]) {
        initialIndexPath = nil;
        if (messageForCell != NULL)
            *messageForCell = rowObject;
    }
    else if ([rowObject isKindOfClass:[NSIndexPath class]]) {
        initialIndexPath = rowObject;
    }
    else if ([rowObject isKindOfClass:[FormCellInfo class]]) {
        initialIndexPath = [rowObject indexPath];
    }
    return initialIndexPath;
}
- (NSIndexPath *)initialIndexPathOf:(NSIndexPath *)uiIndexPath
{
    return [self initialIndexPathOf:uiIndexPath messageForCell:NULL];
}

- (NSIndexPath *)arrangedIndexPathOf:(NSIndexPath *)initialIndexPath
{
    if (!_sectionRowList)
        return initialIndexPath;
    
    // 根据formCellInfo中的初始indexPath查找cell当前在界面上的位置
    
    // cell当前位置必定不会在初始位置之前
    NSArray *rowList = [_sectionRowList objectAtIndex:initialIndexPath.section];
    NSInteger row = initialIndexPath.row;
    NSUInteger rowCount = rowList.count;
    NSIndexPath *arrangedIndexPath = nil;
    for (; row < rowCount; ++row) {
        id rowObject = [rowList objectAtIndex:row];
        if ([rowObject isKindOfClass:[NSIndexPath class]]) {
            if ([initialIndexPath isEqual:rowObject]) {
                arrangedIndexPath = [NSIndexPath indexPathForRow:row inSection:initialIndexPath.section];
            }
        }
        else if ([rowObject isKindOfClass:[FormCellInfo class]]) {
            if ([initialIndexPath isEqual:[rowObject indexPath]]) {
                arrangedIndexPath = [NSIndexPath indexPathForRow:row inSection:initialIndexPath.section];
            }
        }
    }
    if (!arrangedIndexPath)
        NSLog(@"未找到arrangedIndexPath %@", initialIndexPath);
    return arrangedIndexPath;
}

/*!
 @abstract 根据界面上cell的indexPath查找对应的tableViewCell的初始位置，如果当前cell包含的是消息，则返回上一个位置的indexPath，并输出消息
 */
- (NSIndexPath *)parentCellIndexPathOf:(NSIndexPath *)uiIndexPath messageForCell:(NSString **)messageForCell
{
    NSIndexPath *cellIndexPath = [self initialIndexPathOf:uiIndexPath messageForCell:messageForCell];
    if (!cellIndexPath)
        cellIndexPath = [NSIndexPath indexPathForRow:uiIndexPath.row - 1 inSection:uiIndexPath.section];
    return cellIndexPath;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height;
    NSString *message = nil;
    NSIndexPath *cellInitialIndexPath = [self parentCellIndexPathOf:indexPath messageForCell:&message];
    if (!message) {
        height = [super tableView:tableView heightForRowAtIndexPath:cellInitialIndexPath];
    }
    else {
        // TODO 如果cell包含的是验证消息，则计算尺寸
        height = 25.0f;
    }
    return height;
}

- (NSInteger)tableView:(UITableView *)tableView indentationLevelForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSIndexPath *cellIndexPath = [self parentCellIndexPathOf:indexPath messageForCell:NULL];
    NSIndexPath *initialCellIndexPath = [self initialIndexPathOf:cellIndexPath messageForCell:NULL];
    return [super tableView:tableView indentationLevelForRowAtIndexPath:initialCellIndexPath];
}

#pragma mark 控制键盘附件

- (BOOL)preferPopInputForCell
{
    return NO;
}

- (FormViewCell *)cellForFormCellInfo:(FormCellInfo *)formCellInfo
{
    NSIndexPath *ip = [self arrangedIndexPathOf:formCellInfo.indexPath];
    return (FormViewCell *)[self tableView:self.tableView cellForRowAtIndexPath:ip];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *message = nil;
    NSIndexPath *initialIndexPath = [self initialIndexPathOf:indexPath
                                              messageForCell:&message];
    UITableViewCell *tableCell;
    if (message) {
        // validation message
        tableCell = [tableView dequeueReusableCellWithIdentifier:@"validationMessage"];
        if (!tableCell) {
            tableCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                               reuseIdentifier:@"validationMessage"];
            [tableCell.textLabel setFont:[UIFont systemFontOfSize:11]];
            [tableCell.textLabel setTextColor:[UIColor whiteColor]];
            [tableCell.textLabel setLineBreakMode:NSLineBreakByWordWrapping];
            [tableCell.textLabel setNumberOfLines:100];
            [tableCell setBackgroundColor:[UIColor colorWithRed:.7 green:0 blue:0 alpha:1]];
            [tableCell setUserInteractionEnabled:NO];
        }
        [tableCell.textLabel setText:message];
    }
    else {
        tableCell = [super tableView:tableView cellForRowAtIndexPath:initialIndexPath];
        if ([tableCell isKindOfClass:[FormViewCell class]]) {
            FormViewCell *formCell = (FormViewCell *)tableCell;
            FormCellInfo *cellInfo =   [self _formCellInfoForProperty:formCell.propertyName];
            formCell.cellInfo = cellInfo;
            cellInfo.inputHandler = self;
        }
    }
    return tableCell;
}

- (BOOL)_beginInputOnCurrentCell
{
    BOOL bioc;
    if ([self preferPopInputForCell]) {
        bioc = NO;
    }
    else {
        NSIndexPath *arrangedIndexPath = [self arrangedIndexPathOf:currentCellIndexPath];
        bioc = [self _beginInputOnCellOfIndexPath:arrangedIndexPath];
    }
    return bioc;
}

/*!
 @abstract 尝试在指定的cell上打开inputView
 */
- (BOOL)_beginInputOnCellOfIndexPath:(NSIndexPath *)indexPath
{
    // 让cell成为firstResponder，弹出输入组件
    UITableViewCell *tableCell = [self tableView:self.tableView cellForRowAtIndexPath:indexPath];
    
    // 如果cell处于不可见区域，则将其滚动到可见区域，同时赋予焦点
    // 滚动会有一些滞后（即使设置animated＝NO），所以要重载cell的becomeFirstResponder，返回canBecomeFirstResponder的值
    CGPoint contentOffset = self.tableView.contentOffset;
    CGRect cellRect = [self.tableView rectForRowAtIndexPath:indexPath];
    CGRect tableRect = self.tableView.frame;
    float minY = cellRect.origin.y - contentOffset.y;
    float maxY = minY + cellRect.size.height;
    BOOL needsScroll = maxY <= 0 || minY >= tableRect.size.height;
    if (needsScroll) {
        [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
    }
    
    BOOL becameFirstResponder = [tableCell becomeFirstResponder];
    return becameFirstResponder;
}

/*!
 @abstract 检查cell是否需要提供自定义输入组件
 */
- (BOOL)_requiresCustomInputViewForCell:(FormViewCell *)cell
{
    BOOL result;
    // 只有要为其提供inputView的cell才能成为firstResponder
    if ([ERPFormUtils containsEditableTextView:cell]) {
        result = NO;
    }
    else if (cell.defaultInputType == FormViewCellInputTypeDefault) {
        result = NO;
    }
    else {
        result = YES;
    }
    return result;
}

#pragma mark FormViewCellInputHandler 为cell提供输入inputView和inputAccessoryView
- (BOOL)canBecomeFirstResponder:(FormViewCell *)cell countTextFieldsIn:(BOOL)countTextFieldsIn
{
    BOOL cbfr;
    // 使用自定义输入组件，或包含可编辑的文本组件的cell才能获取焦点
    if (!cell.userInteractionEnabled)
        cbfr = NO;
    else if ([self _requiresCustomInputViewForCell:cell])
        cbfr = YES;
    else if (countTextFieldsIn && [ERPFormUtils containsEditableTextView:cell])
        cbfr = YES;
    else
        cbfr = NO;
    return cbfr;
}


// 为cell提供输入组件
- (UIView *)inputViewForCell:(FormViewCell *)cell
{
    UIView *inputView;
    // 所提供的输入组件在隐藏时
    // 根据cell属性提供inputview
    if (cell.defaultInputType == FormViewCellInputTypeList) {
        // 选择数据源selector
        NSArray *selectData = [cell listDataFromProvider:[self listDataProvider]];
        __weak TableFormViewController *weakSelf = self;
        ChildPropertyPickerDataModel *model;
        model = [[ChildPropertyPickerDataModel alloc] initWithData:selectData
                                                        idProperty:cell.propertyListIdPropertyName
                                                      textProperty:cell.propertyListTextPropertyName
                                                     childProperty:nil
                                                       depthOfData:1];
        StrongReferencedModelPickerView *pv;
        pv = [[StrongReferencedModelPickerView alloc] initWithModel:model
                                                       dataCallback:^(NSArray *selectedData, ChildPropertyPickerDataModel *model) {
                                                           [weakSelf valueSelected:selectedData dataModel:model];
                                                       }];
        // 根据cell的当前值设置组件的选择状态
        id value = [self currentValueForProperty:cell.propertyName];
        BOOL selected = NO;
        if (value) {
            selected = [pv.model selectObjectsForAllComponents:pv
                                               selectedObjects:@[value]
                                                      animated:NO
                                                 objectMatcher:^BOOL(id obj1, id obj2) {
                                                     id key1 = [obj1 valueForKey:cell.propertyListIdPropertyName];
                                                     id key2 = obj2;
                                                     NSString *strKey1 = [ObjectUtils convertData:key1 toType:[NSString class]];
                                                     NSString *strKey2 = [ObjectUtils convertData:key2 toType:[NSString class]];
                                                     return [strKey1 isEqualToString:strKey2] || (!strKey1 && !strKey2);
                                                 }];
        }
        // 如果没有匹配的项，而且model中有数据，则选择第一条数据
        if (!selected && model.data.count) {
            [pv.model selectObjectsByIndexForAllComponents:pv selectedIndicies:@[@0] animated:YES];
            // 触发选择
            [pv pickerView:pv didSelectRow:0 inComponent:0];
        }
        inputView = pv;
    }
    else if (cell.defaultInputType == FormViewCellInputTypeDate) {
        // 日期
        UIDatePicker *pv = [[UIDatePicker alloc] init];
        [pv addTarget:self action:@selector(_inputViewDatePickerValueChanged:) forControlEvents:UIControlEventValueChanged];
        [pv setDatePickerMode:UIDatePickerModeDate];
        // 设置选择状态
        id value = [self currentValueForProperty:cell.propertyName];
        if (value) {
            NSDate *date = [ObjectUtils convertData:value toType:[NSDate class]];
            [pv setDate:date animated:YES];
        }
        else {
            // 如果没有值，则默认选择当前值
            [pv sendActionsForControlEvents:UIControlEventValueChanged];
        }
        inputView = pv;
    }
    else {
        // 未知类型，不提供输入组件
        NSLog(@"未知cell类型，无法提供inputView : %@", cell);
        inputView = nil;
    }
    return inputView;
}

- (void)_inputViewDatePickerValueChanged:(UIDatePicker *)picker
{
    NSDate *date = picker.date;
    FormViewCell *currentCell = [self _currentFormCell];
    [self updateModelWithValue:date forProperty:currentCell.propertyName isValueAListItem:NO otherModifications:nil];
}

#define TABLE_FORM_INPUT_ACCESSORY_HEIGHT 44
#define TABLE_FORM_INPUT_ACCESSORY_PADDING 10
#define TABLE_FORM_INPUT_ACCESSORY_TAG_PREV 1
#define TABLE_FORM_INPUT_ACCESSORY_TAG_NEXT 2
#define TABLE_FORM_INPUT_ACCESSORY_TAG_CLEAR 11
#define TABLE_FORM_INPUT_ACCESSORY_TAG_DONE 12
#define TABLE_FORM_INPUT_ACCESSORY_TAG_TITLE 99

// 为cell提供键盘附件
- (UIView *)inputAccessoryViewForCell:(FormViewCell *)cell
{
    if (!_inputAccessoryView) {
        CGRect iavFrame = CGRectMake(0, 0, self.tableView.bounds.size.width, TABLE_FORM_INPUT_ACCESSORY_HEIGHT);
        _inputAccessoryView = [[UIToolbar alloc] initWithFrame:iavFrame];
        
        UIBarButtonItem *prevBarItem, *nextBarItem, *gapBarItem, *gapBarItem2, *clearBarItem, *doneBarItem;
        UIBarButtonItem *titleItem;
        // 前后导航
        UIImage *btnImageLeft = [UIImage imageNamed:@"IQButtonBarArrowLeft@2x.png"];
        UIImage *btnImageRight = [UIImage imageNamed:@"IQButtonBarArrowRight@2x.png"];
        prevBarItem = [self _barButtonForInputAccessoryView:btnImageLeft
                                                   selector:@selector(_previousForInputAccessoryView:)
                                                        tag:TABLE_FORM_INPUT_ACCESSORY_TAG_PREV];
        nextBarItem = [self _barButtonForInputAccessoryView:btnImageRight
                                                   selector:@selector(_nextForInputAccessoryView:)
                                                        tag:TABLE_FORM_INPUT_ACCESSORY_TAG_NEXT];
        gapBarItem = [self _barButtonForInputAccessoryView:nil selector:0 tag:0];
        // cell标题
        titleItem = [self _barButtonForInputAccessoryView:@""
                                                 selector:nil
                                                      tag:TABLE_FORM_INPUT_ACCESSORY_TAG_TITLE];
        titleItem.enabled = NO;
        gapBarItem2 = [self _barButtonForInputAccessoryView:nil selector:0 tag:0];
        // 功能按钮
        clearBarItem = [self _barButtonForInputAccessoryView:@"清除"
                                                    selector:@selector(_clearForInputAccessoryView:)
                                                         tag:TABLE_FORM_INPUT_ACCESSORY_TAG_CLEAR];
        doneBarItem = [self _barButtonForInputAccessoryView:@"完成"
                                                   selector:@selector(_doneForInputAccessoryView:)
                                                        tag:TABLE_FORM_INPUT_ACCESSORY_TAG_DONE];
        _inputAccessoryView.items = @[prevBarItem, nextBarItem, gapBarItem, titleItem, gapBarItem2, clearBarItem, doneBarItem];
    }
    [self _updateInputAccessoryViewForCell:cell];
    return _inputAccessoryView;
}

// 根据cell定义更新附件的样式
- (void)_updateInputAccessoryViewForCell:(FormViewCell *)cell
{
    FormCellInfo *formCellInfo = [self _formCellInfoForProperty:cell.propertyName];
    if ([formCellInfo.cell isMemberOfClass:[UITableViewCell class]]) {
        NSLog(@"Invalid cell type");
    }
    UIBarButtonItem *titleItem = [[_inputAccessoryView items] objectAtIndex:3];
    [titleItem setTitle:formCellInfo.cell.propertyLabelText];
    UIBarButtonItem *prevItem = [[_inputAccessoryView items] objectAtIndex:0];
    FormCellInfo *prevEditableSibling = [self _editableSiblingOfCell:formCellInfo direction:-1];
    [prevItem setEnabled:prevEditableSibling != nil];
    FormCellInfo *nextEditableSibling = [self _editableSiblingOfCell:formCellInfo direction:1];
    UIBarButtonItem *nextItem = [[_inputAccessoryView items] objectAtIndex:1];
    [nextItem setEnabled:nextEditableSibling != nil];
}

- (UIBarButtonItem *)_barButtonForInputAccessoryView:(id)content selector:(SEL)selector tag:(uint)tag
{
    UIBarButtonItem *btn;
    if ([content isKindOfClass:[NSString class]]) {
        NSString *title = (NSString *)content;
        btn = [[UIBarButtonItem alloc] initWithTitle:title
                                               style:UIBarButtonItemStylePlain
                                              target:self
                                              action:selector];
    }
    else if ([content isKindOfClass:[UIImage class]]) {
        UIImage *img = (UIImage *)content;
        // 调整image尺寸
        int h = TABLE_FORM_INPUT_ACCESSORY_HEIGHT - TABLE_FORM_INPUT_ACCESSORY_PADDING * 2;
        CGSize newSize = [JSUIUtils aspectScaleSize:img.size to:CGSizeMake(h, h)];
        img = [img imageScaledToSmallerSize:newSize];
        btn = [[UIBarButtonItem alloc] initWithImage:img
                                               style:UIBarButtonItemStylePlain
                                              target:self
                                              action:selector];
    }
    else if (!content) {
        btn =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                                           target:nil
                                                           action:nil];
    }
    else {
        btn = nil;
    }
    btn.tag = tag;
    return btn;
}
- (void)_previousForInputAccessoryView:(id)sender
{
    // 聚焦到上一个cell
    FormCellInfo *currentCellInfo = [self _formCellInfoForProperty:[[self _currentFormCell] propertyName]];
    if (![self _trySelectSiblingOfCell:currentCellInfo direction:-1]) {
        NSLog(@"未找到当前cell或目标cell");
    }
}
- (void)_nextForInputAccessoryView:(id)sender
{
    // 聚焦到下一个cell
    FormCellInfo *currentCellInfo = [self _formCellInfoForProperty:[[self _currentFormCell] propertyName]];
    if (![self _trySelectSiblingOfCell:currentCellInfo direction:1]) {
        NSLog(@"未找到当前cell或目标cell");
    }
}
- (BOOL)_trySelectSiblingOfCell:(FormCellInfo *)cellInfo direction:(int)direction
{
    NSAssert(direction != 0, @"必须指定查找方向: >0 next, <0 previous");
    FormCellInfo *targetCell = [self _editableSiblingOfCell:cellInfo direction:direction];
    NSLog(@"dir -> %d\nsrc -> %@\ntarget -> %@", direction, cellInfo, targetCell);
    if (targetCell) {
        // TODO 提供配置，允许跳过手动处理的cell（既不由formController提供输入，也不包含可编辑文本控件的cell），或是为手动处理的cell提供导航接口方法
        NSIndexPath *targetCellIndexPath = [targetCell indexPath];
        targetCellIndexPath = [self arrangedIndexPathOf:targetCellIndexPath];
        [self tableView:self.tableView didSelectRowAtIndexPath:targetCellIndexPath];
        [self _updateInputAccessoryViewForCell:targetCell.cell];
        return true;
    }
    else {
        return false;
    }
}
// 按指定方向查找可编辑的cell
- (FormCellInfo *)_editableSiblingOfCell:(FormCellInfo *)cellInfo direction:(int)direction
{
    NSAssert(direction != 0, @"必须指定查找方向: >0 next, <0 previous");
    FormCellInfo *targetCell = direction > 0 ? [cellInfo nextSibling] : [cellInfo previousSibling];
    // 如果指定cell不能接受焦点，则顺序向指定方向查找
    // 这里需要计入cell内部可编辑的文本控件
    while (targetCell && ![self canBecomeFirstResponder:[targetCell cell] countTextFieldsIn:YES]) {
        targetCell = direction > 0 ? [targetCell nextSibling] : [targetCell previousSibling];
    }
    return targetCell;
}
- (void)_clearForInputAccessoryView:(id)sender
{
    BOOL isList = [[self _currentFormCell] defaultInputType] == FormViewCellInputTypeList;
    [self updateModelWithValue:nil isValueAListItem:isList otherModifications:nil];
}
- (void)_doneForInputAccessoryView:(id)sender
{
    [self _closeKeyboard];
}



#pragma mark 填表控制

- (BOOL)shouldAutoFillForm
{
    return YES;
}

- (void)fillForm
{
    // 填表，如果容器所在的controller会导航到其他controller，则不应该在view*Appear中填表，防止在返回时重新填表
    [ERPFormUtils fillForm:self withDictionary:formData withListDataProvider:[self listDataProvider]];
    [ERPFormUtils bindValueListener:self forFormController:self];
    [ERPFormUtils bindFocusListener:self forFormController:self];
    
    [self didFillForm];
}

- (void)didFillForm
{
}



#pragma mark 控件辅助方法

- (UITableViewCell *)_currentCell
{
    NSIndexPath *indexPath = currentCellIndexPath;
    indexPath = [self arrangedIndexPathOf:indexPath];
    return [self tableView:self.tableView cellForRowAtIndexPath:indexPath];
}
- (FormViewCell *)_currentFormCell
{
    UITableViewCell *cell = [self _currentCell];
    if ([cell isKindOfClass:[FormViewCell class]])
        return (FormViewCell *)cell;
    else
        return nil;
}

- (void)_reloadForm
{return;
    if (currentCellIndexPath)
        [self.tableView reloadData];
}

- (void)_closeKeyboard
{
    // 关闭键盘
    UIResponder *responder = [JSUIUtils findFirstResponderInView:self.view];
    [responder resignFirstResponder];
}



#pragma mark TableViewSelection

- (BOOL)cellSelectionHandledForIndexPath:(NSIndexPath *)indexPath
{
    return NO;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSIndexPath *initialIndexPath = [self parentCellIndexPathOf:indexPath messageForCell:NULL];
    [self selectAndEditRowAtIndexPath:initialIndexPath calledByCellSelection:YES];
}

/*!
 @abstract 选择指定行，并根据cell的属性开始编辑
 @param indexPath
 @param calledByCellSelection 指示当前调用是否从cell的选择事件触发
 */
- (void)selectAndEditRowAtIndexPath:(NSIndexPath *)indexPath calledByCellSelection:(BOOL)calledByCellSelection
{
    // 清除上一个cell的inputView引用，避免事件延迟触发，赋值到其他字段
    if (currentCellIndexPath && ![currentCellIndexPath isEqual:indexPath]) {
        NSIndexPath *arrangedIndexPath = [self arrangedIndexPathOf:currentCellIndexPath];
        UITableViewCell *currentCell = [self tableView:self.tableView cellForRowAtIndexPath:arrangedIndexPath];
        if ([currentCell isKindOfClass:[FormViewCell class]]) {
            ((FormViewCell *)currentCell).isCurrent = NO;
        }
    }
    
    // 记录当前编辑行
    currentCellIndexPath = indexPath;
    UITableViewCell *currentCell = [self _currentCell];
    FormViewCell *currentFormCell = nil;
    if ([currentCell isKindOfClass:[FormViewCell class]]) {
        currentFormCell = (FormViewCell *)currentCell;
        currentFormCell.isCurrent = YES;
    }
    
    // 选择cell
    NSIndexPath *arrangedIndexPath = [self arrangedIndexPathOf:currentCellIndexPath];
    [self.tableView selectRowAtIndexPath:arrangedIndexPath
                                animated:YES
                          scrollPosition:UITableViewScrollPositionNone];
    
    // 如果是从输入组件focus发起的调用，则不应该试图关闭键盘
    // 检查下一个cell是否提供输入组件，如果没有则关闭键盘
    if (calledByCellSelection && ![self _requiresCustomInputViewForCell:currentFormCell]) {
        [self _closeKeyboard];
    }
    
    // 提供预先处理输入的接口
    if ([self cellSelectionHandledForIndexPath:indexPath])
        return;
    
    // 处理表单元素
    [self _handleFormItem:currentCell calledByCellSelection:calledByCellSelection];
}

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSIndexPath *initialIndexPath = [self initialIndexPathOf:indexPath messageForCell:NULL];
    if (!initialIndexPath) {
        // 验证消息
        return nil;
    }
    else {
        UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
        if ([cell isKindOfClass:[FormViewCell class]]) {
            FormViewCell *fvc = (FormViewCell *)cell;
            // 如果cell的依赖项没有满足则禁止选择
            NSMutableOrderedSet *unsatisfiedCells;
            if (![self _isDependencySatisfied:fvc unsatisfiedCells:&unsatisfiedCells]) {
                // 提示依赖项
                NSMutableString *depMessage = [NSMutableString stringWithCapacity:64];
                if (unsatisfiedCells && unsatisfiedCells.count) {
                    [depMessage appendString:@"请先填写"];
                    for (FormViewCell *unsDepCell in unsatisfiedCells) {
                        [depMessage appendString:unsDepCell.propertyLabelText];
                        [depMessage appendString:@","];
                    }
                    [depMessage deleteCharactersInRange:NSMakeRange(depMessage.length - 1, 1)];
                }
                else {
                    [depMessage appendString:@"未找到依赖项目"];
                }
                
                [JSUIUtils toastForView:tableView.superview withMessage:depMessage forDuration:3];
                return nil;
            }
        }
    }
    return indexPath;
}

// 检查cell的依赖项是否都满足，验证依赖项的值和关联的依赖项，注意应该避免循环依赖
- (BOOL)_isDependencySatisfied:(FormViewCell *)formViewCell unsatisfiedCells:(NSMutableOrderedSet **)unsatisfiedCells
{
    // 如果没有找到依赖的cell也不满足依赖
    if (!formViewCell) {
        NSLog(@"未找到依赖项");
        return NO;
    }
    for (NSString *dep in formViewCell.dependentPropertyNames) {
        FormViewCell *depCell = [self _formCellInfoForProperty:dep].cell;
        // 检查cell的值是否合法，这里不指定目标类型，因为很多时候会在绘制table的时候省略掉propertyType属性
        // TODO 检查cell的值是否符合验证规则
        if (depCell && ![ERPFormUtils isValueValid:depCell.cellInfo.value forType:nil]) {
            if (!*unsatisfiedCells) {
                *unsatisfiedCells = [NSMutableOrderedSet orderedSetWithCapacity:3];
            }
            [*unsatisfiedCells addObject:depCell];
            return NO;
        }
        if (![self _isDependencySatisfied:depCell unsatisfiedCells:unsatisfiedCells]) {
            return NO;
        }
    }
    return YES;
}

// 根据propertyName寻找formViewCell
- (FormCellInfo *)_formCellInfoForProperty:(NSString *)propertyName
{
    return [_propertyCellMap valueForKey:propertyName];
}


#pragma mark 表单输入控制
// 处理表单元素
- (void)_handleFormItem:(UITableViewCell *)cell calledByCellSelection:(BOOL)calledByCellSelection
{
#ifdef FORMVIEWCONTROLLER_LOGGABLE
    NSString *title = cell.textLabel.text;
    NSLog(@"cell tag = %zd, title = %@, cell = %@", cell.tag, title, cell);
#endif
    // 处理自定义cell
    if ([cell isKindOfClass:[FormViewCell class]]) {
        FormViewCell *formCell = (FormViewCell *)cell;
#ifdef FORMVIEWCONTROLLER_LOGGABLE
        NSLog(@"cell is propertyListDataSelector : %@", formCell);
#endif
      
        // 如果是从输入组件focus发起的调用，则不应该试图让cell处理输入
        // 先尝试由cell自己处理输入，如果cell无法自己处理，则根据属性定义使用其他输入组件
        if (calledByCellSelection && [self _beginInputOnCurrentCell]) {
            // 输入已被cell处理，不再进行后续步骤
        }
        else {
            if (formCell.propertyListDataSelector && formCell.propertyListDataSelector.length) {
                // 选择数据源selector
                [self _handleCustomSelectFormItem:formCell];
            }
            else {
                // 根据字段类型选择输入组件
                [self _handleCustomFormItemByType:formCell calledByCellSelection:calledByCellSelection];
            }
        }
    }
    else {
        // 处理普通的表单元素
        // 如果是从cell内部控件的focus事件调用，则不应该尝试将焦点转移给内部的控件，避免死循环
        [self _handleCommonFormItem:cell tryFocus:calledByCellSelection];
    }
}

- (void)_handleCustomSelectFormItem:(FormViewCell *)formCell
{
    // TODO 提供actionSheet/tableView/picker方式选择数据
    NSArray *selectData = [formCell listDataFromProvider:[self listDataProvider]];
#ifdef FORMVIEWCONTROLLER_LOGGABLE
    NSLog(@"select data = %@", selectData);
#endif
    // picker选择数据
    [self _beginSingleSelectDataWithPicker:selectData
                            withIdProperty:formCell.propertyListIdPropertyName
                          withTextProperty:formCell.propertyListTextPropertyName];
}

- (void)_handleCustomFormItemByType:(FormViewCell *)formCell calledByCellSelection:(BOOL)calledByCellSelection
{
    if (formCell.propertyClass == [NSDate class]) {
        // 日期
        [self _beginInputDate:formCell];
    }
    else {
        // 如果有默认的输入组件，则尝试将焦点移动到组件上
        if (calledByCellSelection && ![JSUIUtils tryFocusOnFirstInput:formCell]) {
            // TODO 以文本方式输入内容
            NSLog(@"cell accepts text");
        }
    }
}

- (void)_handleCommonFormItem:(UITableViewCell *)cell tryFocus:(BOOL)tryFocus
{
    if (tryFocus) {
        // 尝试将焦点移动到第一个可见的输入组件上
        [JSUIUtils tryFocusOnFirstInput:cell];
    }
    else {
        // TODO 处理无法接受焦点的cell
        NSLog(@"TODO");
    }
}



#pragma mark 数据操作(由DataManipulation扩展提供对外接口)

- (NSDictionary *)_buildDependencyMap
{
    typedef NSMutableDictionary Map;
    
    // 1. 创建属性到它所依赖属性的映射表
    // 属性 -> { 目标属性1 : 依赖距离1 = 0, 目标属性2 : 依赖距离2 = 0, ... }
    Map *depSrcDestMap = [Map dictionaryWithCapacity:32];
    NSArray *formViewCells = [ERPFormUtils formCellInfosInFormController:self];
    for (FormCellInfo *fci in formViewCells) {
        NSSet *destProps = fci.cell.dependentPropertyNames;
        if (destProps && destProps.count) {
            Map *destPropMap = [Map dictionaryWithCapacity:destProps.count];
            for (NSString *destProp in destProps)
                [destPropMap setValue:@0 forKey:destProp];
            [depSrcDestMap setValue:destPropMap forKey:fci.cell.propertyName];
        }
    }

    // 2. 计算某个属性到它所依赖的属性的最长距离，同时计算某个被引用的属性有哪些属性依赖它以及依赖的最长距离
    // 属性 -> { 目标属性1 : 依赖距离1, 目标属性2 : 依赖距离2, ... }
    static void (^ const calcDependentDepth)(Map *, Map *, NSString *, NSString *, uint, Map *) = ^(Map *refSrcDestMap/* 参考依赖关系表 */, Map *rootPropMap/* 要向其中添加的根属性->距离映射表 */, NSString *rootProp/* 根属性，用于保证不会死循环 */, NSString *srcProp/* 要计算距离的属性 */, uint depth/* 当前递归层数 */, Map *destSrcMap/* 依赖于某个属性的属性及引用距离列表 */) {
        // 防止属性引用形成环
        if (depth > 1 && [rootProp isEqualToString:srcProp])
            return;
        
        // 根据srcProp获取destProp的依赖关系，如果destProp存在依赖关系，则更新rootMap中destProp的距离为depth
        Map *destProps = [[refSrcDestMap valueForKey:srcProp] copy];
        if (destProps) {
            // 有依赖关系
            for (NSString *destProp in destProps) {
                NSNumber *destDepth = (NSNumber *)[rootPropMap valueForKey:destProp];
                // 记录最长引用距离
                if (!destDepth || destDepth.unsignedIntValue < depth) {
                    [rootPropMap setValue:@(depth) forKey:destProp];
                    // 依赖属性清单映射表，反向映射属性引用
                    Map *srcPropDistMap = [destSrcMap valueForKey:destProp];
                    if (!srcPropDistMap) {
                        srcPropDistMap = [Map dictionaryWithCapacity:4];
                        [destSrcMap setValue:srcPropDistMap forKey:destProp];
                    }
                    [srcPropDistMap setValue:@(depth) forKey:rootProp];
                }
                // 检查destProp的依赖关系
                calcDependentDepth(refSrcDestMap, rootPropMap, rootProp, destProp, depth + 1, destSrcMap);
            }
        }
    };
    // 属性依赖映射：被依赖的属性A -> { 依赖于属性A的属性B : 属性B到属性A的距离, 依赖于属性A的属性C : 属性C到属性A的距离, ... }
    // 此表是depSrcDestMap的反向映射
    Map *depDestSrcMap = [Map dictionaryWithCapacity:32];
    for (NSString *srcProp in depSrcDestMap) {
        calcDependentDepth(depSrcDestMap, [depSrcDestMap valueForKey:srcProp], srcProp, srcProp, 1, depDestSrcMap);
    }
    
    // 3. 为每个存在依赖属性的属性映射到依赖于它的属性的列表，列表按依赖距离长度正序排列
    // 整理被引用属性的引用属性，按距离正序排列
    Map *destSrcPropListMap = [Map dictionaryWithCapacity:depDestSrcMap.count];
    for (NSString *destProp in depDestSrcMap) {
        Map *srcDistMap = [depDestSrcMap valueForKey:destProp];
        // 搜集属性依赖关系和依赖距离
        NSMutableArray *srcDistList = [NSMutableArray arrayWithCapacity:srcDistMap.count];
        for (NSString *srcProp in srcDistMap) {
            [srcDistList addObject:@[ srcProp, [srcDistMap valueForKey:srcProp] ]];
        }
        // 按照距离远近正序排列源属性
        [srcDistList sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
            uint dist1 = [[obj1 objectAtIndex:1] unsignedIntValue];
            uint dist2 = [[obj2 objectAtIndex:1] unsignedIntValue];
            return dist1 > dist2 ? NSOrderedDescending : (dist1 < dist2 ? NSOrderedAscending : NSOrderedSame);
        }];
        // 丢弃距离，只保留属性名
        NSMutableArray *srcPropList = [NSMutableArray arrayWithCapacity:srcDistList.count];
        for (NSArray *srcDist in srcDistList) {
            [srcPropList addObject:[srcDist objectAtIndex:0]];
        }
        [destSrcPropListMap setValue:srcPropList forKey:destProp];
    }
    
    return destSrcPropListMap;
}
// 清理所有依赖于指定cell的其他cell，每个cell只会被清理一次，如果有多条依赖路径时，会在最长的路径上被clear
- (void)_clearCellsThatDependOn:(FormViewCell *)cell
{
    if (!_propertyDependencyDestSrcListMap)
        _propertyDependencyDestSrcListMap = [self _buildDependencyMap];
    NSArray *dependentProps = [_propertyDependencyDestSrcListMap valueForKey:cell.propertyName];
    if (dependentProps) {
        for (NSString *depProp in dependentProps) {
            FormViewCell *depCell = [self _formCellInfoForProperty:depProp].cell;
            if (depCell) {
                [ERPFormUtils fillCell:depCell withData:nil withListDataProvider:[self listDataProvider]];
            }
        }
    }
}

- (void)_updateModelWithValue:(id)value forCell:(FormViewCell *)cell isValueAListItem:(BOOL)isListItem otherModifications:(NSDictionary *)otherModifications fillCell:(BOOL)fillCell
{
    // 实际要更新到model上的数据，对于列表选择来说，通常是value的主键，其他时候就是value本身
    id actualValue, oldValue = cell.cellInfo.value;
    if (isListItem && cell.defaultInputType == FormViewCellInputTypeList) {
        actualValue = [value valueForKey:cell.propertyListIdPropertyName];
    }
    else {
        actualValue = value;
    }
    cell.cellInfo.value = actualValue;
#ifdef FORMVIEWCONTROLLER_LOGGABLE
    NSLog(@"model changed for key %@, new value = %@, other values = %@", cell.propertyName, value, otherModifications);
#endif
    
    // 清空依赖于当前项的其他项，但不触发valueChange
    [self _clearCellsThatDependOn:cell];
    
    // 填充cell，刷新view
    if (fillCell) {
        if (isListItem) {
            [ERPFormUtils fillCell:cell withSelectedData:value withListDataProvider:[self listDataProvider]];
        }
        else {
            [ERPFormUtils fillCell:cell withData:value withListDataProvider:[self listDataProvider]];
        }
        [self _reloadForm];
    }
    
    // 记录修改
    id newValue = actualValue;
    if (!newValue)
        newValue = [NSNull null];
    [_formDataModifications setValue:newValue forKey:cell.propertyName];
    if (otherModifications) {
        [_formDataModifications setValuesForKeysWithDictionary:otherModifications];
    }
    
    // 值变化后处理
    [self valueDidChange:actualValue oldValue:oldValue forCell:cell];
    
    // 通知delegate
    [self.formValueDelegate valueDidChange:actualValue oldValue:oldValue forKey:cell.propertyName];
}

/*!
 @abstract 记录model更新并通知delegate(只记录更新，不修改传入的model)
 @param value 要修改的值
 @param isListItem 要修改的值是否属于选择列表，如果是，controller将调用listDataProvider获取列表数据，并更新form中显示的文字
 @param otherModifications 其他更新的值，可选，但这些值的更新不会通知到delegate，只有在最后读取结果数据时叠加到结果上
 @param fillCurrentCell 是否重新填充cell并刷新view，通常从别处获取的数据（比如弹出列表）需要刷新，而直接在控件上编辑的不需要（比如textField，switch）
 */
- (void)_updateModelWithValue:(id)value isValueAListItem:(BOOL)isListItem otherModifications:(NSDictionary *)otherModifications fillCell:(BOOL)fillCell
{
    UITableViewCell *cell = [self _currentCell];
    if ([cell isKindOfClass:[FormViewCell class]]) {
        [self _updateModelWithValue:value forCell:(FormViewCell *)cell isValueAListItem:isListItem otherModifications:otherModifications fillCell:fillCell];
    }
}

- (void)_updateModelWithValue:(id)value forProperty:(NSString *)propertyName isValueAListItem:(BOOL)isListItem otherModifications:(NSDictionary *)otherModifications fillCell:(BOOL)fillCell
{
    FormViewCell *cell = [self _formCellInfoForProperty:propertyName].cell;
    if (cell) {
        [self _updateModelWithValue:value forCell:cell isValueAListItem:isListItem otherModifications:otherModifications fillCell:fillCell];
    }
}

// 更新模型并通知模型变更，同时会刷新view
// TODO 如果otherModifications中包含要显示在form上的值，则要为每一个这样的值都调用updateModelWithValue
- (void)updateModelWithValue:(id)value isValueAListItem:(BOOL)isListItem otherModifications:(NSDictionary *)otherModifications
{
    [self _updateModelWithValue:value isValueAListItem:isListItem otherModifications:otherModifications fillCell:YES];
}
// 更新模型并通知模型变更，同时会刷新view
- (void)updateModelWithValue:(id)value forProperty:(NSString *)propertyName isValueAListItem:(BOOL)isListItem otherModifications:(NSDictionary *)otherModifications
{
    [self _updateModelWithValue:value forProperty:propertyName isValueAListItem:isListItem otherModifications:otherModifications fillCell:YES];
}

// 获取数据修改结果
- (NSDictionary *)dataMerged
{
    // 合并原始数据和修改
    NSMutableDictionary *merged = [NSMutableDictionary dictionaryWithDictionary:formData];
    [merged setValuesForKeysWithDictionary:_formDataModifications];
    return merged;
}

/*!
 @abstract 重载点：cell值变化
 */
- (void)valueDidChange:(id)newValue oldValue:(id)oldValue forCell:(FormViewCell *)formViewCell
{
}

// 获取最新值
- (id)currentValueForProperty:(NSString *)propertyName
{
    FormCellInfo *cellInfo = [self _formCellInfoForProperty:propertyName];
    id value;
    if (cellInfo) {
        value = cellInfo.value;
    }
    else {
        NSLog(@"未找到propertyName为'%@'的项，从formData中提取数据", propertyName);
        value = [formData valueForKey:propertyName];
    }
    return value;
}

- (FormCellInfo *)formCellInfoForProperty:(NSString *)propertyName
{
    FormCellInfo *cellInfo = [self _formCellInfoForProperty:propertyName];
    return cellInfo;
}

- (id)currentTypedValueForProperty:(NSString *)propertyName
{
    id value = [self currentValueForProperty:propertyName];
    id typedValue;
    FormCellInfo *cellInfo = [self _formCellInfoForProperty:propertyName];
    if (cellInfo) {
        typedValue = [ObjectUtils convertData:value toType:cellInfo.cell.propertyClass];
    }
    else {
        typedValue = value;
    }
    return typedValue;
}


#pragma mark 数据列表选择
// picker选择数据
- (void)_beginSingleSelectDataWithPicker:(NSArray *)data withIdProperty:(NSString *)idPropertyName withTextProperty:(NSString *)textPropertyName
{
    [self _closeKeyboard];
    _currentSelectListData = data;
    
    ChildPropertyPickerDataModel *model = [[ChildPropertyPickerDataModel alloc] initWithData:data
                                                                                  idProperty:idPropertyName
                                                                                textProperty:textPropertyName
                                                                               childProperty:nil
                                                                                 depthOfData:1];
    ERPSingleSelectSheet *ss = [[ERPSingleSelectSheet alloc] initWithModel:model];
    ss.showClearButton = YES;
    ss.delegate = self;
    [ss showInView:self.navigationController.view];
    
    id value = [self currentValueForProperty:[self _currentFormCell].propertyName];
    [ss selectObjects:@[value] animated:YES objectMatcher:^BOOL(id obj1, id obj2) {
        id key1 = [obj1 valueForKey:idPropertyName];
        id key2 = obj2;
        NSString *strKey1 = [ObjectUtils convertData:key1 toType:[NSString class]];
        NSString *strKey2 = [ObjectUtils convertData:key2 toType:[NSString class]];
        return [strKey1 isEqualToString:strKey2] || (!strKey1 && !strKey2);
    }];
}

#pragma mark SingleSelectDelegate单选组件事件代理
- (BOOL)valueSelected:(NSArray *)selectedValues dataModel:(ChildPropertyPickerDataModel *)model
{
#ifdef FORMVIEWCONTROLLER_LOGGABLE
    NSLog(@"values selected -> %@", selectedValues);
#endif
    id selectedValue = selectedValues && selectedValues.count ? [selectedValues objectAtIndex:0] : nil;
    [self updateModelWithValue:selectedValue isValueAListItem:YES otherModifications:nil];
    return YES;
}



#pragma mark - RMDateSelectionViewController Delegates
- (void)_beginInputDate:(FormViewCell *)formCell
{
    [self _closeKeyboard];
    RMDateSelectionViewController *dateSelectionVc = [RMDateSelectionViewController dateSelectionController];
    dateSelectionVc.delegate = self;
    dateSelectionVc.datePicker.datePickerMode = UIDatePickerModeDate;
    
    id value = [self currentValueForProperty:formCell.propertyName];
    if (![ObjectUtils isNilOrNull:value]) {
        NSDate *date = [ObjectUtils convertData:value toType:[NSDate class]];
        if (date)
            [dateSelectionVc.datePicker setDate:date animated:YES];
    }
    [dateSelectionVc show];
}

- (void)_dateSelected:(NSDate *)date withSelectViewController:(RMDateSelectionViewController *)vc;
{
    vc.delegate = nil;
    [vc dismiss];
    
    [self updateModelWithValue:date isValueAListItem:NO otherModifications:nil];
}
- (void)dateSelectionViewController:(RMDateSelectionViewController *)vc didSelectDate:(NSDate *)aDate
{
    [self _dateSelected:aDate withSelectViewController:vc];
}

- (void)dateSelectionViewControllerNowButtonPressed:(RMDateSelectionViewController *)vc
{
    [self _dateSelected:[NSDate date] withSelectViewController:vc];
}

- (void)dateSelectionViewControllerDidCancel:(RMDateSelectionViewController *)vc
{
    vc.delegate = nil;
    [vc dismiss];
}



#pragma mark ControlValueChangeListener
- (void)valueChangedForControl:(UIControl *)control
{
#ifdef FORMVIEWCONTROLLER_LOGGABLE
    NSLog(@"control %@ value changed", control);
#endif
    FormViewCell *fvc = [ERPFormUtils outerFormViewCellForView:control];
    if (fvc) {
        // 更新选定行
        currentCellIndexPath = fvc.cellInfo.indexPath;
        // 读取新值
        id value = [JSUIUtils valueOfInput:control];
        fvc.cellInfo.value = value;
        [self _updateModelWithValue:value isValueAListItem:NO otherModifications:nil fillCell:NO];
    }
    else {
        NSLog(@"valueChangeEvent ignored : cannot find outer formViewCell for view %@", control);
    }
}
- (void)textChangedForTextInput:(NSNotification *)textInputNotification
{
#ifdef FORMVIEWCONTROLLER_LOGGABLE
    NSLog(@"textinput %@ text changed", textInputNotification);
#endif
    UIView *textView = (UIView *)textInputNotification.object;
    FormViewCell *fvc = [ERPFormUtils outerFormViewCellForView:textView];
    if (fvc) {
        // 更新选定行
        currentCellIndexPath = fvc.cellInfo.indexPath;
        // 读取新值
        id value = [JSUIUtils valueOfInput:textView];
        fvc.cellInfo.value = value;
        [self _updateModelWithValue:value isValueAListItem:NO otherModifications:nil fillCell:NO];
    }
    else {
        NSLog(@"notificiation '%@' ignored : cannot find outer formViewCell for view %@", textInputNotification.name, textView);
    }
    
}



#pragma mark FormInputFocusDelegate
- (void)controlFocused:(UIView *)control
{
    FormViewCell *fvc = [ERPFormUtils outerFormViewCellForView:control];
    if (fvc) {
        NSIndexPath *indexPath = fvc.cellInfo.indexPath;
        [self selectAndEditRowAtIndexPath:indexPath calledByCellSelection:NO];
    }
}
- (void)textInputFocused:(NSNotification *)textInputNotification
{
    UIView *textInput = (UIView *)textInputNotification.object;
    FormViewCell *fvc = [ERPFormUtils outerFormViewCellForView:textInput];
    if (fvc) {
        NSIndexPath *indexPath = fvc.cellInfo.indexPath;
        [self selectAndEditRowAtIndexPath:indexPath calledByCellSelection:NO];
    }
}



#pragma mark Validation

// !! 由于propertyCellMap在视图加载之后才构建，所以验证只能在其之后才能使用
- (NSDictionary *)validateAllProperties
{
    NSMutableDictionary *validationResult = nil;
    for (NSString *propertyName in _propertyCellMap) {
        NSString *message = [self validateValueForProperty:propertyName];
        if (message) {
            if (!validationResult) {
                validationResult = [NSMutableDictionary dictionaryWithCapacity:_propertyCellMap.count];
            }
            [validationResult setValue:message forKey:propertyName];
        }
    }
    return validationResult;
}

- (NSString *)validateValueForProperty:(NSString *)propertyName
{
    FormCellInfo *cellInfo = [self _formCellInfoForProperty:propertyName];
    if (!cellInfo || (!cellInfo.cell.propertyRequired && !cellInfo.cell.propertyValidator)) {
        // 没有对应的cellInfo，或没有validator的均不做验证
        return nil;
    }

    id value = [self currentTypedValueForProperty:propertyName];

    BOOL required = cellInfo.cell.propertyRequired;
    if (required) {
        if (![JSValidator validateRequired:value]) {
            return @"此项必须填写";
        }
    }
    
    NSString *validator = cellInfo.cell.propertyValidator;
    NSString *validatorParams = cellInfo.cell.propertyValidatorParams;
    NSString *validatorMessage = cellInfo.cell.propertyValidatorMessage;
    
    NSString *message = nil;
    if ([@"maxLength" caseInsensitiveCompare:validator] == NSOrderedSame) {
        message = [JSValidator validateMaxLength:value maxLength:[validatorParams intValue]];
    }
    else if ([@"minLength" caseInsensitiveCompare:validator] == NSOrderedSame) {
        message = [JSValidator validateMinLength:value minLength:[validatorParams intValue]];
    }
    else if ([@"lengthInRange" caseInsensitiveCompare:validator] == NSOrderedSame) {
        NSArray* params = [self _splitValidatorParams:validatorParams expectedCount:2];
        uint min = [params[0] intValue];
        uint max = [params[1] intValue];
        message = [JSValidator validateLengthInRange:value minLength:min maxLength:max];
    }
    else if ([@"regExp" caseInsensitiveCompare:validator] == NSOrderedSame) {
        message = [JSValidator validateRegExp:(NSString *)value regExp:validatorParams invalidMessage:validatorMessage];
    }
    else if ([@"valueInRange" caseInsensitiveCompare:validator] == NSOrderedSame) {
        NSArray* params = [self _splitValidatorParams:validatorParams expectedCount:2];
        message = [JSValidator validateValueInRange:value minValue:params[0] maxValue:params[1]];
    }
    else {
        Class validatorClass = NSClassFromString(validator);
        if (!validatorClass) {
            validatorClass = NSClassFromString([NSString stringWithFormat:@"JS%@Validator", validator]);
        }
        if (validatorClass) {
            message = [JSValidator validateValue:value withValidator:validatorClass];
        }
        else {
            NSLog(@"属性%@未找到合适的验证器%@", propertyName, validator);
        }
    }
    
    return message;
}

- (NSArray *)_splitValidatorParams:(NSString *)params expectedCount:(uint)expectedCount
{
    return [self _splitValidatorParams:params expectedCount:expectedCount splitRest:NO];
}
/*!
 @abstract 分割验证器参数，分割逻辑参见FormViewCell.propertyValidatorParams属性
 @param params 参数字符串
 @param expectedCount 期望的参数数量，如果可以分割的数量小于期望数量，则将结果的剩余部分以空字符串填充
 @param splitRest 如果expectedCount数量小于实际可以分割的数量，是否继续分割剩余字符串，然后取其开头的字符串作为参数
 @result 元素数量等于expectedCount的字符串数组
 */
- (NSArray *)_splitValidatorParams:(NSString *)params expectedCount:(uint)expectedCount splitRest:(BOOL)splitRest
{
    NSMutableArray *ps = [NSMutableArray arrayWithCapacity:expectedCount];
    NSRange searchBegin = NSMakeRange(0, params.length); // 搜索开始的range
    NSRange splitBegin = searchBegin; // 切分参数开始的range
    uint splitShift = splitRest ? 0 : 1;
    while (searchBegin.location < params.length && ps.count < expectedCount - splitShift) {
        NSRange index = [params rangeOfString:@":" options:NSLiteralSearch range:searchBegin];
        if (!index.length) {
            break;
        }
        else if (index.length) {
            if (index.location > 0 && [params characterAtIndex:index.location - 1] == '\\') {
                searchBegin.location = index.location + 1;
            }
            else {
                NSRange paramRange = NSMakeRange(splitBegin.location, index.location - splitBegin.location);
                NSString *param = [params substringWithRange:paramRange];
                if ([param rangeOfString:@"\\:"].length) {
                    param = [param stringByReplacingOccurrencesOfString:@"\\:" withString:@":"];
                }
                [ps addObject:param];
                searchBegin.location = index.location + 1;
                splitBegin.location = searchBegin.location;
            }
        }
        searchBegin.length = params.length - searchBegin.location;
        splitBegin.length = params.length - splitBegin.location;
    }
    // 最后一个参数
    if (splitBegin.location < params.length && ps.count < expectedCount) {
        NSString *param = [params substringFromIndex:splitBegin.location];
        if ([param rangeOfString:@"\\:"].length) {
            param = [param stringByReplacingOccurrencesOfString:@"\\:" withString:@":"];
        }
        [ps addObject:param];
    }
    
    // 如果分割出的参数数量不足，则填充空字符串
    while (ps.count < expectedCount) {
        [ps addObject:@""];
    }
    return ps;
}

#pragma mark Validation On Cells
- (BOOL)validateAllCells
{
    [self _closeKeyboard];
    
    BOOL valid = YES;
    NSArray *formCellInfos = [ERPFormUtils formCellInfosInFormController:self];
    for (FormCellInfo *fci in formCellInfos) {
        if (![self validateCellForProperty:fci.propertyName])
            valid = NO;
    }
    return valid;
}

- (BOOL)validateCellForProperty:(NSString *)propertyName
{
    NSAssert([NSThread currentThread].isMainThread, @"验证单元格必须在UI线程进行");
    FormCellInfo *cellInfo = [self _formCellInfoForProperty:propertyName];
    NSString *message = [self validateValueForProperty:propertyName];
    
    NSMutableArray *rows = [_sectionRowList objectAtIndex:cellInfo.indexPath.section];
    NSInteger row, rowCount = rows.count;
    for (row = cellInfo.indexPath.row; row < rowCount; ++row) {
        id rowObject = [rows objectAtIndex:row];
        if (rowObject == cellInfo)
            break;
    }
    
    NSInteger messageRow = row + 1;
    NSIndexPath *messageIndexPath = [NSIndexPath indexPathForRow:messageRow inSection:cellInfo.indexPath.section];
    NSArray *messageIndexPaths = @[messageIndexPath];
    if (message) {
        // 向sectionRowList插入验证消息
        if (messageRow < rowCount) {
            if ([[rows objectAtIndex:messageRow] isKindOfClass:[NSString class]]) {
                // 更新消息
                NSLog(@"UPDATE %@ : %@ : %@", propertyName, messageIndexPath, message);
                [rows setObject:message atIndexedSubscript:messageRow];
                [self.tableView reloadRowsAtIndexPaths:messageIndexPaths
                                      withRowAnimation:UITableViewRowAnimationAutomatic];
            }
            else {
                // 插入消息
                NSLog(@"ADD %@ : %@ : %@", propertyName, messageIndexPath, message);
                [rows insertObject:message atIndex:messageRow];
                [self.tableView insertRowsAtIndexPaths:messageIndexPaths
                                      withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
        else {
            NSLog(@"ADD %@ : %@ : %@", propertyName, messageIndexPath, message);
            [rows addObject:message];
            [self.tableView insertRowsAtIndexPaths:messageIndexPaths
                                  withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }
    else {
        // 删除验证消息
        if (messageRow < rowCount - 1) {
            if ([[rows objectAtIndex:messageRow] isKindOfClass:[NSString class]]) {
                NSLog(@"REMOVE %@ : %@ : %@", propertyName, messageIndexPath, message);
                [rows removeObjectAtIndex:messageRow];
                [self.tableView deleteRowsAtIndexPaths:messageIndexPaths
                                      withRowAnimation:UITableViewRowAnimationAutomatic];
            }
            else {
                // 无验证消息
            }
        }
        else {
            // 无验证消息
        }
    }
    if (message) {
        currentCellIndexPath = nil;
        [self.tableView selectRowAtIndexPath:nil animated:YES scrollPosition:UITableViewScrollPositionNone];
    }
    return message == nil;
}
@end
