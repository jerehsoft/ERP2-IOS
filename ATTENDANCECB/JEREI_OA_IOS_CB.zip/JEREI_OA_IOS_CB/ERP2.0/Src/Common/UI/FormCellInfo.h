//
//  FormCellInfo.h
//  ERP2.0
//
//  Created by jerei on 14-8-29.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FormViewCell.h"
#import "TableFormViewController.h"

@class TableFormViewController;
@class FormViewCell;
@protocol FormViewCellInputHandler;

/*!
 @abstract 提供FormViewCell摘要信息和相邻cell的关联
 */
@interface FormCellInfo : NSObject
/*!
 @abstract section标题
 */
@property (nonatomic, retain) NSString *sectionTitle;

@property (nonatomic, retain) NSString *propertyName;

@property (nonatomic, assign) TableFormViewController *formController;
/*!
 @abstract
 */
@property (nonatomic, readonly) FormViewCell *cell;

/*!
 @abstract 上一个相邻cell
 */
@property (nonatomic, assign) FormCellInfo *previousSibling;
/*!
 @abstract 下一个相邻cell
 */
@property (nonatomic, assign) FormCellInfo *nextSibling;


// cell的当前值
@property (nonatomic, retain) id value;
// cell的位置
@property (nonatomic, retain) NSIndexPath *indexPath;
/*!
 @abstract 是否当前选定的cell
 */
@property (nonatomic, assign) BOOL isCurrent;

/*!
 @abstract 处理cell输入的handler
 */
@property (nonatomic, assign) id<FormViewCellInputHandler> inputHandler;

@end
