//
//  ERPSingleSelectSheet.h
//  ERP2.0
//
//  Created by jerei on 14-8-6.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "JSContentSheet.h"
#import "ChildPropertyPickerDataModel.h"



@protocol SingleSelectSheetDelegate <JSContentSheetDelegate>
@optional

/*!
 @abstract 向delegate发送已选择的数据，如果返回nil则表示没有选择。delegate如果返回NO可以阻止选择界面自动隐藏
 */
- (BOOL)valueSelected:(NSArray *)selectedValues dataModel:(ChildPropertyPickerDataModel *)model;
@end


@interface ERPSingleSelectSheet : JSContentSheet

@property (nonatomic, assign) BOOL showClearButton;
@property (nonatomic, assign) id<SingleSelectSheetDelegate> delegate;

- (instancetype)initWithModel:(ChildPropertyPickerDataModel *)model;
- (void)selectObjects:(NSArray *)selectedObjects animated:(BOOL)animated objectMatcher:(BOOL(^)(id obj1, id obj2))objectMatcher;

@end
