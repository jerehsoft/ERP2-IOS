//
//  ERPSingleSelectSheet.m
//  ERP2.0
//
//  Created by jerei on 14-8-6.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPSingleSelectSheet.h"



@interface ERPSingleSelectSheet()
{
    ChildPropertyPickerDataModel *_model;
}
@end

@implementation ERPSingleSelectSheet

- (NSArray *)additionalButtons
{
    NSArray *abs = [super additionalButtons];
    NSMutableArray *newAbs = [NSMutableArray arrayWithArray:abs ? abs : @[]];
    if (self.showClearButton)
        [newAbs addObject:@"Clear"];
    return newAbs;
}

- (instancetype)initWithModel:(ChildPropertyPickerDataModel *)model
{
    self = [super init];
    if (self) {
        _model = model;
    }
    return self;
}

- (void)dealloc
{
    _model = nil;
    [self printDealloc];
}

- (void)showInView:(UIView *)view
{
    if (!self.contentView) {
        UIPickerView *pv = [[UIPickerView alloc] init];
        pv.tag = 99;
        pv.dataSource = _model;
        pv.delegate = _model;
        self.contentView = pv;
    }
    [super showInView:view];
}

- (BOOL)callDelegateWithSelectedData:(NSArray *)selectedData
{
    // 如果delegate返回NO则表示数据不合法，禁止隐藏选择界面
    if (self.delegate && [self.delegate respondsToSelector:@selector(valueSelected:dataModel:)]) {
        return [self.delegate valueSelected:selectedData dataModel:_model];
    }
    return YES;
}
- (BOOL)buttonTouchHandled:(UIButton *)button
{
    if (button.tag == JCS_BTN_TAG_OK) {
        NSArray *selectedData = [_model selectedObjectsForAllComponents:(UIPickerView *)self.contentView];
        return ![self callDelegateWithSelectedData:selectedData];
    } else if ([button.titleLabel.text isEqualToString:@"Clear"]) {
        return ![self callDelegateWithSelectedData:nil];
    }
    return NO;
}

- (void)selectObjects:(NSArray *)selectedObjects animated:(BOOL)animated objectMatcher:(BOOL(^)(id obj1, id obj2))objectMatcher
{
    UIPickerView *pv = (UIPickerView *)self.contentView;
    if (!pv) {
        NSLog(@"此方法必须在显示sheet之后调用，确保pickerView已经初始化");
    }
    [_model selectObjectsForAllComponents:pv selectedObjects:selectedObjects animated:animated objectMatcher:objectMatcher];
}

@end
