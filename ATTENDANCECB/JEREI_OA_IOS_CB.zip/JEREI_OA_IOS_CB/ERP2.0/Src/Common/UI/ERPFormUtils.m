//
//  ERPFormUtils.m
//  ERP2.0
//
//  Created by jerei on 14-8-4.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPFormUtils.h"

@interface FormDataTableViewDeleate()
{
    NSDictionary *_data;
    FormDataMapping *_mapping;
}
@end


@implementation FormDataTableViewDeleate

- (void)dealloc
{
    [self printDealloc];
}

- (instancetype)initWithData:(NSDictionary *)data mappingForData:(FormDataMapping *)mapping
{
    if (self = [super init]) {
        _data = data;
        _mapping = mapping;
    }
    return self;
}

- (FormDataMappingItem *)_itemForIndexPath:(NSIndexPath *)indexPath
{
    FormDataMappingGroup *group = [_mapping groupAtIndex:indexPath.section];
    FormDataMappingItem *item = [group itemAtIndex:indexPath.row];
    return item;
}

#pragma mark TableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[_mapping groupAtIndex:section] itemCount];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [_mapping groupAtIndex:section].title;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _mapping.groupCount;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UILabel *label = nil;
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"__groupCell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"__groupCell"];
        [cell setFrame:CGRectZero];
        cell.indentationWidth = 0;
        label = [[UILabel alloc] initWithFrame:CGRectZero];
        [label setLineBreakMode:NSLineBreakByCharWrapping];
        [label setContentMode:UIViewContentModeLeft];
        [label setNumberOfLines:0];
        [label setFont:[UIFont systemFontOfSize:[UIFont systemFontSize]]];
        [label setTag:1];
        [[cell contentView] addSubview:label];
    }
    
    // TODO 两栏布局，自适应高度
    if (!label)
        label = (UILabel *)[cell viewWithTag:1];
    
    NSString *text = [[self _itemForIndexPath:indexPath] descripionForData:_data];
    
    NSInteger tableWidth = tableView.bounds.size.width;
    CGSize constraint = CGSizeMake(tableWidth - (SIMPLE_FORM_CELL_CONTENT_MARGIN * 2), 20000.0f);
    CGSize size = [text sizeWithFont:[UIFont systemFontOfSize:[UIFont systemFontSize]] constrainedToSize:constraint lineBreakMode:NSLineBreakByCharWrapping];
    
    [label setText:text];
    [label setFrame:CGRectMake(SIMPLE_FORM_CELL_CONTENT_MARGIN, SIMPLE_FORM_CELL_CONTENT_MARGIN, tableWidth - (SIMPLE_FORM_CELL_CONTENT_MARGIN * 2), MAX(size.height, SIMPLE_FORM_CELL_HEIGHT))];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    NSString *text = [[self _itemForIndexPath:indexPath] descripionForData:_data];
    // 计算文字尺寸
    NSInteger tableWidth = tableView.bounds.size.width;
    CGSize constraint = CGSizeMake(tableWidth - (SIMPLE_FORM_CELL_CONTENT_MARGIN * 2), 20000.0f);
    CGSize size = [text sizeWithFont:[UIFont systemFontOfSize:[UIFont systemFontSize]] constrainedToSize:constraint lineBreakMode:NSLineBreakByCharWrapping];
    
    CGFloat height = MAX(size.height, SIMPLE_FORM_CELL_HEIGHT);
    return height + (SIMPLE_FORM_CELL_CONTENT_MARGIN * 2);
}
@end


#pragma mark FormUtils

@implementation ERPFormUtils

#pragma mark 工具方法

// 搜集table中所有的cell的信息
+ (NSArray *)formCellInfosInFormController:(TableFormViewController *)formController
{
    NSMutableArray *cells = [NSMutableArray arrayWithCapacity:32];
    UITableView *tableView = formController.tableView;
    id<UITableViewDataSource> formDataSource = tableView.dataSource;
    // traverse section
    FormCellInfo *prevCellInfo = nil;
    
    NSInteger sectionCount = [formDataSource numberOfSectionsInTableView:tableView];
    for (NSInteger sectionId = 0; sectionId < sectionCount; ++sectionId) {
        NSString *sectionTitle = [formDataSource tableView:tableView titleForHeaderInSection:sectionId];
        // traverse cells in section
        NSInteger rowCount = [formDataSource tableView:tableView numberOfRowsInSection:sectionId];
        for (uint rowId = 0; rowId < rowCount; ++rowId) {
            NSIndexPath *cellIndexPath = [NSIndexPath indexPathForRow:rowId inSection:sectionId];
            UITableViewCell *cellView = [formDataSource tableView:tableView
                                            cellForRowAtIndexPath:cellIndexPath];
            if ([cellView isKindOfClass:[FormViewCell class]]) {
                FormViewCell *formCell = (FormViewCell *)cellView;
                FormCellInfo *cellInfo = [[FormCellInfo alloc] init];
                cellInfo.sectionTitle = sectionTitle;
                cellInfo.formController = formController;
                cellInfo.propertyName = formCell.propertyName;
                cellInfo.indexPath = cellIndexPath;
                cellInfo.formController = formController;
                // 建立相邻cell的关联
                if (prevCellInfo) {
                    prevCellInfo.nextSibling = cellInfo;
                    cellInfo.previousSibling = prevCellInfo;
                }
                prevCellInfo = cellInfo;
                [cells addObject:cellInfo];
            }
            else {
                NSLog(@"Ignoring cell at %@ : %@", cellIndexPath, cellView);
            }
        }
    }
    return cells;
}

+ (FormViewCell *)outerFormViewCellForView:(UIView *)innerView
{
    UIView *v = innerView;
    while (v && v != v.superview) {
        if ([v isKindOfClass:[FormViewCell class]]) {
            return (FormViewCell *)v;
        }
        v = v.superview;
    }
    return nil;
}

#pragma mark 显示简易只读form
+ (CustomIOS7AlertView *)showSimpleDialogWithContent:(UIView *)contentView
{
    CGRect contentFrame = contentView.frame;
    contentFrame.origin.x = contentFrame.origin.y = ALERT_FORM_VIEW_PADDING;
    
    CustomIOS7AlertView *alertView = [[CustomIOS7AlertView alloc] init];
    alertView.onButtonTouchUpInside = ^(CustomIOS7AlertView *alertView, int buttonIndex) {
    };
    alertView.buttonTitles = @[@"取消"];
    
    CGRect containerFrame = CGRectMake(ALERT_FORM_VIEW_PADDING, ALERT_FORM_VIEW_PADDING, contentFrame.size.width + ALERT_FORM_VIEW_PADDING * 2, contentFrame.size.height + ALERT_FORM_VIEW_PADDING * 2);
    UIView *container = [[UIView alloc] initWithFrame:containerFrame];
    [container addSubview:contentView];
    
    alertView.containerView = container;
    [alertView show];
    return alertView;
}

+ (void)showSimpleFormWithData:(NSDictionary *)data mappingForData:(FormDataMapping *)mapping
{
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    CGRect containerFrame = CGRectMake(0, 0, screenSize.width - ALERT_FORM_VIEW_PADDING * 2, screenSize.height * .8 - ALERT_FORM_VIEW_PADDING * 2);
    CGRect tableFrame = CGRectMake(ALERT_FORM_VIEW_PADDING, ALERT_FORM_VIEW_PADDING, containerFrame.size.width - ALERT_FORM_VIEW_PADDING * 2, containerFrame.size.height - ALERT_FORM_VIEW_PADDING * 2);
    
    // tableView的delegate和dataSource都是assign方式赋值，所以这里需要保持引用，并在block中释放
    __block FormDataTableViewDeleate *delegate = [[FormDataTableViewDeleate alloc] initWithData:data mappingForData:mapping];
    CustomIOS7AlertView *alertView = [[CustomIOS7AlertView alloc] init];
    alertView.onButtonTouchUpInsideAfterAnimate = ^(CustomIOS7AlertView *alertView, int buttonIndex) {
        delegate = nil;
    };
    alertView.buttonTitles = @[@"关闭"];

    UITableView *table = [[UITableView alloc] initWithFrame:tableFrame style:UITableViewStylePlain];
    table.allowsSelection = NO;
    table.delegate = delegate;
    table.dataSource = delegate;
    table.separatorInset = UIEdgeInsetsZero;

    UIView *container = [[UIView alloc] initWithFrame:containerFrame];
    [container addSubview:table];
    
    alertView.containerView = container;
    [alertView show];
}


#pragma mark 填表

+ (void)fillForm:(TableFormViewController *)formController withDictionary:(NSDictionary *)data withListDataProvider:(id)listDataProvider
{
    NSArray *cells = [ERPFormUtils formCellInfosInFormController:formController];
    for (FormCellInfo *ci in cells) {
        [ERPFormUtils fillFormViewCell:ci.cell withDictionary:data withListDataProvider:listDataProvider];
    }
    [formController.tableView reloadData];
}


+ (void)fillFormViewCell:(FormViewCell *)cell withDictionary:(NSDictionary *)dictionary withListDataProvider:(id)listDataProvider
{
    FormViewCell *formCell = (FormViewCell *)cell;
    id data = [dictionary valueForKey:formCell.propertyName];
#ifdef ERPFORMUTILS_PRINT_FILL_EXTRACT
    NSLog(@"Filling %@, data '%@'", cell, data);
#endif
    if (!formCell.propertyType || !formCell.propertyClass) {
        // 如果没有指定属性类型，则根据实际值类型来确定
        formCell.propertyType = NSStringFromClass([data class]);
        // 如果仍然不能确定类型则指定为NSString
        if (!formCell.propertyType)
            formCell.propertyType = NSStringFromClass([NSString class]);
    }
    [ERPFormUtils fillFormViewCell:formCell withData:data withListDataProvider:listDataProvider];
}

+ (void)fillCell:(UITableViewCell *)cell withData:(id)data withListDataProvider:(id)listDataProvider
{
    if ([cell isKindOfClass:[FormViewCell class]]) {
        [ERPFormUtils fillFormViewCell:(FormViewCell *)cell withData:data withListDataProvider:listDataProvider];
    }
    else {
        [ERPFormUtils fillTableViewCell:cell withData:data];
    }
}

+ (void)fillCell:(UITableViewCell *)cell withSelectedData:(id)selectedData withListDataProvider:(id)listDataProvider
{
    if ([cell isKindOfClass:[FormViewCell class]]) {
        // 根据selectedData获取实际的data
        FormViewCell *fvc = (FormViewCell *)cell;
        assert(fvc.defaultInputType == FormViewCellInputTypeList);
        NSString *idProp = fvc.propertyListIdPropertyName;
        // 如果没有listIdProperty，则数据为selectedData本身
        id data = (idProp && idProp.length) ? [selectedData valueForKey:idProp] : selectedData;
        [ERPFormUtils fillFormViewCell:(FormViewCell *)cell withData:data withListDataProvider:listDataProvider];
    }
    else {
        [ERPFormUtils fillTableViewCell:cell withData:selectedData];
    }
}

+ (UIView *)firstInputForCell:(UITableViewCell *)cell
{
    UIView *inputView = nil;
    if ([cell isKindOfClass:[FormViewCell class]]) {
        FormViewCell *formCell = (FormViewCell *)cell;
        if (formCell.inputViewTag && formCell.inputViewTag.intValue > 0) {
            inputView = [formCell viewWithTag:formCell.inputViewTag.intValue];
            if (!inputView)
                NSLog(@"无法找到tag为%@的inputView, cell = %@", formCell.inputViewTag, formCell);
        } else {
            inputView = [JSUIUtils findFirstInput:formCell];
            if (!inputView)
                inputView = formCell.detailTextLabel;
        }
    } else {
        inputView = [JSUIUtils findFirstInput:cell];
        if (!inputView)
            inputView = cell.detailTextLabel;
    }
    return inputView;
}

+ (BOOL)containsEditableTextView:(UIView *)view
{
    __block BOOL blockContainsEditableTextView = NO;
    [JSUIUtils traverse:view withViewProcessor:^BOOL(UIView *uiView, int viewDepth) {
        if ([uiView isKindOfClass:[UITextField class]]) {
            if (((UITextField *)uiView).enabled) {
                blockContainsEditableTextView = YES;
                return NO;
            }
        }
        else if ([uiView isKindOfClass:[UITextView class]]) {
            if (((UITextView *)uiView).editable) {
                blockContainsEditableTextView = YES;
                return NO;
            }
        }
        return YES;
    }];
    return blockContainsEditableTextView;
}

+ (BOOL)isTextView:(UIView *)view
{
    return ([view isKindOfClass:[UITextField class]] || [view isKindOfClass:[UITextView class]]);
}

+ (BOOL)isTextViewAndFocused:(UIView *)view
{
    if ([ERPFormUtils isTextView:view]) {
        if (view.isFirstResponder)
            return YES;
    }
    return NO;
}


+ (void)fillTableViewCell:(UITableViewCell *)cell withData:(id)data
{
    NSString *text = [data description];
    UIView *inputView = [JSUIUtils findFirstInput:cell];
    if (inputView) {
        [ERPFormUtils setViewText:inputView withData:text];
    }
    else {
        cell.detailTextLabel.text = text;
        [cell setNeedsLayout];
    }
}

+ (void)fillFormViewCell:(FormViewCell *)cell withData:(id)data withListDataProvider:(id)listDataProvider
{
    // 记录当前值
    cell.cellInfo.value = data;
    // 为控件设置文字
    NSString *text = [ERPFormUtils formatData:data forCell:cell withListDataProvider:listDataProvider];
    UIView *inputView = [JSUIUtils findFirstInput:cell];
    if (inputView) {
        [ERPFormUtils setViewText:inputView withData:text];
    }
    else {
        cell.detailTextLabel.text = text;
        [cell setNeedsLayout]; // 如果初始化时text为空，下次更新detailTextLabel时会无法显示，必须调用setNeedsLayout
        [cell layoutSubviews];
    }
}

// 设置指定view的显示文字
+ (void)setViewText:(UIView *)view withData:(id)data
{
    // TODO
    if ([view isKindOfClass:[UILabel class]]) {
        UILabel *label = (UILabel *)view;
        label.text = [data description];
        [label setNeedsLayout];
    }
    else if ([view isKindOfClass:[UITextField class]]) {
        [(UITextField *)view setText:[data description]];
    }
    else if ([view isKindOfClass:[UITextView class]]) {
        [(UITextView *)view setText:[data description]];
    }
    else if ([view isKindOfClass:[UISwitch class]]) {
        NSNumber *num = (NSNumber *)[ObjectUtils convertData:data toType:[NSNumber class]];
        BOOL on = num != nil && num.intValue != 0;
        ((UISwitch *)view).on = on;
    }
    else if ([view isKindOfClass:[UIStepper class]]) {
        NSNumber *num = (NSNumber *)[ObjectUtils convertData:data toType:[NSNumber class]];
        ((UIStepper *)view).value = num == nil ? 0.0 : num.doubleValue;
    }
    else if ([view isKindOfClass:[UISlider class]]) {
        NSNumber *num = (NSNumber *)[ObjectUtils convertData:data toType:[NSNumber class]];
        ((UISlider *)view).value = num == nil ? 0.0f : num.floatValue;
    }
    else if ([view isKindOfClass:[UISegmentedControl class]]) {
        NSNumber *num = (NSNumber *)[ObjectUtils convertData:data toType:[NSNumber class]];
        UISegmentedControl *seg = (UISegmentedControl *)view;
        if (num != nil && num >= 0 && seg.numberOfSegments > 0 && num.unsignedIntegerValue < seg.numberOfSegments)
            seg.selectedSegmentIndex = [num intValue];
        else
            seg.selected = NO;
    }
    else {
        NSLog(@"unknowns input view type : %@", view);
    }
}



#pragma mark 提取数据
+ (NSDictionary *)dictionaryFromFromController:(TableFormViewController *)formController withListDataProvider:(id)listDataProvider
{
    NSArray *cells = [ERPFormUtils formCellInfosInFormController:formController];
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithCapacity:cells.count];
    for (FormCellInfo *ci in cells) {
        if (ci.value != nil)
            data[ci.propertyName] = ci.value;
    }
    return data;
}

+ (id)dataFromCell:(UITableViewCell *)cell withListDataProvider:(id)listDataProvider
{
    if ([cell isKindOfClass:[FormViewCell class]]) {
#ifdef ERPFORMUTILS_PRINT_FILL_EXTRACT
        NSLog(@"Extracting %@", cell);
#endif
        FormViewCell *formCell = (FormViewCell *)cell;
        return formCell.cellInfo.value;
    }
    else {
        NSLog(@"无法对除FormViewCell以外的Cell调用dataFromCell:withListDataProvider:方法");
        return nil;
    }
}


#pragma mark 数据转换与格式化
+ (id)convertData:(id)data forCell:(FormViewCell *)cell
{
    if (!cell)
        return data;
    return [ObjectUtils convertData:data toType:cell.propertyClass];
}

+ (NSString *)formatData:(id)data forCell:(FormViewCell *)cell withListDataProvider:(id)listDataProvider
{
    NSString *pattern = cell.propertyPattern;
    id dataToDisplay;
    if (cell.defaultInputType == FormViewCellInputTypeList) {
        // 如果是选择控件，则从数据源中获取文字
        NSArray *listData = [cell listDataFromProvider:listDataProvider];
        if (!listData)
            listData = @[];
        NSInteger idx = [listData indexOfFirstMatchOfValue:data byKey:cell.propertyListIdPropertyName];
        if (idx != -1) {
            dataToDisplay = [listData objectAtIndex:idx];
            if (cell.propertyListTextPropertyName && cell.propertyListTextPropertyName.length)
                dataToDisplay = [dataToDisplay valueForKey:cell.propertyListTextPropertyName];
        } else {
            dataToDisplay = nil;
        }
    }
    else {
        // 否则直接以传入的数据为基础进行格式化
        dataToDisplay = [ObjectUtils convertData:data toType:cell.propertyClass];
    }
    // 格式化数据
    NSString *str;
    if (pattern && pattern.length) {
        if ([cell.propertyClass isSubclassOfClass:[NSDate class]]) {
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            df.dateFormat = pattern;
            str = [df stringFromDate:(NSDate* )dataToDisplay];
        }
        else if ([cell.propertyClass isSubclassOfClass:[NSNumber class]]) {
            NSNumberFormatter *nf = [[NSNumberFormatter alloc] init];
            [nf setPositiveFormat:pattern];
            [nf setNegativeFormat:pattern];
            str = [nf stringFromNumber:(NSNumber *)dataToDisplay];
        }
        else if ([cell.propertyClass isSubclassOfClass:[NSString class]]) {
            str = (NSString *)dataToDisplay;
        }
        else {
            str = [dataToDisplay description];
        }
    }
    else {
        str = [dataToDisplay description];
    }
    return str;
}


#pragma mark 控件值变化事件监听

+ (void)bindValueListener:(id<ControlValueChangeListener>)listener forFormController:(TableFormViewController *)formController
{
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    SEL textChanged = @selector(textChangedForTextInput:);
    SEL valueChanged = @selector(valueChangedForControl:);
    for (FormCellInfo *ci in [self formCellInfosInFormController:formController]) {
        UIView *view = [JSUIUtils findFirstInput:ci.cell];
        if (!view)
            continue;
        
        if ([view conformsToProtocol:@protocol(UITextInput)]) {
            UITextField *textField = (UITextField *)view;
            [nc removeObserver:listener
                          name:UITextFieldTextDidChangeNotification
                        object:textField];
            [nc addObserver:listener
                   selector:textChanged
                       name:UITextFieldTextDidChangeNotification
                     object:textField];
        }
        else if ([view isKindOfClass:[UIControl class]]) {
            UIControl *control = (UIControl *)view;
            NSArray *actions = [control actionsForTarget:listener forControlEvent:UIControlEventValueChanged];
            if (actions && actions.count)
                continue;
            [control addTarget:listener action:valueChanged forControlEvents:UIControlEventValueChanged];
        }
    }
}

+ (void)unbindValueListener:(id<ControlValueChangeListener>)listener forFormController:(TableFormViewController *)formController
{
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    SEL valueChanged = @selector(valueChangedForControl:);
    for (FormCellInfo *ci in [self formCellInfosInFormController:formController]) {
        UIView *view = [JSUIUtils findFirstInput:ci.cell];
        if (!view)
            continue;
        
        if ([view conformsToProtocol:@protocol(UITextInput)]) {
            UITextField *textField = (UITextField *)view;
            [nc removeObserver:listener
                          name:UITextFieldTextDidChangeNotification
                        object:textField];
        }
        else if ([view isKindOfClass:[UIControl class]]) {
            UIControl *control = (UIControl *)view;
            [control removeTarget:listener action:valueChanged forControlEvents:UIControlEventValueChanged];
        }

    }
}

#pragma mark 控件接受焦点事件监听
+ (void)bindFocusListener:(id<InputFocusDelegate>)listener forFormController:(TableFormViewController *)formController
{
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    SEL controlFocused = @selector(controlFocused:);
    SEL textInputFocused = @selector(textInputFocused:);
    for (FormCellInfo *ci in [self formCellInfosInFormController:formController]) {
        UIView *view = [JSUIUtils findFirstInput:ci.cell];
        if (!view)
            continue;
        
        if ([view conformsToProtocol:@protocol(UITextInput)]) {
            UITextField *textField = (UITextField *)view;
            [nc removeObserver:listener
                          name:UITextFieldTextDidBeginEditingNotification
                        object:textField];
            [nc addObserver:listener
                   selector:textInputFocused
                       name:UITextFieldTextDidBeginEditingNotification
                     object:textField];
        }
        else if ([view isKindOfClass:[UIControl class]]) {
            UIControl *control = (UIControl *)view;
            NSArray *actions = [control actionsForTarget:listener forControlEvent:UIControlEventEditingDidBegin];
            if (actions && actions.count)
                continue;
            [control addTarget:listener action:controlFocused forControlEvents:UIControlEventEditingDidBegin];
        }
    }
}

+ (void)unbindFocusListener:(id<InputFocusDelegate>)listener forFormController:(TableFormViewController *)formController
{
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    SEL controlFocused = @selector(controlFocused:);
    for (FormCellInfo *ci in [self formCellInfosInFormController:formController]) {
        UIView *view = [JSUIUtils findFirstInput:ci.cell];
        if (!view)
            continue;
        
        if ([view conformsToProtocol:@protocol(UITextInput)]) {
            UITextField *textField = (UITextField *)view;
            [nc removeObserver:listener
                          name:UITextFieldTextDidBeginEditingNotification
                        object:textField];
        }
        else if ([view isKindOfClass:[UIControl class]]) {
            UIControl *control = (UIControl *)view;
            [control removeTarget:listener action:controlFocused forControlEvents:UIControlEventEditingDidBegin];
        }
        
    }
}


#pragma mark 数据检查
+ (BOOL)isValueValid:(id)value forType:(Class)type
{
    if ([ObjectUtils isNilOrNull:value])
        return NO;
    if (!type)
        type = [value class];
    if ([type isSubclassOfClass:[NSNumber class]]) {
        if ([NSStringFromClass([value class]) isEqualToString:@"__NSCFBoolean"]) {
            // boolean总是包含合法值
            return YES;
        }
        else {
            // number非0为合法
            return ((NSNumber *)value).doubleValue != 0;
        }
    }
    else if ([type isSubclassOfClass:[NSString class]]) {
        // 字符串trim后长度大于0为合法
        return [((NSString *)value) trim].length > 0;
    }
    else if ([type isSubclassOfClass:[NSArray class]]) {
        // 数组包含非null值为合法
        NSArray *arr = (NSArray *)value;
        if (arr.count == 0)
            return NO;
        for (id val in arr)
            if (![ObjectUtils isNilOrNull:val])
                return YES;
        return NO;
    }
    else {
        // 其他类型非null即为合法
        return YES;
    }
}

@end
