//
//  ERPUser.h
//  ERP2.0
//
//  Created by jerei on 14-8-18.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ERPUser : NSObject

/*!
 @abstract 检查用户是否合法，userId>0而且有手机端用户角色
 */
@property (atomic, readonly) BOOL isValid;

@property (atomic, assign) NSInteger userId;
@property (atomic, copy) NSString *userNo;
@property (atomic, copy) NSString *userName;
@property (atomic, copy) NSString *pwd;

+ (instancetype) userFromDictionary:(NSDictionary *)dict;
@end
