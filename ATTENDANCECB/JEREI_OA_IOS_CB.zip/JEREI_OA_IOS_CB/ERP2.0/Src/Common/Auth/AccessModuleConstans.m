//
//  AccessModuleConstans.m
//  ERP2.0
//
//  Created by jerei on 14-11-03.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "AccessModuleConstans.h"

static NSArray *_arr;
static NSNumber *_currentLine;

@implementation AccessModuleConstans

+ (void)setAccessModules:(NSArray *)arr
{
    _arr = arr;
}

+ (NSArray *)getAccessModules
{
    return _arr;
}

+ (void)setCurrentLine:(NSNumber *)line
{
    _currentLine = line;
}

+ (NSNumber *)getCurrentLine
{
    return _currentLine;
}

@end
