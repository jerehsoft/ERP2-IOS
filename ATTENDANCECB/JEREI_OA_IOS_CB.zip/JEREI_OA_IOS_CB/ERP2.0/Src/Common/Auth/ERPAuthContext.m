//
//  ERPAuthContext.m
//  ERP2.0
//
//  Created by jerei on 14-8-18.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPAuthContext.h"

static ERPUser *_currentUser;

@implementation ERPAuthContext

+ (void)setUser:(ERPUser *)user
{
    _currentUser = user;
}

+ (ERPUser *)getUser
{
    return _currentUser;
}

@end
