//
//  PlatformConstans.h
//  ERP2.0
//
//  Created by jerei on 14-11-03.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AccessModuleConstans : NSObject

/*!
 @abstract 插值
 */
+ (void)setAccessModules:(NSArray *)arr;
/*!
 @abstract 取值
 */
+ (NSArray *)getAccessModules;

+ (void)setCurrentLine:(NSNumber *)line;

+ (NSNumber *)getCurrentLine;
@end
