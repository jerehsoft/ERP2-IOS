//
//  ERPAuthContext.h
//  ERP2.0
//
//  Created by jerei on 14-8-18.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ERPUser.h"

/*!
 @abstract 登录用户信息
 */
@interface ERPAuthContext : NSObject

/*!
 @abstract 设置当前用户
 */
+ (void)setUser:(ERPUser *)user;
/*!
 @abstract 获取当前用户
 */
+ (ERPUser *)getUser;

@end
