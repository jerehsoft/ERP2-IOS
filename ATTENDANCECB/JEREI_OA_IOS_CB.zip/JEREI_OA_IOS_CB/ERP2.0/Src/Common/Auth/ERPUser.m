//
//  ERPUser.m
//  ERP2.0
//
//  Created by jerei on 14-8-18.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPUser.h"
#import "ObjectUtils.h"

@implementation ERPUser

- (BOOL)isValid {
    return self.userId > 0;
}

+ (instancetype)userFromDictionary:(NSDictionary *)dict {
    if (!dict)
        return nil;
    ERPUser *u = [ObjectUtils entityFromDictionary:dict ofType:[ERPUser class]];
    return u;
}

@end
