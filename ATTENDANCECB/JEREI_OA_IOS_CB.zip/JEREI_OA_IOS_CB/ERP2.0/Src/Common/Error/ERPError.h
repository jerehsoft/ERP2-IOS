//
//  ERPError.h
//  ERP2.0
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>

#define ERP_ERROR_DOMAIN @"com.jerehsoft.www"

// 异常代码
typedef enum {
    ERPWebRequestError_EmptyResponse,
    ERPWebRequestError_ResponseNotADictionary,
    ERPWebRequestError_FieldError,
    ERPWebRequestError_ActionError,
    ERPWebRequestError_ActionErrorMessage,
    ERPWebRequestError_ResponseNotJSON,
    
    ERPDbError_Unavailable, // db无法创建，或者无法获取实例
    ERPDbError_CannotInitialize // db无法初始化（无法创建表和系统数据）
} ERPErrorCode;


// 字段验证失败消息
@interface ERPFieldErrorMessage : NSObject
@property (nonatomic, retain) NSString *field;
// 如果有多条消息则组合到一起
@property (nonatomic, retain) NSString *message;
@end

@interface ERPError : NSError

@property (nonatomic, retain) NSArray *fieldErrorMessages;

// 创建异常信息
+ (ERPError *)makeError:(ERPErrorCode)code description:(NSString *)description failureReason:(NSString *)failureReason;
+ (ERPError *)makeError:(ERPErrorCode)code description:(NSString *)description;
+ (ERPError *)makeError:(ERPErrorCode)code;

@end
