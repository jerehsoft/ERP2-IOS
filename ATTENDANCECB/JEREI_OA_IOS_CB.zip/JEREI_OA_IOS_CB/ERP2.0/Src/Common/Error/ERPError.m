//
//  ERPError.m
//  ERP2.0
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPError.h"


@implementation ERPFieldErrorMessage
@end

@implementation ERPError

+ (ERPError *)makeError:(ERPErrorCode)code
            description:(NSString *)description
          failureReason:(NSString *)failureReason
{
    if (!description && failureReason)
        description = failureReason;
    else if (!failureReason && description)
        failureReason = description;
    else if (!failureReason && !description)
        failureReason = description = @"no error message";
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                              description, NSLocalizedDescriptionKey,
                              failureReason, NSLocalizedFailureReasonErrorKey,
                              nil];
    ERPError *err = [[ERPError alloc] initWithDomain:ERP_ERROR_DOMAIN code:code userInfo:userInfo];
    return err;
}

+ (ERPError *)makeError:(ERPErrorCode)code
            description:(NSString *)description
{
    return [ERPError makeError:code description:description failureReason:description];
}

+ (ERPError *)makeError:(ERPErrorCode)code
{
    NSString *description = nil;
    switch (code) {
        case ERPWebRequestError_ActionError:
            description = @"action执行发生错误";
            break;
        case ERPWebRequestError_EmptyResponse:
            description = @"action没有返回结果";
            break;
        case ERPWebRequestError_FieldError:
            description = @"数据验证失败";
            break;
        case ERPWebRequestError_ActionErrorMessage:
            description = @"action执行过程中产生了错误消息";
            break;
        case ERPWebRequestError_ResponseNotADictionary:
            description = @"action返回结果不是一个字典";
            break;
        case ERPWebRequestError_ResponseNotJSON:
            description = @"action返回消息不是JSON格式";
            break;
        default:
            description = [NSString stringWithFormat:@"未知的错误类型:%d", code];
            break;
    }
    return [ERPError makeError:code description:description];
}

@end
