//
//  JSAudioUtils.h
//  ERP2.0
//
//  Created by jerei on 14-9-22.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
@import AVFoundation;
@import AudioToolbox;

@interface JSAudioUtils : NSObject

@property (strong, nonatomic)   AVAudioRecorder  *recorder;
@property (strong, nonatomic)   AVAudioPlayer    *player;
@property (strong, nonatomic)   NSString         *recordFileName;
@property (strong, nonatomic)   NSString         *recordFilePath;

+ (NSString*)GetCurrentTimeString;
+ (NSString*)GetPathByFileName:(NSString *)_fileName ofType:(NSString *)_type;
+ (NSInteger)getVoiceLengthByPath:(NSString *)aFilePath;
+ (NSInteger) getFileSize:(NSString*) path;

@end
