//
//  FormValueUtils.h
//  XLForm
//
//  Created by jerei on 14/12/18.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface FormValueUtils : NSObject
+(void)setValuesFrom:(NSDictionary *)dict to:(NSManagedObject *)managedObject;
+(NSDictionary *)copyFormValues:(NSDictionary *)formValue;
+(void)set:(NSMutableDictionary *)dict valuesToChildren:(NSDictionary *)mapInfo;

+(NSString *)getFirstChar:(NSString *)str;
@end
