//
//  ErpCommDateUtils.m
//  ERP2.0
//
//  Created by jerei on 14-9-28.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ErpCommDateUtils.h"
#import "DateUtils.h"

@interface ErpCommDateUtils ()

@end

@implementation ErpCommDateUtils

+ (NSDateFormatter *) initFormatterDefault:(NSString *) _formatStr{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:_formatStr];
    return df;
}

+ (NSDateFormatter *) initFormatter:(NSString *)p1 _formatStr:_localStr{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:p1];
    NSLocale *local = [[NSLocale alloc] initWithLocaleIdentifier:_localStr];
    [df setLocale:local];
    return df;
}

#pragma mark 以今天为基准获取距今天指定天数、指定格式的日期字符串
+ (NSString *) stringDateFromDays:(NSInteger)p1 _days:(NSString *) _formatStr{
    return [self stringDateFromDate:[self dateFromDays:p1 _days:_formatStr] _date:_formatStr];
}

+ (NSDate *) dateFromDays:(NSInteger)p1 _days:(NSString *) _formatStr{
    NSTimeInterval secondsPerDay = p1*24*60*60;
    NSDate *_date = [NSDate dateWithTimeIntervalSinceNow:secondsPerDay];
    NSLog(@"%@",[[self initFormatterDefault:_formatStr] stringFromDate:_date]);
    _date = [[self initFormatterDefault:_formatStr] dateFromString:[_date stringWithFormat:_formatStr]];
    return _date;
}

+ (NSDate *) dateFromString:(NSString *)p1 _dateStr:(NSString *) _formatStr{
    return [[self initFormatterDefault:_formatStr] dateFromString:p1];
}

+ (NSString *) stringDateFromDate:(NSDate *)p1 _date:(NSString *) _formatStr{
    NSString *_dateStr = [[self initFormatterDefault:_formatStr] stringFromDate:p1];
    return _dateStr;
}

+ (NSComparisonResult) compareDate:(NSDate *)p1 _date1:(NSDate *) _date2{
    NSComparisonResult result = [p1 compare : _date2];
    return result;
}
//带指定格式的日期比较
+ (NSComparisonResult) compareDateFormat:(NSDate *)p1 _date1:(NSDate *)p2 _date2:(NSString *) formatStr{
    //设置时间输出格式：
    NSDateFormatter *df = [self initFormatterDefault:formatStr];
    p1 = [df dateFromString : [df stringFromDate:p1]];
    p2 = [df dateFromString : [df stringFromDate:p2]];
    NSComparisonResult result = [p1 compare : p2];
    return result;
}

+ (NSComparisonResult) compareStringDate:(NSString *)p1 _date1 : (NSString *)p2 _date2:(NSString *) formatStr{
    //设置时间输出格式：
    NSDateFormatter *df = [self initFormatterDefault:formatStr];
    NSComparisonResult result = [self compareDate: [df dateFromString:p1] _date1:[df dateFromString:p2]];
    return result;
}

+ (double) daysBetweenDays:(NSString *)p1 _date1:(NSString *)_date2{
    //两个日期之间相隔多少秒
    NSTimeInterval secondsBetweenDates= [[self dateFromString:_date2 _dateStr:@"yyyy-MM-dd"] timeIntervalSinceDate:[self dateFromString:p1 _dateStr:@"yyyy-MM-dd"] ];
    NSLog(@"secondsBetweenDates=  %lf",secondsBetweenDates);
    return secondsBetweenDates/(60*60*24);
}

@end
