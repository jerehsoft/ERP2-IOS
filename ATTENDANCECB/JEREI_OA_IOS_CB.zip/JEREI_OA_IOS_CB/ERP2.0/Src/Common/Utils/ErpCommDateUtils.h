//
//  ErpCommDateUtils.h
//  ERP2.0
//
//  Created by jerei on 14-9-28.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ErpCommDateUtils : NSObject
+ (NSDateFormatter *) initFormatterDefault:(NSString *) _formatStr;
+ (NSDateFormatter *) initFormatter:(NSString *)p1 _formatStr:_localStr;
+ (NSString *) stringDateFromDays:(NSInteger)p1 _days:(NSString *)_formatStr;
+ (NSDate *) dateFromDays:(NSInteger)p1 _days:(NSString *) _formatStr;
+ (NSDate *) dateFromString:(NSString *)p1 _dateStr:(NSString *)_formatStr;
+ (NSString *) stringDateFromDate:(NSDate *)p1 _date: (NSString *)_formatStr;
+ (NSComparisonResult) compareDate:(NSDate *)p1 _date1:(NSDate *)_date2;
+ (NSComparisonResult) compareDateFormat:(NSDate *)p1 _date1:(NSDate *)p2 _date2:(NSString *) formatStr;
+ (NSComparisonResult) compareStringDate:(NSString *)p1 _date1 : (NSString *)p2 _date2:(NSString *) formatStr;
+ (double) daysBetweenDays:(NSString *)p1 _date1:(NSString *)_date2;
@end
