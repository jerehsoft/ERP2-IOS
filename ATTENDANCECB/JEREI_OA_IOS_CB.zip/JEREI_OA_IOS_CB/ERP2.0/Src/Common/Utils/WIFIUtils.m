//
//  WIFIUtils.m
//  ERP2.0
//
//  Created by jerei on 14-9-22.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "WIFIUtils.h"
#import "JSUIUtils.h"
#import "Reachability.h"
#import "ERPWebRequest.h"
#import <SystemConfiguration/CaptiveNetwork.h>

@implementation WIFIUtils

+ (NSDictionary *)getWIFIDic {
    CFArrayRef myArray = CNCopySupportedInterfaces();
    if (myArray != nil) {
        CFDictionaryRef myDict = CNCopyCurrentNetworkInfo(CFArrayGetValueAtIndex(myArray, 0));
        if (myDict != nil) {
            NSDictionary *dic = (NSDictionary*)CFBridgingRelease(myDict);
            NSLog(@"%@",dic);

            return dic;
        }
    }
    return nil;
}

+ (NSString *)getBSSID {
    NSDictionary *dic = [self getWIFIDic];
    if (dic == nil) {
        return nil;
    }
    return dic[@"BSSID"];
}

+ (NSString *)getSSID {
    NSDictionary *dic = [self getWIFIDic];
    if (dic == nil) {
        return nil;
    }
    return dic[@"SSID"];
}

+ (void)checkWIFIWithWifiInfo:(NSString *)currentWifi currentCBFlag:(BOOL)cbFlag devices:(NSArray *)devices complete:(void(^)())complete{

    if (cbFlag == YES) {
        if (complete) {
            complete();
        }
    }else{
        [JSUIUtils popSuccessControllerWithType:5 message:@"请在指定区域考勤,谢谢!" complete:nil];
    }

}
@end
