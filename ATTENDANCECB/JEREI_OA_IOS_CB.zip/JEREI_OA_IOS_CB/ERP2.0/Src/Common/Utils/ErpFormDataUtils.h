//
//  ErpFormDataUtils.h
//  ERP2.0
//
//  Created by jerei on 14-9-22.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DateUtils.h"

@interface ErpFormDataUtils : NSObject

+ (void)setData:(id)data forKey:(NSString *)keyName;

+ (id)getDataForKey:(NSString *)keyName;

+ (id)removeDataForKey:(NSString *)keyName;

+ (void)parseBoolValues:(NSDictionary *)map forKeys:(NSArray *)keys;

+ (void)removeAllNSNullValues:(NSMutableDictionary *)map;

+ (NSMutableDictionary*)removeAllNSNullValuesNd:(NSDictionary *)map;

@end
