//
//  ERPDefaults.m
//  ERP2.0
//
//  Created by jerei on 14-8-1.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ERPDefaults.h"


@implementation ERPDefaults

+ (NSCalendar *)defaultCalendar
{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    calendar.timeZone = [ERPDefaults defaultTimeZone];
    return calendar;
}

+ (NSTimeZone *)defaultTimeZone
{
    return [NSTimeZone timeZoneForSecondsFromGMT:ERP_TIME_ZONE * 3600];
}

@end
