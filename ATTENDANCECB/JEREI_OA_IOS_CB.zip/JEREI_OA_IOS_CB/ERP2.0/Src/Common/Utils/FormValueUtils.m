//
//  FormValueUtils.m
//  XLForm
//
//  Created by jerei on 14/12/18.
//  Copyright (c) 2014年 Xmartlabs. All rights reserved.
//

#import "FormValueUtils.h"
#import "XLFormOptionsObject.h"

@implementation FormValueUtils

+(void)setValuesFrom:(NSDictionary *)dict to:(NSManagedObject *)managedObject{
    NSArray *keys = managedObject.entity.attributesByName.allKeys;
    for(NSString *key in dict.allKeys){
        if([keys containsObject:key]){
            id value = [dict valueForKey:key];
            
            
            NSAttributeDescription *attri = [managedObject.entity.attributesByName valueForKey:key];
            if(attri.attributeType == NSInteger16AttributeType){
                if([value isKindOfClass:[NSNull class]]){
                    continue;
                }
                [managedObject setValue:@([[dict valueForKey:key] integerValue]) forKey:key];
            }else if(attri.attributeType == NSStringAttributeType){
                if([value isKindOfClass:[NSNull class]]){
                    [managedObject setValue:@"" forKey:key];
                } else {
                    [managedObject setValue:[dict valueForKey:key] forKey:key];
                }
            } else {
                if([value isKindOfClass:[NSNull class]]){
                    continue;
                }
                [managedObject setValue:[dict valueForKey:key] forKey:key];
            }
        }
    }
}

+(NSDictionary *)copyFormValues:(NSDictionary *)formValue{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    for(NSString *key in formValue.allKeys){
        id value = [formValue valueForKey:key];
        if([value isKindOfClass:[NSDictionary class]]){
            [dic setValuesForKeysWithDictionary:value];
        }else if([value isKindOfClass:[XLFormOptionsObject class]]){
            [dic setValue:[value formValue] forKey:key];
        }else{
            [dic setValue:value forKey:key];
        }
    }
    
    for(NSString *key2 in dic.allKeys){
        id value = [dic valueForKey:key2];
        if([value isKindOfClass:[XLFormOptionsObject class]]){
            [dic setValue:[value formValue] forKey:key2];
        }
    }
    
    return dic;
}

+(void)set:(NSMutableDictionary *)dict valuesToChildren:(NSDictionary *)mapInfo{
    for(NSString *filedKey in mapInfo.allKeys){
        NSArray *keys = [mapInfo valueForKey:filedKey];
        NSMutableDictionary *values = [[NSMutableDictionary alloc]initWithCapacity:keys.count];
        for(NSString *key in keys){
            [values setValue:[dict valueForKey:key] forKey:key];
        }
        [dict setValue:values forKey:filedKey];
    }
}

+(NSString *)getFirstChar:(NSString *)str{
    if(str.length == 0)return nil;
    str = [[FormValueUtils phonetic:str] uppercaseString];
    unichar firstChar = [str characterAtIndex:0];
    if(firstChar < 'A' || firstChar > 'Z')
        firstChar = '~';        
    NSString *result = [NSString stringWithFormat: @"%C", firstChar];
    return result;
}

+(NSString *)phonetic:(NSString *)sourceString {
    NSMutableString *source = [sourceString mutableCopy];
    CFStringTransform((__bridge CFMutableStringRef)source, NULL, kCFStringTransformMandarinLatin, NO);
    CFStringTransform((__bridge CFMutableStringRef)source, NULL, kCFStringTransformStripDiacritics, NO);
    return source;
}

@end
