//
//  ErpFormDataUtils.m
//  ERP2.0
//
//  Created by jerei on 14-9-22.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ErpFormDataUtils.h"
#import "AppDelegate.h"
#import "DateUtils.h"

@implementation ErpFormDataUtils

+ (void)setData:(id)data forKey:(NSString *)keyName
{
    AppDelegate *delege = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSMutableDictionary *dic = [delege tempDataMap];
    if(dic == nil){
        dic = [NSMutableDictionary dictionaryWithCapacity:10];
        [delege setTempDataMap:dic];
    }
    [dic setObject:data forKey:keyName];
    
}

+ (id)getDataForKey:(NSString *)keyName
{
    AppDelegate *delege = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSMutableDictionary *dic = [delege tempDataMap];
    if(dic == nil)return nil;
    id data = [dic valueForKey:keyName];
    return data;
}

+ (id)removeDataForKey:(NSString *)keyName
{
    AppDelegate *delege = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSMutableDictionary *dic = [delege tempDataMap];
    if(dic == nil)return nil;
    id data = [dic valueForKey:keyName];
    [dic removeObjectForKey:keyName];
    return data;
}

+ (void)parseBoolValues:(NSDictionary *)map forKeys:(NSArray *)keys{

    for(NSString *key in keys){
        id val = [map valueForKey:key];
        if(val){
            if([val isEqual:@true] ||[val isEqual:@1]){
                [map setValue:@"true" forKeyPath:key];
            }else{
                [map setValue:@"false" forKeyPath:key];

            }
        }
    }
    
}

+ (void)removeAllNSNullValues:(NSMutableDictionary *)map{
    for(NSString *key in map.allKeys){
        id val = [map valueForKey:key];
        if([val isKindOfClass:[NSNull class]]){
            [map removeObjectForKey:key];
        }else if([val isKindOfClass:[NSMutableDictionary class]]){
            [ErpFormDataUtils removeAllNSNullValues:val];
        }
    }
}

+ (NSMutableDictionary*)removeAllNSNullValuesNd:(NSDictionary *)map
{
    NSMutableDictionary *nd = [[NSMutableDictionary alloc]init];
    [nd setValuesForKeysWithDictionary:map];
    for(NSString *key in nd.allKeys){
        id val = [nd valueForKey:key];
        if([val isKindOfClass:[NSNull class]]){
            [nd removeObjectForKey:key];
        }else if([val isKindOfClass:[NSMutableDictionary class]]){
            [ErpFormDataUtils removeAllNSNullValues:val];
        }
    }
    return nd;
}

@end
