//
//  ERPDefaults.h
//  ERP2.0
//
//  Created by jerei on 14-8-1.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


#define ERP_TIME_ZONE (+8)
#define ERP_DATE_FORMAT @"yyyy-MM-dd"
#define ERP_DATETIME_FORMAT @"yyyy-MM-dd HH:mm:ss"
#define ERP_TIME_FORMAT @"HH:mm:ss"

@interface ERPDefaults : NSObject

+ (NSTimeZone *)defaultTimeZone;
+ (NSCalendar *)defaultCalendar;

@end
