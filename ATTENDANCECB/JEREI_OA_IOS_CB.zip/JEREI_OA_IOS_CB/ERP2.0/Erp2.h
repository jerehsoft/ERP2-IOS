//
//  Erp2.h
//  BaseDev
//
//  Created by jerei on 15/3/11.
//  Copyright (c) 2015年 jerehsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "JSWebRequest.h"
#import "ERPWebRequest.h"
#import "ERPError.h"
#import "ERPListActionResponseData.h"
#import "ERPDefaults.h"
#import "ERPAuthContext.h"

// 隐藏selectorLeak警告
#define SuppressPerformSelectorLeakWarning(Stuff) \
do { \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop") \
} while (0)


// 日志标记
#define FORMVIEWCONTROLLER_LOGGABLE
#define ERPFORMUTILS_PRINT_FILL_EXTRACT
