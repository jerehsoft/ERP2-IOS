//
//  AppDelegate.h
//  BaseDev
//
//  Created by jerei on 15/3/11.
//  Copyright (c) 2015年 jerehsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WXApi.h"

@class MMDrawerController;

@interface AppDelegate : UIResponder <UIApplicationDelegate, WXApiDelegate>
{
    @private
    MMDrawerController *drawerController;
}

@property (strong, nonatomic) UIWindow *window;
@property NSMutableDictionary *tempDataMap;


@end

