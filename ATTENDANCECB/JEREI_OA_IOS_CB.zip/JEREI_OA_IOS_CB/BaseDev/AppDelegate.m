//
//  AppDelegate.m
//  BaseDev
//
//  Created by jerei on 15/3/11.
//  Copyright (c) 2015年 jerehsoft. All rights reserved.
//

#import "AppDelegate.h"
#import "MMDrawerController.h"
#import "MMdrawerVisualState.h"
#import "DZNSegmentedControl.h"
#import "ERPWebRequest.h"
#import "ErpFormDataUtils.h"
#import "JSUIUtils.h"
#import "ERPDataCache.h"
#import "BRTBeaconSDK.h"
#define BRT_SDK_KEY @"00000000000000000000000000000000"
#ifndef __IPHONE_5_0
#warning "This project uses features only available in iOS SDK 5.0 and later."
#endif

#ifdef __OBJC__
#define Lang(en,zh) [[NSLocale preferredLanguages][0] rangeOfString:@"zh"].location==0?zh:en
#endif
@interface AppDelegate ()

@end

@implementation AppDelegate

-(BOOL)application:(UIApplication *)application willFinishLaunchingWithOptions:(NSDictionary *)launchOptions{
    NSDictionary *loginUser = [ERPDataCache getLoginUser];
    ERPUser *user = [ERPUser userFromDictionary:loginUser];
    if (user && user.isValid) {
        [ERPAuthContext setUser:user];
    }
    return YES;
}



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NSLog(@"%@",[[BRTBeaconSDK BRTBeaconManager] monitoredRegions]);
    // Override point for customization after application launch.
    [BRTBeaconSDK registerApp:BRT_SDK_KEY onCompletion:^(BOOL complete,NSError *error) {
        NSLog(@"%@",error.description);
    }];
    return YES;
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    return [WXApi handleOpenURL:url delegate:self];
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [WXApi handleOpenURL:url delegate:self];
}

-(void) onReq:(BaseReq*)req {
    //onReq是微信终端向第三方程序发起请求，要求第三方程序响应。第三方程序响应完后必须调用sendRsp返回。在调用sendRsp返回时，会切回到微信终端程序界面。
}

-(void) onResp:(BaseResp*)resp {
    //如果第三方程序向微信发送了sendReq的请求，那么onResp会被回调。sendReq请求调用后，会切到微信终端程序界面。
    if([resp isKindOfClass:[SendMessageToWXResp class]]) {
        if (resp.errCode == 0) {
            //成功
        }
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma monitor
- (void)sendLocalNotification:(NSString*)msg
{
    UILocalNotification *notice = [[UILocalNotification alloc] init];
    notice.alertBody = msg;
    notice.alertAction = Lang(@"Open", @"打开软件");
    notice.soundName = UILocalNotificationDefaultSoundName;
    notice.userInfo = @{@"msg":@"whatever you want"};
    [[UIApplication sharedApplication] presentLocalNotificationNow:notice];
}
/**
 * 只能在AppDelegate实现
 *
 * 区域监听失败触发的回调方法，以及关联的错误信息
 *
 * @param manager Bright beacon 管理器
 * @param region Bright beacon 区域
 * @param error 错误信息
 *
 * @return void
 */
-(void)beaconManager:(BRTBeaconManager *)manager
monitoringDidFailForRegion:(BRTBeaconRegion *)region
           withError:(NSError *)error{

}

/**
 * 只能在AppDelegate实现
 *
 * 在区域监听中，iOS设备进入beacon设备区域触发该方法
 *
 * @param manager Bright beacon 管理器
 * @param region Bright beacon 区域
 *
 * @return void
 */
-(void)beaconManager:(BRTBeaconManager *)manager
      didEnterRegion:(BRTBeaconRegion *)region{
    if(region.notifyOnEntry)[self sendLocalNotification:Lang(@"Hello!", @"您已经进入了Beacon体验区")];
}


/**
 * 只能在AppDelegate实现
 *
 * 在区域监听中，iOS设备离开beacon设备区域触发该方法
 *
 * @param manager Bright beacon 管理器
 * @param region Bright beacon 区域
 *
 * @return void
 */
-(void)beaconManager:(BRTBeaconManager *)manager
       didExitRegion:(BRTBeaconRegion *)region{
    if(region.notifyOnExit)[self sendLocalNotification:Lang(@"Goodbye.", @"您已经离开")];
}

/**
 * 只能在AppDelegate实现
 *
 * 在调用startMonitoringForRegion:方法，当beacon区域状态变化会触发该方法
 *
 * @param manager Bright beacon 管理器
 * @param state Bright beacon 区域状态
 * @param region Bright beacon 区域
 *
 * @return void
 */
-(void)beaconManager:(BRTBeaconManager *)manager
   didDetermineState:(CLRegionState)state
           forRegion:(BRTBeaconRegion *)region{
    if(region.notifyEntryStateOnDisplay)[self sendLocalNotification:Lang(@"Hello!", @"你处于监听Beacon区域,点亮屏幕收到此推送")];
}

@end
