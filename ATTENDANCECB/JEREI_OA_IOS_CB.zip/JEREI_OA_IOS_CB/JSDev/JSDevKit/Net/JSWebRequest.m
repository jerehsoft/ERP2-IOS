//
//  JSWebRequest.m
//  JSDevKit
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "JSWebRequest.h"
#import "StringUtils.h"
#import "DateUtils.h"
#import <objc/runtime.h>


@implementation JSWebRequest

- (void)dealloc
{
    [self printDealloc];
}

#pragma mark 请求发送
+ (void)requestWithURL:(NSString *)url
            withParams:(id)params
           withHeaders:(NSDictionary *)headers
        successHandler:(MKNKResponseBlock)successHandler
          errorHandler:(MKNKResponseErrorBlock)errorHandler
{
    [JSWebRequest requestWithURL:url withMethod:@"GET" withParams:params withHeaders:headers successHandler:successHandler errorHandler:errorHandler];
}

+ (void)requestWithURL:(NSString *)url
            withMethod:(NSString *)method
            withParams:(id)params
           withHeaders:(NSDictionary *)headers
        successHandler:(MKNKResponseBlock)successHandler
          errorHandler:(MKNKResponseErrorBlock)errorHandler
{
    NSMutableDictionary *paramDict = nil;
    if (params) {
        if ([params isKindOfClass:[NSDictionary class]]) {
            paramDict = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)params];
            
            NSMutableArray *nullKeys = [NSMutableArray arrayWithCapacity:paramDict.count];
            for (NSString *key in paramDict) {
                id value = [paramDict valueForKey:key];
                if ([value isKindOfClass:[NSNull class]]) {
                    [nullKeys addObject:key];
                }
            }
            
            for (NSString *key in nullKeys) {
                [paramDict removeObjectForKey:key];
            }
        }
    }
    
    MKNetworkEngine *engine = [[MKNetworkEngine alloc] init];
    MKNetworkOperation *op = [engine operationWithURLString:url
                                                     params:paramDict
                                                 httpMethod:method];
    
    if (!op) {
        // 无法创建请求
        if (errorHandler) {
            NSError *opErr = [ErrorUtils makeErrorOfDomain:ERROR_DOMAIN_JSWEBREQ
                                                  withCode:ERROR_CODE_JSWEBREQ_CANNOT_CREATE_OPERATION
                                           withDescription:@"无法创建请求"
                                                withReason:@"无法创建请求"];
            errorHandler(nil, opErr);
            return;
        }
    }
    
    // request log
    
    [op addCompletionHandler:^(MKNetworkOperation *completedOperation) {
        NSString *responseString = completedOperation.responseString;
        NSLog(@"> request complete : length = %@", responseString ? @(responseString.length) : nil);
    } errorHandler:^(MKNetworkOperation *completedOperation, NSError *error) {
        NSLog(@"> request error : %@", [error description]);
    }];
    
    if (headers)
        [op addHeaders:headers];
    if (successHandler || errorHandler)
        [op addCompletionHandler:successHandler errorHandler:errorHandler];
    [engine enqueueOperation:op];
}

static NSString* const PREFIX_HTTP = @"http://";
static NSString* const PREFIX_HTTPS = @"https://";

- (void)setBaseUrl:(NSString *)baseUrl
{
    assert(baseUrl && baseUrl.length);
    assert([baseUrl hasPrefix:PREFIX_HTTP ignoreCase:YES]
           || [baseUrl hasPrefix:PREFIX_HTTPS ignoreCase:YES]);

    if (![baseUrl hasSuffix:@"/"])
        baseUrl = [NSString stringWithFormat:@"%@/", baseUrl];
    _baseUrl = baseUrl;
}

- (NSString *)getBaseUrl
{
    return _baseUrl;
}

- (JSWebRequest *)initWithBaseUrl:(NSString *)baseUrl
{
    self = [super init];
    if (self) {
        self.baseUrl = baseUrl;
    }
    return (JSWebRequest *)self;
}

- (void)requestWithRelativeURI:(NSString *)uri
                    withParams:(id)params
                   withHeaders:(NSDictionary *)headers
                successHandler:(MKNKResponseBlock)successHandler
                  errorHandler:(MKNKResponseErrorBlock)errorHandler
{
    [self requestWithRelativeURI:uri
                      withMethod:@"GET"
                      withParams:params
                     withHeaders:headers
                  successHandler:successHandler
                    errorHandler:errorHandler];
}

- (void)requestWithRelativeURI:(NSString *)uri
                    withMethod:(NSString *)method
                    withParams:(id)params
                   withHeaders:(NSDictionary *)headers
                successHandler:(MKNKResponseBlock)successHandler
                  errorHandler:(MKNKResponseErrorBlock)errorHandler
{
    if (uri && [uri hasPrefix:@"/"])
        uri = [uri substringFromIndex:1];
    NSString *url = [NSString stringWithFormat:@"%@%@", self.baseUrl, uri];
    [JSWebRequest requestWithURL:url
                      withMethod:method
                      withParams:params
                     withHeaders:headers
                  successHandler:successHandler
                    errorHandler:errorHandler];
}


#pragma mark 参数辅助方法
+ (NSMutableDictionary *)paramsWithDictionary:(NSDictionary *)dict
{
    if (!dict)
        return [NSMutableDictionary dictionaryWithCapacity:8];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithCapacity:dict.count];
    for (NSString *key in dict) {
        [JSWebRequest addParamOfName:key value:[dict valueForKey:key] toParams:params];
    }
    return params;
}

// 转换并添加参数
+ (void)addParamOfName:(NSString *)name value:(id)value toParams:(NSMutableDictionary *)params
{
    if (![JSWebRequest _addParamOfName:name value:value toParams:params]) {
        [JSWebRequest _addParamsFromObjectProperties:value withPath:name toParams:params];
    }
}

// 添加参数，如果参数值为复杂类型，则返回NO
+ (BOOL)_addParamOfName:(NSString *)name value:(id)value toParams:(NSMutableDictionary *)params
{
    BOOL added = YES;
    if ([ObjectUtils isNilOrNull:value]) {
        [JSWebRequest _assertParamNameOrPath:name];
        // null
        [params setValue:[NSNull null] forKey:name];
    }
    else if ([value isKindOfClass:[NSString class]]) {
        [JSWebRequest _assertParamNameOrPath:name];
        // string
        [params setValue:value forKey:name];
    }
    else if ([value isKindOfClass:[NSNumber class]]) {
        [JSWebRequest _assertParamNameOrPath:name];
        if ([@"__NSCFBoolean" isEqualToString:NSStringFromClass([value class])]) {
            // boolean
            [params setValue:@"true" forKey:name];
        }
        else {
            // number
            [params setValue:value forKey:name];
        }
    }
    else if ([value isKindOfClass:[NSDate class]]) {
        [JSWebRequest _assertParamNameOrPath:name];
        // date
        NSString *dateStr = [((NSDate *)value) stringWithDefaultFormat];
        [params setValue:dateStr forKey:name];
    }
    else {
        // 其他类型，应交给方法_addParamsFromObjectProperties去处理
        added = NO;
    }
    return added;
}

+ (void)_assertParamNameOrPath:(NSString *)name
{
    if (!name || !name.length)
        NSLog(@"只有参数值为dictionary或nsobject时才能省略参数名");
    assert(name && name.length);
}

+ (void)_addParamsFromObjectProperties:(id)object withPath:(NSString *)path toParams:(NSMutableDictionary *)params
{
    // TODO 如果某个object没有可添加的属性，如何处理？是否可以写入一个NSNull？
    if ([object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *dict = (NSDictionary *)object;
        for (NSString *key in dict) {
            id value = [dict valueForKey:key];
            NSString *keyPath = path && path.length ? [NSString stringWithFormat:@"%@.%@", path, key] : key;
            if (![JSWebRequest _addParamOfName:keyPath value:value toParams:params]) {
                [JSWebRequest _addParamsFromObjectProperties:value withPath:keyPath toParams:params];
            }
        }
    }
    else if ([object isKindOfClass:[NSArray class]]) {
        [JSWebRequest _assertParamNameOrPath:path];
        
        // TODO 支持NSFastEnumeration
        NSArray *arr = (NSArray *)object;
        // 记录数组大小
        [JSWebRequest _addParamOfName:[NSString stringWithFormat:@"%@.length", path] value:@(arr.count) toParams:params];
        // 按下标添加数组元素
        for (NSInteger i = 0, j = arr.count; i < j; ++i) {
            NSString *keyPath = [NSString stringWithFormat:@"%@[%zd]", path, i];
            id value = arr[i];
            if (![JSWebRequest _addParamOfName:keyPath value:value toParams:params]) {
                [JSWebRequest _addParamsFromObjectProperties:value withPath:keyPath toParams:params];
            }
        }
    }
    else if ([object isKindOfClass:[NSObject class]]) {
        // 解析普通对象，读取属性值
        uint propCount;
        objc_property_t *prop = class_copyPropertyList([object class], &propCount);
        for (objc_property_t *p = prop; p < prop + propCount; ++p) {
            const char *csPropName = property_getName(*p);
            NSString *propName = [NSString stringWithUTF8String:csPropName];
            id value = [object valueForKey:propName];
            NSString *keyPath = path && path.length ? [NSString stringWithFormat:@"%@.%@", path, propName] : propName;
            if (![JSWebRequest _addParamOfName:keyPath value:value toParams:params]) {
                [JSWebRequest _addParamsFromObjectProperties:value withPath:keyPath toParams:params];
            }
        }
    }
    else {
        // 未知类型
        NSLog(@"Ignoring unknown type <%@>, object = %@", NSStringFromClass([object class]), object);
    }
}



@end
