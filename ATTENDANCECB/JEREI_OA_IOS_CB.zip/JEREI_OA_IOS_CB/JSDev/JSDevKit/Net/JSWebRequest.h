//
//  JSWebRequest.h
//  JSDevKit
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "../../Refs/MKNetworkKit/MKNetworkKit.h"
#import "../../Refs/MKNetworkKit/MKNetworkEngine.h"
#import "../../Refs/MKNetworkKit/MKNetworkOperation.h"

#import "JSDev.h"

#define ERROR_DOMAIN_JSWEBREQ @"JSWEBREQUEST"
#define ERROR_CODE_JSWEBREQ_CANNOT_CREATE_OPERATION 1


@interface JSWebRequest : NSObject
{
@protected
    NSString *_baseUrl;
}

// 请求的起始地址，所有relativeURI的请求均以此地址为根
@property (nonatomic, retain) NSString *baseUrl;

+ (void)requestWithURL:(NSString *)url
            withParams:(id)params
           withHeaders:(NSDictionary *)headers
        successHandler:(MKNKResponseBlock)successHandler
          errorHandler:(MKNKResponseErrorBlock)errorHandler;

+ (void)requestWithURL:(NSString *)url
            withMethod:(NSString *)method
            withParams:(id)params
           withHeaders:(NSDictionary *)headers
        successHandler:(MKNKResponseBlock)successHandler
          errorHandler:(MKNKResponseErrorBlock)errorHandler;

- (JSWebRequest *)initWithBaseUrl:(NSString *)baseUrl;

- (void)requestWithRelativeURI:(NSString *)uri
                    withParams:(id)params
                   withHeaders:(NSDictionary *)headers
                successHandler:(MKNKResponseBlock)successHandler
                  errorHandler:(MKNKResponseErrorBlock)errorHandler;

- (void)requestWithRelativeURI:(NSString *)uri
                    withMethod:(NSString *)method
                    withParams:(id)params
                   withHeaders:(NSDictionary *)headers
                successHandler:(MKNKResponseBlock)successHandler
                  errorHandler:(MKNKResponseErrorBlock)errorHandler;

/*!
 @method
 @abstract 将字典转换为可用的web参数字典，转换规则参考addParamOfName
 @param dict 源参数字典，如果传入nil仍然会返回一个空字典
 @result 转换源字典的所有值之后形成的新字典
 */
+ (NSMutableDictionary *)paramsWithDictionary:(NSDictionary *)dict;


/*!
 @method
 @abstract 向字典中添加参数，如果参数不是string或number则进行转换(如果数值类型为__NSCFBoolean则转换为'true'/'false')，如果是嵌套的对象，则转换为webform参数形式如key1.key2.key3 = value。如果参数是简单对象或者array，则不可省略参数name
 @param name 参数名
 @param value 参数值
 @param params 目标参数字典
 */
+ (void)addParamOfName:(NSString *)name value:(id)value toParams:(NSMutableDictionary *)params;


@end
