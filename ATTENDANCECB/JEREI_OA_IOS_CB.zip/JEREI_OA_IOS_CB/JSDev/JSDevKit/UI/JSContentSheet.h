//
//  JSSelectSheet.h
//  JSDevKit
//
//  Created by jerei on 14-8-6.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <UIKit/UIKit.h>


// 元素tag
#define JCS_BTN_TAG_OK 1
#define JCS_BTN_TAG_CANCEL 2
#define JCS_BTN_TAG_ADDITIONAL_MIN 100
#define JCS_BTN_TAG_ADDITIONAL_MAX 999
#define JCS_CONTENT_CONTAINER_TAG 10
// 元素尺寸
#define JCS_CORNER_SIZE 5.0f
#define JCS_BTN_HEIGHT 30.0f
#define JCS_ELEMENT_GAP 12.0f
#define JCS_ELEMENT_PADDING_H 10.0f
#define JCS_ELEMENT_PADDING_V 10.0f

@class JSContentSheet;

@protocol JSContentSheetDelegate <NSObject>
@optional

// OK
- (void)sheetOKButtonPressed:(JSContentSheet *)contentSheet;
// Cancel
- (void)sheetCancelButtonPressed:(JSContentSheet *)contentSheet;
/*!
 @abstract 按钮点击
 */
- (void)sheetAdditionButtonPressed:(JSContentSheet *)contentSheet buttonTitle:(NSString *)buttonTitle;

@end


// 可指定内容的类actionSheet
@interface JSContentSheet : UIView

// 确定取消按钮
@property (nonatomic, assign) BOOL showOKButton;
@property (nonatomic, assign) BOOL showCancelButton;
@property (nonatomic, retain) NSString *okButtonTitle;
@property (nonatomic, retain) NSString *cancelButtonTitle;
// 事件代理
@property (nonatomic, assign) id<JSContentSheetDelegate> delegate;

// 附加按钮，显示在选择组件上方
@property (nonatomic, copy) NSArray *additionalButtons;

// 中央显示的内容view
@property (nonatomic, retain) UIView *contentView;

/*!
 @abstract 在目标view上层显示
 */
- (void)showInView:(UIView *)view;
/*!
 @abstract 关闭
 */
- (void)dismiss;

/*!
 @abstract 重载点：在这里截获按钮事件，返回NO可以继续默认事件分发
 */
- (BOOL)buttonTouchHandled:(UIButton *)button;

@end
