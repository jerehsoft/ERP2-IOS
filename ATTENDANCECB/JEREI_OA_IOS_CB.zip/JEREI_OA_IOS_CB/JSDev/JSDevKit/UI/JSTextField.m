//
//  JSTextField.m
//  JSDevKit
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "JSTextField.h"

@implementation JSTextField

@synthesize placeholderColor;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


- (void)setPlaceholderColor:(UIColor *)placeholderColor2
{
    [self setValue:placeholderColor2 forKeyPath:@"_placeholderLabel.textColor"];
}

- (UIColor *)getPlaceholderColor
{
    return (UIColor *)[self valueForKeyPath:@"_placeholderLabel.textColor"];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
