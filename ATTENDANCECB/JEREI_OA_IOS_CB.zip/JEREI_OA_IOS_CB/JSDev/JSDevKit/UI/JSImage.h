//
//  JSImage.h
//  JSDevKit
//
//  Created by jerei on 14-8-28.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSDev.h"

@interface JSImage : NSObject

@end

@interface UIImage(JSImage)

- (UIImage *)imageScaledToSize:(CGSize)size;
- (UIImage *)imageScaledToSmallerSize:(CGSize)size;
- (UIImage *)imageScaledToLargerSize:(CGSize)size;

@end