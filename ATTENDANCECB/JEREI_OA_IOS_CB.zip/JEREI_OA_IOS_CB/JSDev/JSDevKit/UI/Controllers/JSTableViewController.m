//
//  JSTableViewController.m
//  JSDevKit
//
//  Created by jerei on 14-8-8.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "JSTableViewController.h"

@interface JSTableViewController ()

@end

@implementation JSTableViewController

- (void)dealloc
{
    [self printDealloc];
}

@end
