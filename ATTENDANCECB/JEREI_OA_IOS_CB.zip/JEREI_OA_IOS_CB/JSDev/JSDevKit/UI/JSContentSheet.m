//
//  JSSelectSheet.m
//  JSDevKit
//
//  Created by jerei on 14-8-6.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "JSContentSheet.h"
#import "JSUIUtils.h"


@interface JSContentSheet()
{
    // 透明背景
    UIView *_backgroundView;
}
@end

@implementation JSContentSheet

@synthesize additionalButtons = _additionalButtons;
@synthesize contentView = _contentView;

- (id)init
{
    self = [self initWithFrame:CGRectMake(0, 0, 0, 0)];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        _backgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth([UIScreen mainScreen].bounds), CGRectGetHeight([UIScreen mainScreen].bounds))];
        _backgroundView.backgroundColor = [UIColor blackColor];
        _backgroundView.alpha = 0.0f;
        
        // default values
        self.showOKButton = YES;
        self.showCancelButton = YES;
        
        self.okButtonTitle = @"OK";
        self.cancelButtonTitle = @"Cancel";
    }
    return self;
}

- (void)dealloc
{
    _additionalButtons = nil;
    _contentView = nil;
    _backgroundView = nil;
    self.delegate = nil;
    [self printDealloc];
}


#pragma mark 辅助方法
- (BOOL)_isIOSUnder7_0
{
    return [[[UIDevice currentDevice] systemVersion] compare:@"7.0" options:NSNumericSearch] == NSOrderedAscending;
}

- (float)_height
{
    return CGRectGetHeight([UIScreen mainScreen].bounds);
}
- (float)_width
{
    return CGRectGetWidth([UIScreen mainScreen].bounds);
}
- (void)_getSizeForWidth:(float *)width height:(float *)height
{
    float h = [self _height], w = [self _width];
    if (!UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])) {
        float hw = w;
        w = h;
        h = hw;
    }
    *height = h;
    *width = w;
}
- (UIButton *)_buttonWithTitle:(NSString *)title andTag:(NSInteger)tag
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btn.layer setCornerRadius:JCS_CORNER_SIZE];
    [btn.layer setMasksToBounds:YES];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [btn setBackgroundColor:[UIColor whiteColor]];
    [btn setTag:tag];
    [btn addTarget:self action:@selector(buttonTouched:) forControlEvents:UIControlEventTouchUpInside];
    return btn;
}

// 布局内容
- (void)_layoutSubviews:(float *)contentHeight
{
    // 内容的总高度
    float totalHeight = 0;
    
    // 容器尺寸
    float width, height;
    [self _getSizeForWidth:&width height:&height];
    // 当前y
    float y = height - JCS_ELEMENT_GAP;
    

    // 1. 先显示ok/cancel
    y -= JCS_BTN_HEIGHT;
    // 默认参考frame
    CGRect okCancelFrame = CGRectMake(JCS_ELEMENT_GAP, y, width - JCS_ELEMENT_GAP * 2, JCS_BTN_HEIGHT);
    UIButton *okButton, *cancelButton;
    if (self.showOKButton) {
        okButton = (UIButton *)[self viewWithTag:JCS_BTN_TAG_OK];
        if (!okButton) {
            okButton = [self _buttonWithTitle:self.okButtonTitle andTag:JCS_BTN_TAG_OK];
            [self addSubview:okButton];
        }
        okButton.frame = okCancelFrame;
    }
    if (self.showCancelButton) {
        cancelButton = (UIButton *)[self viewWithTag:JCS_BTN_TAG_CANCEL];
        if (!cancelButton) {
            cancelButton = [self _buttonWithTitle:self.cancelButtonTitle andTag:JCS_BTN_TAG_CANCEL];
            [self addSubview:cancelButton];
        }
        cancelButton.frame = okCancelFrame;
    }
    if (self.showOKButton && self.showCancelButton) {
        // 重新布局ok/cancel，并排摆放
        CGRect frame2 = CGRectOffset(okCancelFrame, 0, 0);
        frame2.size.width = (width - JCS_ELEMENT_GAP * 3) / 2;
        okButton.frame = frame2;
        cancelButton.frame = CGRectOffset(frame2, JCS_ELEMENT_GAP + frame2.size.width, 0);
    }
    // 更新高度
    if (self.showOKButton || self.showCancelButton)
        totalHeight += JCS_BTN_HEIGHT;
    
    // 2. 再显示content，content必需有高度
    if (self.contentView) {
        UIView *contentContainer = [self viewWithTag:JCS_CONTENT_CONTAINER_TAG];
        if (!contentContainer) {
            float contentHeight = self.contentView.bounds.size.height;
            y -= JCS_ELEMENT_GAP + contentHeight + JCS_ELEMENT_PADDING_V * 2;
            
            CGRect contentContainerFrame = CGRectMake(JCS_ELEMENT_GAP, y, width - JCS_ELEMENT_GAP * 2, contentHeight + JCS_ELEMENT_PADDING_V * 2);
            contentContainer = [[UIView alloc] initWithFrame:contentContainerFrame];
            [contentContainer setClipsToBounds:YES];
            [contentContainer setBackgroundColor:[UIColor whiteColor]];
            [contentContainer.layer setMasksToBounds:YES];
            [contentContainer.layer setCornerRadius:JCS_CORNER_SIZE];
            [self addSubview:contentContainer];
            
            // 调整content宽度和定位
            CGRect contentFrame = CGRectMake(JCS_ELEMENT_PADDING_H, JCS_ELEMENT_PADDING_V, contentContainerFrame.size.width - JCS_ELEMENT_PADDING_H * 2, self.contentView.frame.size.height);
            self.contentView.frame = contentFrame;
            [contentContainer addSubview:self.contentView];
        }
        totalHeight += contentContainer.frame.size.height + JCS_ELEMENT_GAP;
    }
    
    // 3. 显示additionalButtons
    // 先隐藏所有可能的additionalButton
    for (UIView *ab in self.subviews) {
        if (ab.tag >= JCS_BTN_TAG_ADDITIONAL_MIN && ab.tag <= JCS_BTN_TAG_ADDITIONAL_MAX)
            ab.hidden = YES;
    }
    // 创建或重用button
    if (self.additionalButtons && self.additionalButtons.count) {
        for (NSInteger btnId = 0, btnCount = self.additionalButtons.count; btnId < btnCount; ++btnId) {
            NSInteger btnTag = JCS_BTN_TAG_ADDITIONAL_MIN + btnId;
            assert(btnTag <= JCS_BTN_TAG_ADDITIONAL_MAX);
            UIButton *btn = (UIButton *)[self viewWithTag:btnTag];
            NSString *btnTitle = [self.additionalButtons objectAtIndex:btnId];
            if (!btn) {
                // 创建button
                btn = [self _buttonWithTitle:btnTitle andTag:btnTag];
                [self addSubview:btn];
            }
            [btn setHidden:NO];
            [btn setTitle:btnTitle forState:UIControlStateNormal];
            // 定位button
            y -= JCS_ELEMENT_GAP + JCS_BTN_HEIGHT;
            CGRect btnFrame = CGRectMake(okCancelFrame.origin.x, y, okCancelFrame.size.width, okCancelFrame.size.height);
            btn.frame = btnFrame;
            totalHeight += JCS_ELEMENT_GAP + JCS_BTN_HEIGHT;
        }
    }
    
    *contentHeight = totalHeight;
    
#if DEBUG
    //[JSUIUtils inspect:self];
#endif
}

#pragma mark 按钮触摸事件
- (BOOL)buttonTouchHandled:(UIButton *)button
{
    return NO;
}

- (void)buttonTouched:(id)sender
{
    UIButton *button = (UIButton *)sender;
    
    // 如果事件已被处理则跳过后续步骤
    if ([self buttonTouchHandled:button])
        return;
    
    if (!self.delegate || ![self.delegate conformsToProtocol:@protocol(JSContentSheetDelegate)]) {
        [self dismiss];
        return;
    }
    
    NSInteger tag = button.tag;
    if (tag == JCS_BTN_TAG_OK) {
        if ([self.delegate respondsToSelector:@selector(sheetOKButtonPressed:)])
            [self.delegate sheetOKButtonPressed:self];
    } else if (tag == JCS_BTN_TAG_CANCEL) {
        if ([self.delegate respondsToSelector:@selector(sheetCancelButtonPressed:)])
            [self.delegate sheetCancelButtonPressed:self];
    } else if (tag >= JCS_BTN_TAG_ADDITIONAL_MIN && tag <= JCS_BTN_TAG_ADDITIONAL_MAX) {
        if ([self.delegate respondsToSelector:@selector(sheetAdditionButtonPressed:buttonTitle:)])
            [self.delegate sheetAdditionButtonPressed:self buttonTitle:button.titleLabel.text];
    } else {
        NSLog(@"JSContentSheet : unknown button tag %ld", (long)tag);
    }
    [self dismiss];
}

#pragma mark 显示方法

- (void)layoutSubviews
{
    [super layoutSubviews];
    float contentHeight;
    [self _layoutSubviews:&contentHeight];
}
- (void)showInView:(UIView *)view
{
    if (self.superview) {
        NSLog(@"contentSheet already shown");
        return;
    }
    
    float contentHeight;
    [self _layoutSubviews:&contentHeight];
    
    [view addSubview:self];
    [view insertSubview:_backgroundView belowSubview:self];

    float x, height, width;
    [self _getSizeForWidth:&width height:&height];
    x = width / 2;
    
    // backgroundView使用中心点定位，view使用左上角定位
    _backgroundView.frame = CGRectMake(_backgroundView.center.x, _backgroundView.center.y, width, height);
    _backgroundView.center = CGPointMake(x, height / 2.0);
    // 要保证frame覆盖button的区域才能让button接受触摸事件
    self.frame = CGRectMake(0, 0, _backgroundView.frame.size.width, _backgroundView.frame.size.height);
    self.center = CGPointMake(width / 2, height / 2 + contentHeight + 100);
    
    if ([self _isIOSUnder7_0]) {
        [UIView animateWithDuration:0.2f
                              delay:0.0f
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^() {
                             _backgroundView.alpha = 0.4f;
                             self.center = CGPointMake(width / 2, height / 2);
                         } completion:^(BOOL finished) {
//                             self.visible = YES;
                         }];
    } else {
        [UIView animateWithDuration:0.5f
                              delay:0
             usingSpringWithDamping:0.6f
              initialSpringVelocity:0
                            options:UIViewAnimationOptionCurveLinear
                         animations:^{
                             _backgroundView.alpha = 0.4f;
                             self.center = CGPointMake(width / 2, height / 2);
                         } completion:^(BOOL finished) {
//                             self.visible = YES;
                         }];
    }
}

- (void)dismiss
{
    if ([self _isIOSUnder7_0]) {
        [UIView animateWithDuration:0.2f
                              delay:0.0f
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^() {
                             _backgroundView.alpha = 0.0f;
                             self.center = CGPointMake(self.center.x, self.center.y + self.frame.size.height);
                         } completion:^(BOOL finished) {
                             [_backgroundView removeFromSuperview];
                             [self removeFromSuperview];
//                             self.visible = NO;
                         }];
    } else {
        [UIView animateWithDuration:0.5f
                              delay:0
             usingSpringWithDamping:0.6f
              initialSpringVelocity:0
                            options:UIViewAnimationOptionCurveLinear
                         animations:^{
                             _backgroundView.alpha = 0.0f;
                             self.center = CGPointMake(self.center.x, self.center.y + self.frame.size.height);
                         } completion:^(BOOL finished) {
                             [_backgroundView removeFromSuperview];
                             [self removeFromSuperview];
//                             self.visible = NO;
                         }];
    }
}

@end
