//
//  JSUIUtils.h
//  JSDevKit
//
//  Created by jerei on 14-7-31.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import "MBProgressHUD.h"
#import "JSDev.h"
#include <AudioToolbox/AudioToolbox.h>

// alert view 按钮点击事件block
typedef void (^AlertViewButtonBlock)(NSString* buttonTitle);
typedef void (^AlertViewButtonOKCancelBlock)(BOOL isCancel);
typedef void (^PropmtViewButtonOKCancelBlock)(BOOL isCancel, NSString *value);

@interface JSUIUtils : NSObject

+ (void)inspect:(UIView *)view;
/*!
 @abstract 探查视图结构
 @param view 要探查的视图
 @param processor 视图处理器，如果返回NO则表示终止探查。uiView : 当前视图，viewDepth : 当前视图层级，buff : 一个可变字符串，可以用来记录日志
 */
+ (void)inspect:(UIView *)view withViewProcessor:(BOOL (^)(UIView* uiView, int viewDepth, NSMutableString* buff))processor;

/*!
 @abstract 深度优先遍历视图结构
 @param view 要探查的视图
 @param processor 视图处理器，如果返回NO则表示终止探查。uiView : 当前视图，viewDepth : 当前视图层级
 */
+ (void)traverse:(UIView *)view withViewProcessor:(BOOL (^)(UIView* uiView, int viewDepth))processor;

/*!
    @abstract 使用web格式颜色构造UIColor ([0x]XXX/[0x]XXXXXX)
 */
+ (UIColor *)colorWithHexRGB:(NSString *)rgbColor;

+ (void)alert:(NSString *)message withTitle:(NSString *)title;
+ (void)alert:(NSString *)message withTitle:(NSString *)title buttonBlock:(AlertViewButtonBlock)buttonBlock;
+ (void)alertOKCancel:(NSString *)message withTitle:(NSString *)title buttonBlock:(AlertViewButtonOKCancelBlock)buttonBlock;
+ (void)alertOKCancel:(NSString *)message withTitle:(NSString *)title leftButtonTitle:(NSString *)lb rightButtonTitle:(NSString *)rb buttonBlock:(AlertViewButtonOKCancelBlock)buttonBlock;
+ (void)promptOKCancel:(NSString *)message withTitle:(NSString *)title buttonBlock:(PropmtViewButtonOKCancelBlock)buttonBlock;

/*!
    @abstract 检查view是否在tableCell中或tableCell本身
 */
+ (BOOL)isViewInTableCell:(UIView *)view;

+ (void)openTelWithPhoneNumber:(NSString *)phoneNumber;
+ (void)openSmsWithPhoneNumber:(NSString *)phoneNumber;
+ (BOOL)openSmsComposerWithPhoneNumber:(NSString *)phoneNumber text:(NSString *)text viewController:(UIViewController *)viewController delegate:(id<MFMessageComposeViewControllerDelegate>)delegate;

/*!
 @abstract 尝试将焦点移动到第一个找到的输入组件
 */
+ (BOOL)tryFocusOnFirstInput:(UIView *)view;
/*!
 @abstract 查找第一个输入组件
 */
+ (UIView *)findFirstInput:(UIView *)view;
/*!
 @abstract 检查一个组件是否输入组件
 */
+ (BOOL)isInput:(UIView *)view;

/*!
 @abstract 在指定view中查找firstResponder
 */
+ (UIView *)findFirstResponderInView:(UIView *)view;

/*!
 @abstract 读取input的值
 */
+ (id)valueOfInput:(UIView *)view;

/*!
 @abstract 使用匹配block查找包含的view
 */
+ (NSArray *)viewsInView:(UIView *)view withMatcher:(BOOL (^)(UIView *view))matcher;

/*!
 @abstract 在view中显示toast消息
 */
+ (void)toastForView:(UIView *)view withMessage:(NSString *)message forDuration:(NSTimeInterval)duration;


typedef void (^TaskDone)();
/*!
 @abstract 显示hud，同时执行操作（可以是异步操作），操作完成之后必须调用taskDone来关闭hud
 */
+ (void)showProgressHUDForView:(UIView *)view withMessage:(NSString *)message taskBlock:(void(^)(TaskDone taskDone))taskBlock;

/*!
 @abstract 等比缩放size，如果目标size有一个方向小于原size，则等比缩小，否则等比放大
 */
+ (CGSize)aspectScaleSize:(CGSize)source to:(CGSize)dest;

/*!
 改变图片颜色
 */
+ (UIImage *)changeColorWithImage:(UIImage *)image color:(UIColor *)color;

/**
 *  登录
 *
 *  @param complete 完成block
 */
+ (void)popLoginControllerWithComplete:(void(^)())complete;
/**
 *  登录
 *  @param type 签到1签退2离司3回司4错误5
 *  @param message 除错误以外，显示在大标题，类型为错误时，显示在小标题
 *  @param complete 完成block
 */
+ (void)popSuccessControllerWithType:(int)type message:(NSString *)message complete:(void(^)())complete;

/**
 *  播放提示音
 *  1、get_appeal
 *  2、grab_success
 *  3、open_grab
 */
+(void)playAlertSoundWithIndex:(int)index;

@end

@interface JSAlertView : UIAlertView
@end

@interface JSAlertViewHandler : NSObject<UIAlertViewDelegate>

- (instancetype)initWithCallback:(AlertViewButtonBlock)buttonBlock;
- (void)setupAlertView:(UIAlertView *)alertView;

@end



@interface UIColor(JSUIUtils)

+ (instancetype)colorWithHexRGB:(NSString *)rgbColor;

@end