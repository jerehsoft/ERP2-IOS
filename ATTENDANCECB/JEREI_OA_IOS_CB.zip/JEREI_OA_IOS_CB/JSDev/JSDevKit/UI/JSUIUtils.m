//
//  JSUIUtils.m
//  JSDevKit
//
//  Created by jerei on 14-7-31.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "JSUIUtils.h"
#import "../Lang/StringUtils.h"
#import <MessageUI/MessageUI.h>
#import "ErpLoginViewController.h"
#import "AlertPopViewController.h"
#import "JSUINavigationController.h"
#import "MMDrawerController.h"
#import "ERPDataCache.h"

@interface JSAlertView()
{
    id<UIAlertViewDelegate> _delegateRef;
}
@end
@implementation JSAlertView

- (id)delegate
{
    return [super delegate];
}
- (void)setDelegate:(id)delegate
{
    super.delegate = delegate;
    _delegateRef = delegate;
}
- (void)dealloc
{
    _delegateRef = nil;
    self.delegate = nil;
    [self printDealloc];
}
@end

@implementation JSUIUtils

+ (void)inspect:(UIView *)view
{
    [JSUIUtils inspect:view withViewProcessor:nil];
}

+ (void)inspect:(UIView *)view withViewProcessor:(BOOL (^)(UIView* uiView, int viewDepth, NSMutableString* buff))processor
{
    if (!view) {
        NSLog(@"no view to inspect");
        return;
    }
    
    NSMutableString *buff = [[NSMutableString alloc] initWithCapacity:512];
    [JSUIUtils inspect:view depth:0 buff:buff withViewProcessor:processor];
    NSLog(@"View %@ inspected as :\n%@", view, buff);
}

// 探查视图结构，如果process返回NO则表示停止探查
+ (BOOL)inspect:(UIView *)view depth:(int)depth buff:(NSMutableString *)buff withViewProcessor:(BOOL (^)(UIView* uiView, int viewDepth, NSMutableString* buff))processor
{
    if (!view)
        return YES;
    
    // dump view info
    // indent
    [buff appendString:[@"" stringByPaddingToLength:depth << 1 withString:@" " startingAtIndex:0]];
    [buff appendFormat:@"%d: %@ %d\n", depth, view, [view isUserInteractionEnabled]];
    
    if (processor) {
        BOOL continues = processor(view, depth, buff);
        if (!continues)
            return NO;
    }
    
    // inspect subviews
    for (UIView *sv in view.subviews) {
        BOOL continues = [JSUIUtils inspect:sv depth:depth + 1 buff:buff withViewProcessor:processor];
        if (!continues)
            return NO;
    }
    return YES;
}

+ (void)traverse:(UIView *)view withViewProcessor:(BOOL (^)(UIView *, int))processor
{
    if (!view) {
        NSLog(@"no view to traverse");
        return;
    }
    [JSUIUtils traverse:view depth:0 withViewProcessor:processor];
}

+ (BOOL)traverse:(UIView *)view depth:(int)depth  withViewProcessor:(BOOL (^)(UIView *, int))processor
{
    if (!view)
        return YES;
    
    if (processor) {
        BOOL continues = processor(view, depth);
        if (!continues)
            return NO;
    }
    
    // traverse subviews
    for (UIView *sv in view.subviews) {
        BOOL continues = [JSUIUtils traverse:sv depth:depth + 1 withViewProcessor:processor];
        if (!continues)
            return NO;
    }
    return YES;
}


+ (NSArray *)viewsInView:(UIView *)view withMatcher:(BOOL (^)(UIView *))matcher
{
    assert(matcher != nil);
    if (!matcher)
        return @[];
    NSMutableArray *views = [NSMutableArray arrayWithCapacity:8];
    [JSUIUtils pushViewsIntoResult:views withinView:view withMatcher:matcher];
    return [views copy];
}

+ (void)pushViewsIntoResult:(NSMutableArray *)result withinView:(UIView *)superView withMatcher:(BOOL (^)(UIView *))matcher
{
    if (matcher(superView))
        [result addObject:superView];
    for (UIView *sv in superView.subviews) {
        [JSUIUtils pushViewsIntoResult:result withinView:sv withMatcher:matcher];
    }
}


+ (UIColor *)colorWithHexRGB:(NSString *)rgbColor
{
    if (!rgbColor || !rgbColor.length)
        return nil;
    
    float r, g, b;
    const char* cc;
    UIColor *color = nil;
    
    NSError *error;
    NSRegularExpressionOptions reOpts = NSRegularExpressionCaseInsensitive;
    if ([rgbColor matches:@"^(0x)?[0-9a-f]{6}$" options:reOpts error:&error]) {
        if (rgbColor.length == 8)
            cc = [[rgbColor substringFromIndex:2] cStringUsingEncoding:NSASCIIStringEncoding];
        else
            cc = [rgbColor cStringUsingEncoding:NSASCIIStringEncoding];
        unsigned long ucolor = strtoul(cc, 0, 16);
        r = ((ucolor & 0xff0000) >> 16) / 255.0;
        g = ((ucolor & 0xff00) >> 8) / 255.0;
        b = (ucolor & 0xff) / 255.0;
        color = [UIColor colorWithRed:r green:g blue:b alpha:1];
    } else if ([rgbColor matches:@"^(0x)?[0-9a-f]{3}$" options:reOpts error:&error]) {
        if (rgbColor.length == 8)
            cc = [[rgbColor substringFromIndex:2] cStringUsingEncoding:NSASCIIStringEncoding];
        else
            cc = [rgbColor cStringUsingEncoding:NSASCIIStringEncoding];
        unsigned long ucolor = strtoul(cc, 0, 16);
        r = ((ucolor & 0xf00) >> 8) / 15.0;
        g = ((ucolor & 0xf0) >> 4) / 15.0;
        b = (ucolor & 0xf) / 15.0;
        color = [UIColor colorWithRed:r green:g blue:b alpha:1];
    } else {
        NSLog(@"invalid rgbColor format : %@", rgbColor);
    }
    return color;
}

+ (void)alert:(NSString *)message withTitle:(NSString *)title
{
    [JSUIUtils alert:message withTitle:title buttonBlock:nil];
}

+ (void)alertOKCancel:(NSString *)message withTitle:(NSString *)title buttonBlock:(AlertViewButtonOKCancelBlock)buttonBlock
{
    [JSUIUtils alertOKCancel:message withTitle:title leftButtonTitle:@"好" rightButtonTitle:@"取消" buttonBlock:buttonBlock];
}

+ (void)alertOKCancel:(NSString *)message withTitle:(NSString *)title leftButtonTitle:(NSString *)lb rightButtonTitle:(NSString *)rb buttonBlock:(AlertViewButtonOKCancelBlock)buttonBlock
{
    JSAlertView *alertView = [[JSAlertView alloc] initWithTitle:title && title.length ? title : @"Alert"
                                                        message:message
                                                       delegate:nil
                                              cancelButtonTitle:lb
                                              otherButtonTitles:rb, nil];
    
    if (buttonBlock) {
        __block AlertViewButtonOKCancelBlock okCancelBlock = buttonBlock;
        [[[JSAlertViewHandler alloc] initWithCallback:^(NSString* buttonTitle) {
            okCancelBlock(![buttonTitle isEqualToString:lb]);
            okCancelBlock = nil;
        }] setupAlertView:alertView];
    }

    //version-update
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{

        dispatch_sync(dispatch_get_main_queue(), ^{
            //返回主线程

            [alertView show];
        });
    });
}

+ (void)promptOKCancel:(NSString *)message withTitle:(NSString *)title buttonBlock:(PropmtViewButtonOKCancelBlock)buttonBlock
{
    JSAlertView *alertView = [[JSAlertView alloc] initWithTitle:title && title.length ? title : @"Alert"
                                                        message:message
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:@"取消", nil];
    [alertView setAlertViewStyle:UIAlertViewStylePlainTextInput];
    
    if (buttonBlock) {
        __block PropmtViewButtonOKCancelBlock okCancelBlock = buttonBlock;
        [[[JSAlertViewHandler alloc] initWithCallback:^(NSString* buttonTitle) {
            UITextField *tf=[alertView textFieldAtIndex:0];
            okCancelBlock(![buttonTitle isEqualToString:@"好"], tf.text);
            okCancelBlock = nil;
        }] setupAlertView:alertView];
    }
    [alertView show];
}

+ (void)alert:(NSString *)message withTitle:(NSString *)title buttonBlock:(AlertViewButtonBlock)buttonBlock
{
    JSAlertView *alertView = [[JSAlertView alloc] initWithTitle:title && title.length ? title : @"Alert"
                                                        message:message
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
    
    if (buttonBlock) {
        [[[JSAlertViewHandler alloc] initWithCallback:buttonBlock] setupAlertView:alertView];
    }
    [alertView show];
}

+ (BOOL)isViewInTableCell:(UIView *)view
{
    while([view superview]) {
        if ([NSStringFromClass([view class]) isEqualToString:@"UITableViewCellContentView"]) {
            return YES;
        } else {
            view = [view superview];
        }
    }
    return NO;
}

+ (void)openTelWithPhoneNumber:(NSString *)phoneNumber
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"tel://%@", phoneNumber]];
    [[UIApplication sharedApplication] openURL:url];
}

+ (void)openSmsWithPhoneNumber:(NSString *)phoneNumber
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"sms://%@", phoneNumber]];
    [[UIApplication sharedApplication] openURL:url];
}

+ (BOOL)openSmsComposerWithPhoneNumber:(NSString *)phoneNumber text:(NSString *)text viewController:(UIViewController *)viewController delegate:(id<MFMessageComposeViewControllerDelegate>)delegate
{
    Class messageClass = (NSClassFromString(@"MFMessageComposeViewController"));
    if (messageClass) {
        if ([messageClass canSendText]) {
            MFMessageComposeViewController *picker = [[MFMessageComposeViewController alloc] init];
            picker.messageComposeDelegate = delegate;
            picker.body = text;
            picker.recipients = @[phoneNumber];
            if (picker) {
                [viewController presentModalViewController:picker animated:YES];
                return YES;
            } else {
                return NO;
            }
        } else {
            //设备没有短信功能
            return NO;
        }
    } else {
        // iOS版本过低,iOS4.0以上才支持程序内发送短信
        return NO;
    }
}


+ (BOOL)tryFocusOnFirstInput:(UIView *)view
{
    UIView *input = [JSUIUtils findFirstInput:view];
    return input && [input canBecomeFirstResponder] && [input becomeFirstResponder];
}
+ (UIView *)findFirstInput:(UIView *)view
{
    if (!view)
        return nil;
    if ([JSUIUtils isInput:view])
        return view;
    for (UIView *sv in view.subviews) {
        UIView *input = [JSUIUtils findFirstInput:sv];
        if (input)
            return input;
    }
    return nil;
}
+ (BOOL)isInput:(UIView *)view
{
    return view
    && !view.hidden
    && view.bounds.size.width
    && view.bounds.size.height
    && (
        [view isKindOfClass:[UITextField class]] ||
        [view isKindOfClass:[UITextView class]] ||
        [view isKindOfClass:[UISwitch class]] ||
        [view isKindOfClass:[UISlider class]] ||
        [view isKindOfClass:[UIStepper class]] ||
        [view isKindOfClass:[UISegmentedControl class]]
        );
}

+ (UIView *)findFirstResponderInView:(UIView *)view
{
    if (!view)
        return nil;
    if (view.isFirstResponder)
        return view;
    for (UIView *sv in view.subviews) {
        UIView *subFirstResponder = [JSUIUtils findFirstResponderInView:sv];
        if (subFirstResponder)
            return subFirstResponder;
    }
    return nil;
}

+ (id)valueOfInput:(UIView *)view
{
    id value;
    if ([view isKindOfClass:[UITextView class]]) {
        value = ((UITextView *)view).text;
    }
    else if ([view isKindOfClass:[UITextField class]]) {
        value = ((UITextField *)view).text;
    }
    else if ([view isKindOfClass:[UISwitch class]]) {
        value = @(((UISwitch *)view).on);
    }
    else if ([view isKindOfClass:[UIStepper class]]) {
        value = @(((UIStepper *)view).value);
    }
    else if ([view isKindOfClass:[UISegmentedControl class]]) {
        UISegmentedControl *seg = (UISegmentedControl *)view;
        value = @(seg.selectedSegmentIndex);
    }
    else if ([view isKindOfClass:[UISlider class]]) {
        value = @(((UISlider *)view).value);
    }
    else {
        NSLog(@"Unknown inputView %@", view);
        value = nil;
    }
    return value;
}

#define JS_TOAST_HUD_VIEW_TAG 19527
+ (void)toastForView:(UIView *)view withMessage:(NSString *)message forDuration:(NSTimeInterval)duration
{
    @synchronized(view) {
        MBProgressHUD *hud;
        UIView *hudView = [view viewWithTag:JS_TOAST_HUD_VIEW_TAG];
        if (hudView) {
            hud = (MBProgressHUD *)hudView;
        }
        else {
            hud = [[MBProgressHUD alloc] initWithView:view];
            hud.tag = JS_TOAST_HUD_VIEW_TAG;
            hud.mode = MBProgressHUDModeText;
            hud.removeFromSuperViewOnHide = YES;
            hud.userInteractionEnabled = NO;
        }
        
        hud.labelText = message;
        [view addSubview:hud];
        [hud showAnimated:YES whileExecutingBlock:^{
            [NSThread sleepForTimeInterval:duration];
        }];
    }
}


+ (void)showProgressHUDForView:(UIView *)view withMessage:(NSString *)message taskBlock:(void (^)(TaskDone taskDone))taskBlock
{
    MBProgressHUD *hud = [[MBProgressHUD alloc] initWithView:view];
    hud.mode = MBProgressHUDModeText;
    hud.labelText = message;
    hud.removeFromSuperViewOnHide = YES;
    [view addSubview:hud];
    [hud show:YES];
    
    __weak MBProgressHUD *weakHud = hud;
    taskBlock(^() {
        [weakHud hide:YES];
    });
}

+ (CGSize)aspectScaleSize:(CGSize)source to:(CGSize)dest
{
    if (CGSizeEqualToSize(source, dest))
        return source;
    
    float srcW = source.width, srcH = source.height;
    float destW = dest.width, destH = dest.height;
    
    
    // 如果目标尺寸一个方向大于原尺寸，而另一个方向小于原尺寸，则先往小里调整
    if (destW > srcW && destH < srcH) {
        destW = srcW * destH / srcH;
    }
    else if (destH > srcH && destW < srcW) {
        destH = srcH * destW / srcW;
    }
    
    float w, h;
    // 如果目标宽高比较高，则按高度－》宽度顺序调整，否则按宽度－》高度顺序调整
    if (destW / destH > srcW / srcH) {
        h = destH;
        w = srcW * destH / srcH;
    }
    else {
        w = destW;
        h = srcH * destW / srcW;
    }
    return CGSizeMake(w, h);
}

+ (UIImage *)changeColorWithImage:(UIImage *)image color:(UIColor *)color
{
    UIGraphicsBeginImageContextWithOptions(image.size, NO, image.scale);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0, image.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    CGContextSetBlendMode(context, kCGBlendModeNormal);
    CGRect rect = CGRectMake(0, 0, image.size.width, image.size.height);
    CGContextClipToMask(context, rect, image.CGImage);
    [color setFill];
    CGContextFillRect(context, rect);
    UIImage*newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

+ (UIViewController *)getCurrentVC {
    UIViewController *appRootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
    UIViewController *topVC = appRootVC;
    while (topVC.presentedViewController) {
        topVC = topVC.presentedViewController;
    }
    if ([topVC isKindOfClass:[MMDrawerController class]]) {
        topVC = [(MMDrawerController *)topVC centerViewController];
        if ([topVC isKindOfClass:[JSUINavigationController class]]) {
            topVC = [(JSUINavigationController *)topVC viewControllers].lastObject;
        }
    }
    return topVC;
}

+ (void)popLoginControllerWithComplete:(void(^)())complete {
    if (![ERPAuthContext getUser] || ![ERPAuthContext getUser].isValid) {
        dispatch_async(dispatch_get_main_queue(), ^{
            JSUINavigationController *navVc = [[UIStoryboard storyboardWithName:@"LoginRelated" bundle:nil] instantiateViewControllerWithIdentifier:@"Login"];
            navVc.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
            
            ErpLoginViewController *loginVc = [navVc.viewControllers firstObject];
            [loginVc setBlockForComplete:^{
                [[self getCurrentVC] dismissViewControllerAnimated:YES completion:nil];
                if (complete) {
                    complete();
                }
            }];
            [[self getCurrentVC] presentViewController:navVc animated:YES completion:nil];
        });
    } else {
        if (complete) {
            complete();
        }
    }
}

+ (void)popSuccessControllerWithType:(int)type message:(NSString *)message complete:(void(^)())complete {
    dispatch_async(dispatch_get_main_queue(), ^{
        AlertPopViewController *alertVc = [[AlertPopViewController alloc] initWithNibName:@"AlertPopViewController" bundle:nil];
        alertVc.alertType = type;
        alertVc.message = message;
        JSUINavigationController *navVc = [[JSUINavigationController alloc] initWithRootViewController:alertVc];
        navVc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        //背景半透明关键
        if ([[[UIDevice currentDevice] systemVersion] floatValue] < 8.0) {
            [self getCurrentVC].modalPresentationStyle = UIModalPresentationOverCurrentContext;
        } else {
            navVc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
        }
        [alertVc setBlockForComplete:^{
            [[self getCurrentVC] dismissViewControllerAnimated:YES completion:nil];
            if (complete) {
                complete();
            }
        }];
        [[self getCurrentVC] presentViewController:navVc animated:YES completion:nil];
    });
}

+(void)playAlertSoundWithIndex:(int)index {
    NSString *resourceName;
    switch (index) {
        case 2:
            resourceName = @"grab_success";
            break;
        case 3:
            resourceName = @"open_grab";
            break;
        default:
            resourceName = @"get_appeal";
            break;
    }
    NSString *path = [[NSBundle mainBundle]pathForResource:resourceName
                                                    ofType:@"wav"];
    SystemSoundID soundID;
    AudioServicesCreateSystemSoundID((__bridge CFURLRef)[NSURL fileURLWithPath:path], &soundID);
    AudioServicesPlaySystemSound(soundID);
}

@end


// alert view代理
@interface JSAlertViewHandler()
{
    AlertViewButtonBlock _buttonBlock;
}
@end
@implementation JSAlertViewHandler

- (instancetype)initWithCallback:(AlertViewButtonBlock)buttonBlock
{
    if (self = [super init]) {
        _buttonBlock = buttonBlock;
    }
    return self;
}

- (void)setupAlertView:(JSAlertView *)alertView
{
    alertView.delegate = self;
}

- (void)dealloc
{
    _buttonBlock = nil;
    [self printDealloc];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *buttonTitle = [alertView buttonTitleAtIndex:buttonIndex];
    if (_buttonBlock) {
        _buttonBlock(buttonTitle);
    }
}

@end


@implementation UIColor(JSUIUtils)

+ (instancetype)colorWithHexRGB:(NSString *)rgbColor
{
    return [JSUIUtils colorWithHexRGB:rgbColor];
}

@end