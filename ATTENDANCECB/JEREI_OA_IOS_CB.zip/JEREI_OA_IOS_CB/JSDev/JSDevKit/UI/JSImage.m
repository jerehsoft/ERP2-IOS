//
//  JSImage.m
//  JSDevKit
//
//  Created by jerei on 14-8-28.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "JSImage.h"

@implementation JSImage

@end



@implementation UIImage(JSImage)

- (UIImage *)imageScaledToSize:(CGSize)size
{
    UIGraphicsBeginImageContext(size);
    CGRect bounds = { CGPointZero, size };
    [self drawInRect:bounds];
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}

- (UIImage *)imageScaledToSmallerSize:(CGSize)size
{
    if (self.size.height > size.height || self.size.width > size.width) {
        return [self imageScaledToSize:size];
    }
    else {
        return self;
    }
}

- (UIImage *)imageScaledToLargerSize:(CGSize)size
{
    if (self.size.height < size.height || self.size.width < size.width) {
        return [self imageScaledToSize:size];
    }
    else {
        return self;
    }
}

@end