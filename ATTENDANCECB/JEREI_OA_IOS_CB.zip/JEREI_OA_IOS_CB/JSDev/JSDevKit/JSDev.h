//
//  JSDev.h
//  BaseDev
//
//  Created by jerei on 15/3/11.
//  Copyright (c) 2015年 jerehsoft. All rights reserved.
//

#ifdef __OBJC__
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "JSLog.h"
#import "ObjectUtils.h"
#import "ExceptionUtils.h"
#import "ErrorUtils.h"
#endif