//
//  ArrayUtils.m
//  JSDevKit
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ArrayUtils.h"

@implementation ArrayUtils
@end


@implementation NSArray(NSArrayUtils)


- (NSString *)stringJoinedBy:(NSString *)separator
{
    return [self stringJoinedBy:separator ofKeyPath:nil];
}

- (NSString *)stringJoinedBy:(NSString *)separator ofKeyPath:(NSString *)keyPath
{
    if (!separator)
        separator = @"";
    
    BOOL hasKeyPath = keyPath && keyPath.length;
    NSMutableString *mstr = [[NSMutableString alloc] initWithCapacity:self.count << 5];
    BOOL initialPassed = NO;
    for (id item in self) {
        // 拼接分隔符
        if (initialPassed) {
            [mstr appendString:separator];
        }
        else {
            initialPassed = YES;
        }
        
        // 拼接文本
        id value;
        if (hasKeyPath) {
            // 通过keypath访问属性
            value = [item valueForKeyPath:keyPath];
        }
        else {
            value = item;
        }
        [mstr appendString:[value description]];
    }
    return [mstr description];
}

- (NSInteger)indexOfFirstMatchOfValue:(id)value byKey:(NSString *)keyProperty
{
    BOOL isNil = (value == nil);
    if (isNil) {
        for (NSInteger i = 0, j = self.count; i < j; ++i) {
            id obj = [self objectAtIndex:i];
            if (obj != nil && [obj valueForKey:keyProperty] == nil)
                return i;
        }
    }
    else {
        BOOL isString = [value isKindOfClass:[NSString class]];
        if (isString) {
            for (NSInteger i = 0, j = self.count; i < j; ++i) {
                id obj = [self objectAtIndex:i];
                if (obj != nil) {
                    id val = [obj valueForKey:keyProperty];
                    if ([val isEqualToString:value])
                        return i;
                }
            }
        }
        else {
            for (NSInteger i = 0, j = self.count; i < j; ++i) {
                id obj = [self objectAtIndex:i];
                if (obj != nil) {
                    id val = [obj valueForKey:keyProperty];
                    if ([val isEqual:value])
                        return i;
                }
            }
        }
    }
    return -1;
}

+ (instancetype)arrayWithCopiesOfObjects:(id)object count:(uint)count
{
    if (object == nil)
        object = [NSNull null];
    NSMutableArray *arr = [NSMutableArray arrayWithCapacity:count];
    for (uint i = 0; i < count; ++i) {
        [arr addObject:[object copy]];
    }
    return arr;
}
@end