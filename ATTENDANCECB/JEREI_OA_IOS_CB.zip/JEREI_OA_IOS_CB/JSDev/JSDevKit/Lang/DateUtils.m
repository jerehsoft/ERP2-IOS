//
//  DateUtils.m
//  JSDevKit
//
//  Created by jerei on 14-7-30.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#include <stdlib.h>
#import "DateUtils.h"
#import "StringUtils.h"

@implementation DateUtils

+ (NSDate *)dateFromString:(NSString *)dateStr
{
    if ([dateStr isEqual:[NSNull null]] || dateStr == nil)
        return nil;
    
    // yyyy-MM-dd HH:mm:ss.SSS
    NSString *pattern = @"^(\\d{2,4})[^\\d](\\d{1,2})[^\\d](\\d{1,2})"
    @"(\\s(\\d{1,2}):(\\d{1,2})(:(\\d{1,2})(\\.(\\d{1,3}))?)?)?$";
    NSError *error;
    NSRegularExpression *nsre = [[NSRegularExpression alloc] initWithPattern:pattern options:0 error:&error];
    if (error) {
        NSLog(@"cannot parse date from string '%@'", dateStr);
        return nil;
    }
    
    NSRange range = NSMakeRange(0, dateStr.length);
    NSTextCheckingResult *result = [nsre firstMatchInString:dateStr options:0 range:range];
    if (result.numberOfRanges != 11) {
        // no match
        return nil;
    } else {
        /*
         2014-07-30 21:44:43.457 ERP2.0[25474:70b] result = 11
         2014-07-30 21:44:43.459 ERP2.0[25474:70b] range : 0, location : 0, length : 23, date part = 2014-01-03 12:01:02.234
         2014-07-30 21:44:43.459 ERP2.0[25474:70b] range : 1, location : 0, length : 4, date part = 2014
         2014-07-30 21:44:43.459 ERP2.0[25474:70b] range : 2, location : 5, length : 2, date part = 01
         2014-07-30 21:44:43.460 ERP2.0[25474:70b] range : 3, location : 8, length : 2, date part = 03
         2014-07-30 21:44:43.460 ERP2.0[25474:70b] range : 4, location : 10, length : 13, date part =  12:01:02.234
         2014-07-30 21:44:43.461 ERP2.0[25474:70b] range : 5, location : 11, length : 2, date part = 12
         2014-07-30 21:44:43.461 ERP2.0[25474:70b] range : 6, location : 14, length : 2, date part = 01
         2014-07-30 21:44:43.462 ERP2.0[25474:70b] range : 7, location : 16, length : 7, date part = :02.234
         2014-07-30 21:44:43.462 ERP2.0[25474:70b] range : 8, location : 17, length : 2, date part = 02
         2014-07-30 21:44:43.462 ERP2.0[25474:70b] range : 9, location : 19, length : 4, date part = .234
         2014-07-30 21:44:43.463 ERP2.0[25474:70b] range : 10, location : 20, length : 3, date part = 234
         */
        
        NSMutableString *dateStr2 = [[NSMutableString alloc] initWithCapacity:23];
        // date
        [dateStr2 appendString:[dateStr substringWithRange:[result rangeAtIndex:1]]];
        [dateStr2 appendString:@"-"];
        [dateStr2 appendString:[dateStr substringWithRange:[result rangeAtIndex:2]]];
        [dateStr2 appendString:@"-"];
        [dateStr2 appendString:[dateStr substringWithRange:[result rangeAtIndex:3]]];
        // time
        [dateStr2 appendString:@" "];
        NSRange nr;
        nr = [result rangeAtIndex:5];
        [dateStr2 appendString:(nr.length ? [dateStr substringWithRange:nr] : @"00")];
        [dateStr2 appendString:@":"];
        nr = [result rangeAtIndex:6];
        [dateStr2 appendString:(nr.length ? [dateStr substringWithRange:nr] : @"00")];
        [dateStr2 appendString:@":"];
        nr = [result rangeAtIndex:8];
        [dateStr2 appendString:(nr.length ? [dateStr substringWithRange:nr] : @"00")];
        [dateStr2 appendString:@"."];
        nr = [result rangeAtIndex:10];
        [dateStr2 appendString:(nr.length ? [dateStr substringWithRange:nr] : @"000")];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss.SSS";
        NSDate *date = [dateFormatter dateFromString:[dateStr2 description]];
        return date;
    }
}

const NSString *WEEKDAYS = @"日一二三四五六";
+ (NSString *)weekDayName:(NSInteger)weekDay
{
    assert(weekDay >= 1 && weekDay <= 7);
    return [WEEKDAYS substringWithRange:NSMakeRange(weekDay - 1, 1)];
}

+ (NSString *)weekDayNameByDate:(NSDate *)date {
    NSDateComponents *componets = [[NSCalendar autoupdatingCurrentCalendar] components:NSWeekdayCalendarUnit fromDate:date];
    NSString *weekDayName = [NSString stringWithFormat:@"星期%@",[self weekDayName:[componets weekday]]];
    componets = nil;
    return weekDayName;
}

+ (NSString *)getDaysPastWithDate:(NSDate *)date
{
    NSDate *now = [NSDate dateFromString:[NSString stringWithFormat:@"%@ 23:59:59",[[NSDate date] stringWithFormat:@"yyyy-MM-dd"]]];
    NSTimeZone *nowTimeZone = [NSTimeZone localTimeZone];
    long timeOffset = [nowTimeZone secondsFromGMTForDate:now];
    NSDate *nowDate = [now dateByAddingTimeInterval:timeOffset];
    //比较时间和当前时间
    NSTimeInterval interval = [nowDate timeIntervalSinceDate:date];
    NSString *result = [NSString stringWithFormat:@"%d天前", (int)interval/(60*60*24)];
    if ([result isEqualToString:@"0天前"]) {
        result = @"今天";
    } else if ([result isEqualToString:@"1天前"]) {
        result = @"昨天";
    } else if ([result isEqualToString:@"2天前"]) {
        result = @"前天";
    }
    return result;
}

@end


@implementation NSDate(NSDateUtils)

+ (NSDate *)dateFromString:(NSString *)dateStr
{
    return [DateUtils dateFromString:dateStr];
}

//农历转换函数
- (NSString *)_lunarForSolar:(NSDate *)solarDate
{
    //天干名称
    NSArray *cTianGan = [NSArray arrayWithObjects:@"甲",@"乙",@"丙",@"丁",@"戊",@"己",@"庚",@"辛",@"壬",@"癸", nil];
    //地支名称
    NSArray *cDiZhi = [NSArray arrayWithObjects:@"子",@"丑",@"寅",@"卯",@"辰",@"巳",@"午",@"未",@"申",@"酉",@"戌",@"亥",nil];
    //属相名称
    NSArray *cShuXiang = [NSArray arrayWithObjects:@"鼠",@"牛",@"虎",@"兔",@"龙",@"蛇",@"马",@"羊",@"猴",@"鸡",@"狗",@"猪",nil];
    //农历日期名
    NSArray *cDayName = [NSArray arrayWithObjects:@"*",@"初一",@"初二",@"初三",@"初四",@"初五",@"初六",@"初七",@"初八",@"初九",@"初十",
                         @"十一",@"十二",@"十三",@"十四",@"十五",@"十六",@"十七",@"十八",@"十九",@"二十",
                         @"廿一",@"廿二",@"廿三",@"廿四",@"廿五",@"廿六",@"廿七",@"廿八",@"廿九",@"三十",nil];
    
    //农历月份名
    NSArray *cMonName = [NSArray arrayWithObjects:@"*",@"正",@"二",@"三",@"四",@"五",@"六",@"七",@"八",@"九",@"十",@"十一",@"腊",nil];
    //公历每月前面的天数
    const int wMonthAdd[12] = {0,31,59,90,120,151,181,212,243,273,304,334};
    //农历数据
    const int wNongliData[100] = {2635,333387,1701,1748,267701,694,2391,133423,1175,396438
        ,3402,3749,331177,1453,694,201326,2350,465197,3221,3402
        ,400202,2901,1386,267611,605,2349,137515,2709,464533,1738
        ,2901,330421,1242,2651,199255,1323,529706,3733,1706,398762
        ,2741,1206,267438,2647,1318,204070,3477,461653,1386,2413
        ,330077,1197,2637,268877,3365,531109,2900,2922,398042,2395
        ,1179,267415,2635,661067,1701,1748,398772,2742,2391,330031
        ,1175,1611,200010,3749,527717,1452,2742,332397,2350,3222
        ,268949,3402,3493,133973,1386,464219,605,2349,334123,2709
        ,2890,267946,2773,592565,1210,2651,395863,1323,2707,265877};
    
    static int wCurYear,wCurMonth,wCurDay;
    static int nTheDate,nIsEnd,m,k,n,i,nBit;
    
    //取当前公历年、月、日
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate:solarDate];
    wCurYear = [components year];
    wCurMonth = [components month];
    wCurDay = [components day];
    
    //计算到初始时间1921年2月8日的天数：1921-2-8(正月初一)
    nTheDate = (wCurYear - 1921) * 365 + (wCurYear - 1921) / 4 + wCurDay + wMonthAdd[wCurMonth - 1] - 38;
    if((!(wCurYear % 4)) && (wCurMonth > 2))
        nTheDate = nTheDate + 1;
    
    //计算农历天干、地支、月、日
    nIsEnd = 0;
    m = 0;
    while (nIsEnd != 1) {
        if(wNongliData[m] < 4095)
            k = 11;
        else
            k = 12;
        n = k;
        while (n >= 0) {
            //获取wNongliData(m)的第n个二进制位的值
            nBit = wNongliData[m];
            for (i = 1; i < n + 1; i++)
                nBit = nBit / 2;
            
            nBit = nBit % 2;
            
            if (nTheDate <= (29 + nBit)) {
                nIsEnd = 1;
                break;
            }
            
            nTheDate = nTheDate - 29 - nBit;
            n = n - 1;
        }
        if (nIsEnd)
            break;
        m = m + 1;
    }
    wCurYear = 1921 + m;
    wCurMonth = k - n + 1;
    wCurDay = nTheDate;
    if (k == 12) {
        if (wCurMonth == wNongliData[m] / 65536 + 1)
            wCurMonth = 1 - wCurMonth;
        else if (wCurMonth > wNongliData[m] / 65536 + 1)
            wCurMonth = wCurMonth - 1;
    }
    
    //生成农历天干、地支、属相
    NSString *szShuXiang = (NSString *)[cShuXiang objectAtIndex:((wCurYear - 4) % 60) % 12];
    NSString *szNongli = [NSString stringWithFormat:@"%@(%@%@)年",szShuXiang, (NSString *)[cTianGan objectAtIndex:((wCurYear - 4) % 60) % 10],(NSString *)[cDiZhi objectAtIndex:((wCurYear - 4) % 60) % 12]];
    
    //生成农历月、日
    NSString *szNongliDay;
    if (wCurMonth < 1){
        szNongliDay = [NSString stringWithFormat:@"闰%@",(NSString *)[cMonName objectAtIndex:-1 * wCurMonth]];
    } else{
        szNongliDay = (NSString *)[cMonName objectAtIndex:wCurMonth];
    }
    
//    NSString *lunarDate = [NSString stringWithFormat:@"%@ %@月 %@",szNongli,szNongliDay,(NSString *)[cDayName objectAtIndex:wCurDay]];
    NSString *lunarDate = [NSString stringWithFormat:@"农历%@月 %@",szNongliDay,(NSString *)[cDayName objectAtIndex:wCurDay]];
    return lunarDate;
}

- (NSString *)lunarCalendarDate
{
    return [self _lunarForSolar:self];
}

- (NSString *)stringWithFormat:(NSString *)format
{
    NSDateFormatter *dfYmd = [[NSDateFormatter alloc] init];
    [dfYmd setDateFormat:format];
    return [dfYmd stringFromDate:self];
}

- (NSString *)stringWithDefaultFormat
{
    return [self stringWithFormat:DATEUTILS_DATE_TIME_DEFAULT_FORMAT];
}
@end