//
//  ObjectUtils.m
//  JSDevKit
//
//  Created by jerei on 14-7-31.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ObjectUtils.h"
#import "DateUtils.h"
#import <objc/runtime.h>

// 是否打印nsobject的dealloc消息
#define NSOBJECT_PRINT_DEALLOC

@implementation ObjectUtils

+ (id)convertData:(id)data toType:(Class)type
{
    if ([data isKindOfClass:type])
        return data;
    
    id newData;
    if (type == [NSMutableString class]) {
        // 可变字符串
        newData = [NSMutableString stringWithString:[data description]];
    }
    else if ([type isSubclassOfClass:[NSString class]]) {
        // 字符串
        newData = [data description];
    }
    else if ([type isSubclassOfClass:[NSDate class]]) {
        // 日期
        if (!data) {
            newData = nil;
        } else if ([data isKindOfClass:[NSNumber class]]) {
            // 构造日期
            newData = [NSDate dateWithTimeIntervalSince1970:[(NSNumber *)data doubleValue]];
        } else {
            NSString *dateStr = [data isKindOfClass:[NSString class]] ? (NSString *)data : [data description];
            // 解析字符串
            newData = [DateUtils dateFromString:dateStr];
        }
    }
    else if (type == [NSDecimalNumber class]) {
        // decimal
        if (!data) {
            newData = nil;
        } else if ([data isKindOfClass:[NSDate class]]) {
            newData = [NSDecimalNumber numberWithDouble:[((NSDate *)data) timeIntervalSince1970]];
        } else {
            NSDecimal value;
            NSString *dataStr = [data isKindOfClass:[NSString class]] ? (NSString *)data : [data description];
            if ([[NSScanner scannerWithString:dataStr] scanDecimal:&value]) {
                newData = [NSDecimalNumber decimalNumberWithDecimal:value];
            } else {
                [ObjectUtils _logConvert:@"NSDecimalNumber" data:data];
                newData = nil;
            }
        }
    }
    else if ([type isSubclassOfClass:[NSNumber class]]) {
        // 数值
        if (!data) {
            newData = nil;
        } else if ([data isKindOfClass:[NSDate class]]) {
            newData = [NSNumber numberWithDouble:[((NSDate *)data) timeIntervalSince1970]];
        } else {
            double value;
            NSString *dataStr = [data isKindOfClass:[NSString class]] ? (NSString *)data : [data description];
            if ([[NSScanner scannerWithString:dataStr] scanDouble:&value]) {
                newData = [NSNumber numberWithDouble:value];
            } else {
                [ObjectUtils _logConvert:@"NSNumber" data:data];
                newData = nil;
            }
        }
    }
    else if ([type isSubclassOfClass:[NSArray class]]) {
        // array
        if (type == [NSMutableArray class] && ![[data class] isSubclassOfClass:[NSMutableArray class]]) {
            // 不可变array -> 可变array
            newData = [NSMutableArray arrayWithArray:(NSArray *)data];
        } else if ([data isKindOfClass:[NSEnumerator class]]) {
            // enumerator
            NSArray *allObjects = [(NSEnumerator *)data allObjects];
            if ([data isKindOfClass:[NSMutableArray class]])
                newData = [NSMutableArray arrayWithArray:allObjects];
            else
                newData = allObjects;
        } else if ([data conformsToProtocol:@protocol(NSFastEnumeration)]) {
            // fast enumeration
            NSFastEnumerationState es;
            es.state = 0;
            [data countByEnumeratingWithState:&es objects:nil count:0];
            NSMutableArray *arr = [NSMutableArray arrayWithCapacity:(int)es.extra];
            int idx = 0;
            for (id item in data)
                [arr setObject:item atIndexedSubscript:idx++];
            newData = type == [NSArray class] ? [NSArray arrayWithArray:arr] : arr;
        }
    }
    else if ([type isSubclassOfClass:[NSDictionary class]]) {
        // dictionary
        if (type == [NSMutableDictionary class] && ![[data class] isSubclassOfClass:[NSMutableDictionary class]]) {
            // 不可变dict -> 可变dict
            newData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)data];
        } else if ([data isKindOfClass:[NSString class]]){
            // TODO dict from json
        } else {
            // TODO dict from entity
        }
    }
    else if ([type isSubclassOfClass:[NSSet class]]) {
        // set
        if (type == [NSMutableSet class] && ![[data class] isSubclassOfClass:[NSSet class]]) {
            // mutable set -> immutable set
            newData = [NSMutableSet setWithSet:(NSSet *)data];
        } else {
            // TODO
        }
    }
    else {
        NSString *reason = [NSString stringWithFormat:@"不支持转换对象%@为%@", NSStringFromClass([data class]), NSStringFromClass(type)];
        NSException *ex = [ExceptionUtils makeExceptionWithName:@"未知的目标对象类型" reason:reason description:reason];
        @throw ex;
    }
    return newData;
}

+ (void)_logConvert:(NSString *)targetType data:(id)data
{
    JSLog(@"无法转换为%@ : <%@> %@", targetType, [data class], data);
}

// unused
+ (NSString *)_serializeObjectAsJSON:(id)object
{
    NSError *err;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:object options:0 error:&err];
    if (err) {
        NSString *description = [err.userInfo objectForKey:NSLocalizedDescriptionKey];
        NSString *reason = [err.userInfo objectForKey:NSLocalizedFailureReasonErrorKey];
        NSException *ex = [ExceptionUtils makeExceptionWithName:@"无法序列化对象为JSON" reason:reason description:description];
        @throw ex;
    } else {
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
}

+ (void)printClassHierarchy:(Class)cls
{
    NSMutableArray *clss = [NSMutableArray arrayWithCapacity:8];
    Class c = cls;
    while (c) {
        [clss addObject:NSStringFromClass(c)];
        if ([c superclass] == c)
            break;
        c = [c superclass];
    }
    
    NSMutableString *buff = [[NSMutableString alloc] initWithCapacity:clss.count << 6];
    for (int i = (int)clss.count - 1, j = i; i >= 0; --i) {
        [buff appendString:@"\n"];
        [buff appendFormat:@"%*s", (j - i + 1) << 1, " "];
        [buff appendFormat:@"%d : ", j - i + 1];
        [buff appendString:(NSString *)[clss objectAtIndex:i]];
    }
    NSLog(@"Class hierarchy:%@", [buff description]);
}

+ (NSString *)jsonFromObject:(id)object withIdentation:(BOOL)indented
{
    NSError *err = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:object options:indented ? NSJSONWritingPrettyPrinted : 0 error:&err];
    if (err) {
        NSLog(@"Error serializing object to json, err = %@, object = %@", err, object);
    }
    NSString *jsonStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return jsonStr;
}

+ (id)entityFromDictionary:(NSDictionary *)dict ofType:(Class)type
{
    id entity = [[type alloc] init];
    
    for (Class clas = type; clas; clas = class_getSuperclass(clas)) {
        uint propertyCount;
        objc_property_t *properties = class_copyPropertyList(clas, &propertyCount);
        for (uint i = 0; i < propertyCount; ++i) {
            objc_property_t property = properties[i];
            NSString *keyName = @(property_getName(property));
            id value = [dict objectForKey:keyName];
            if ([ObjectUtils isNilOrNull:value])
                continue;
            
            char *typeEncoding = property_copyAttributeValue(property, "T");
            if (typeEncoding != NULL) {
                switch (typeEncoding[0]) {
                    case '@': {
                        // 对象类型
                        // TODO 嵌套类型转换
                        Class propertyClass = nil;
                        size_t typeEncodingLength = strlen(typeEncoding);
                        if (typeEncodingLength >= 3) {
                            char *className = strndup(typeEncoding + 2, typeEncodingLength - 3);
                            propertyClass = NSClassFromString(@(className));
                            free (className);
                            
                            [entity setValue:[ObjectUtils convertData:value toType:propertyClass]
                                      forKey:keyName];
                        }
                        else {
                            NSLog(@"Unknown property of class %s", typeEncoding);
                        }
                    }
                        break;
                    case 'i': // int
                    case 's': // short
                    case 'l': // long
                    case 'q': // long long
                    case 'I': // unsigned int
                    case 'S': // unsigned short
                    case 'L': // unsigned long
                    case 'Q': // unsigned long long
                    case 'f': // float
                    case 'd': // double
                    case 'B': // BOOL
                        [entity setValue:[ObjectUtils convertData:value toType:[NSNumber class]] forKey:keyName];
                        break;
                    case 'c': // char
                    case 'C': // unsigned char
                        [entity setValue:value forKey:keyName];
                        break;
                    default:
                        [entity setValue:value forKey:keyName];
                        break;
                }
            }
            free(typeEncoding);
        }
        free(properties);
    }
    return entity;
}

+ (NSString *)createUUID {
    // Create universally unique identifier (object)
    CFUUIDRef uuidObject = CFUUIDCreate(kCFAllocatorDefault);
    NSString *uuidStr = (__bridge NSString *) CFUUIDCreateString(kCFAllocatorDefault, uuidObject);
    CFRelease(uuidObject);
    return uuidStr;
}

+ (id)jsonData2ArrayOrDictionary:(NSData *)jsonData{
    NSError *error = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];
    if (jsonObject != nil && error == nil){
        return jsonObject;
    }else{
        NSLog(@"解析错误, error = %@", error);
        return nil;
    }
}

@end

@implementation NSObject(ObjectUtils)

+ (BOOL)isNilOrNull:(id)object
{
    return object == nil || [object isNull];
}

+ (id)isNilOrNull:(id)object defaultObject:(id)defaultObject
{
    return [NSObject isNilOrNull:object] ? defaultObject : object;
}

- (BOOL)isNull
{
    return [self isEqual:[NSNull null]];
}

- (void)printDealloc
{
#ifdef NSOBJECT_PRINT_DEALLOC
    NSLog(@"* Dealloc : %@", self);
#endif
}

@end

@implementation NSDictionary(ObjectUtils)

- (id)valueForKeyNoNull:(NSString *)key
{
    id value = [self valueForKey:key];
    return [value isEqual:[NSNull null]] ? nil : value;
}

- (id)valueForKeyNull:(NSString *)key
{
    id value = [self valueForKey:key];
    return value ? value : [NSNull null];
}

@end