//
//  NumberUtils.m
//  JSDevKit
//
//  Created by jerei on 14-8-1.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "NumberUtils.h"

@implementation NumberUtils

+ (NSString *)chineseNameForZeroThroughTen:(NSInteger)intValue
{
    assert(intValue >= 0 && intValue <= 10);
    static const NSString *CHINESE_NAMES = @"零一二三四五六七八九十";
    return [CHINESE_NAMES substringWithRange:NSMakeRange(intValue, 1)];
}

@end
