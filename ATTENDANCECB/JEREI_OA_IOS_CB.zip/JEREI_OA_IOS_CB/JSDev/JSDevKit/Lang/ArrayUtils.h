//
//  ArrayUtils.h
//  JSDevKit
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ArrayUtils : NSObject

@end

@interface NSArray(NSArrayUtils)

/*
    @abstract 将元素的description组合为字符串
 */
- (NSString *)stringJoinedBy:(NSString *)separator;
/*!
 @abstract 根据keyPath访问元素属性，并组合为字符串
 */
- (NSString *)stringJoinedBy:(NSString *)separator ofKeyPath:(NSString *)keyPath;

/*!
 @abstract 按照属性名从集合中查找属性值匹配的项目的索引
 */
- (NSInteger)indexOfFirstMatchOfValue:(id)value byKey:(NSString *)keyProperty;

/*!
 @abstract 复制object指定次数，构造一个array
 */
+ (instancetype)arrayWithCopiesOfObjects:(id)object count:(uint)count;

@end