//
//  ThreadUtils.h
//  JSDevKit
//
//  Created by jerei on 14-8-12.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MBProgressHUD.h"

@interface ThreadUtils : NSObject

/*!
    @abstract 在后台线程中执行taskBlock，并在结束后返回主线程执行doneBlock
    @param taskBlock
    @param doneBlock 可选
 */
+ (void)runInGlobalQueue:(void(^)())taskBlock whenDone:(void(^)())doneBlock;

/*!
     @abstract 在后台线程中执行taskBlock，并在结束后返回主线程执行doneBlock
     @param taskBlock
     @param doneBlock 可选，如果block返回YES则表示hud已被doneBlock处理，不再自动关闭
     @param viewForHUD 要在其中显示progressHUD的view
     @parma hudInitializer hud创建后可以用这个方法来调整hud的参数
 */
+ (void)runInGlobalQueue:(void(^)(MBProgressHUD *hud))taskBlock
                whenDone:(BOOL(^)(MBProgressHUD *hud))doneBlock
              viewForHUD:(UIView *)viewForHUD
       initializerForHUD:(void (^)(MBProgressHUD *hud))hudInitializer;

@end

@interface NSThread(ThreadUtils)

@end