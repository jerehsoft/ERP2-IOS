//
//  Callback.h
//  JSDevKit
//
//  Created by jerei on 14-8-18.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#ifndef JSDevKit_Callback_h
#define JSDevKit_Callback_h

/*!
 @abstract 进度通知block
 */
typedef void (^JSProgressBlock)(float progress);

/*!
 @abstract 异常通知block
 */
typedef void (^JSErrorBlock)(NSError *error);

/*!
 @abstract 通用接收数据block
 */
typedef void (^JSCommonBlock)(id data);

#endif
