//
//  DateUtils.h
//  JSDevKit
//
//  Created by jerei on 14-7-30.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>

#define DATEUTILS_DATE_TIME_FORMAT_WITH_MILLIS @"yyyy-MM-dd HH:mm:ss.SSS"
#define DATEUTILS_DATE_TIME_DEFAULT_FORMAT @"yyyy-MM-dd HH:mm:ss.SSS"
#define DATEUTILS_DATE_DEFAULT_FORMAT @"yyyy-MM-dd"
#define DATEUTILS_TIME_DEFAULT_FORMAT @"HH:mm:ss.SSS"

@interface DateUtils : NSObject

+ (NSDate *)dateFromString:(NSString *)dateStr;

// 周日：1，周一：2，。。。同NSDateComponents.weekday
+ (NSString *)weekDayName:(NSInteger)weekDay;

+ (NSString *)weekDayNameByDate:(NSDate *)date;

/*!
 @abstract 日期与当前日期的天数差
 */
+ (NSString *)getDaysPastWithDate:(NSDate *)date;
@end


@interface NSDate(NSDateUtils)

/*!
 @abstract 解析日期，目前支持中国地区格式 yyyy-MM-dd HH:mm:ss.SSS，时间／秒数／毫秒数可选
 */
+ (NSDate *)dateFromString:(NSString *)dateStr;
/*!
 @abstract 公历转换为农历
 */
- (NSString *)lunarCalendarDate;

/*!
 @abstract 格式化日期
 */
- (NSString *)stringWithFormat:(NSString *)format;

/*!
 @abstract 按照默认格式格式化日期
 */
- (NSString *)stringWithDefaultFormat;

@end
