//
//  ErrorUtils.m
//  JSDevKit
//
//  Created by jerei on 14-8-13.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ErrorUtils.h"

@implementation ErrorUtils

+ (NSError *)makeErrorOfDomain:(NSString *)domain
                      withCode:(NSInteger)code
               withDescription:(NSString *)description
                    withReason:(NSString *)reason
{
    if (!description && reason)
        description = reason;
    else if (!reason && description)
        reason = description;
    else if (!reason && !description)
        reason = description = @"no error message";
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                              description, NSLocalizedDescriptionKey,
                              reason, NSLocalizedFailureReasonErrorKey,
                              nil];
    NSError *err = [[NSError alloc] initWithDomain:domain code:code userInfo:userInfo];
    return err;
}

@end
