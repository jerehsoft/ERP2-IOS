//
//  StringUtils.m
//  JSDevKit
//
//  Created by jerei on 14-7-25.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "StringUtils.h"

@implementation StringUtils

@end

@implementation NSString(NSStringUtils)

- (BOOL)hasPrefix:(NSString *)prefix ignoreCase:(BOOL)ignoreCase
{
    if (!ignoreCase)
        return [self hasPrefix:prefix];
    
    if (self.length < prefix.length || !prefix)
        return NO;
    else
        return ![self compare:prefix
                      options:NSCaseInsensitiveSearch
                        range:NSMakeRange(0, prefix.length)];
}


- (BOOL)hasSuffix:(NSString *)suffix ignoreCase:(BOOL)ignoreCase
{
    if (!ignoreCase)
        return [self hasSuffix:suffix];
    
    if (self.length < suffix.length || !suffix)
        return NO;
    else
        return ![self compare:suffix
                      options:NSCaseInsensitiveSearch
                        range:NSMakeRange(self.length - suffix.length, suffix.length)];
}

- (BOOL)matches:(NSString *)pattern options:(NSRegularExpressionOptions)options error:(NSError **)error
{
    NSError *reError;
    NSRegularExpression *nsre = [NSRegularExpression regularExpressionWithPattern:pattern
                                                                          options:options
                                                                            error:&reError];
    if (reError) {
        NSLog(@"error constructing RegularExpression with patterh '%@'", pattern);
        *error = reError;
        return NO;
    }
    
    NSRange range = NSMakeRange(0, self.length);
    NSTextCheckingResult *result = [nsre firstMatchInString:self options:0 range:range];
    return result != nil;
}
- (BOOL)matches:(NSString *)pattern options:(NSRegularExpressionOptions)options
{
    return [self matches:pattern options:options error:nil];
}

- (NSString *)trim
{
    // 去左右空白字符，对全角空格也有效
    return [self trimForCharSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (NSString *)trimForCharSet:(NSCharacterSet *)charSet
{
    NSString *str = [self stringByTrimmingCharactersInSet:charSet];
    return str;
}

+ (instancetype)stringWrapped:(id)object
{
    return ([object isEqual:[NSNull null]] || object == nil) ? @"" : [object description];
}

@end