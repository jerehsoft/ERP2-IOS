//
//  NumberUtils.h
//  JSDevKit
//
//  Created by jerei on 14-8-1.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NumberUtils : NSObject

+ (NSString *)chineseNameForZeroThroughTen:(NSInteger)intValue;

@end
