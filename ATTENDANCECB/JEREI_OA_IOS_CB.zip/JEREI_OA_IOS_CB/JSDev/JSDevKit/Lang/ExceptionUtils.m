//
//  ExceptionUtils.m
//  JSDevKit
//
//  Created by jerei on 14-8-11.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import "ExceptionUtils.h"

@implementation ExceptionUtils

+ (NSException *)makeExceptionWithName:(NSString *)name reason:(NSString *)reason description:(NSString *)description
{
    NSDictionary *userInfo = @{ NSLocalizedDescriptionKey : description, NSLocalizedFailureReasonErrorKey : reason };
    NSException *exception = [NSException exceptionWithName:name
                                                     reason:reason
                                                   userInfo:userInfo];
    return exception;
}


@end
