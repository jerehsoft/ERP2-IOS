//
//  ObjectUtils.h
//  JSDevKit
//
//  Created by jerei on 14-7-31.
//  Copyright (c) 2014年 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSDev.h"

@interface ObjectUtils : NSObject

/*!
 @abstract 转换数据
 */
+ (id)convertData:(id)data toType:(Class)type;

/*!
 @abstract 打印类继承关系
 */
+ (void)printClassHierarchy:(Class)cls;

/*!
 @abstract 转换为json字符串
 */
+ (NSString *)jsonFromObject:(id)object withIdentation:(BOOL)indented;

/*!
 @abstract 从dictionary创建指定类型的实例
 */
+ (id)entityFromDictionary:(NSDictionary *)dict ofType:(Class)type;

+ (NSString *)createUUID;

+ (id)jsonData2ArrayOrDictionary:(NSData *)jsonData;

@end


@interface NSObject(ObjectUtils)

/*!
    @method isNilOrNull
    @param object 要检测的对象
    @result 如果对象是nil或者nsnull，则返回YES
 */
+ (BOOL)isNilOrNull:(id)object;

/*!
    @method isNilOrNull
    @param object 要检测的对象
    @param defaultObject 如果对象是nil或者nsnull，作为替代的默认值
    @result 如果对象是nil或者nsnull，则返回defaultObject
 */
+ (id)isNilOrNull:(id)object defaultObject:(id)defaultObject;
/*!
    @method isNull
    @result 如果对象是nsnull则返回YES
 */
- (BOOL)isNull;

/*!
    @method printDealloc
    @abstract 打印对象销毁消息
 */
- (void)printDealloc;

@end

@interface NSDictionary(ObjectUtils)

/*!
    @method valueForKeyNoNull:
    @param key 键
    @result 如果value是nsnull则返回nil，其他情况下返回value本身
 */
- (id)valueForKeyNoNull:(NSString *)key;

- (id)valueForKeyNull:(NSString *)key;

@end