//
//  JSValidator.h
//  JSDevKit
//
//  Created by 丁未汀 on 9/3/14.
//  Copyright (c) 2014 jerei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSDev.h"

@interface JSValidator : NSObject

/*!
 @abstract 必填验证
 */
+ (BOOL)validateRequired:(id)value;


/*!
 @abstract 验证最大长度（字符串将被trim）
 */
+ (NSString *)validateMaxLength:(id)value maxLength:(uint)maxLength;
/*!
 @abstract 验证最小长度（字符串将被trim）
 */
+ (NSString *)validateMinLength:(id)value minLength:(uint)minLength;
/*!
 @abstract 验证长度范围（字符串将被trim）
 */
+ (NSString *)validateLengthInRange:(id)value minLength:(uint)minLength maxLength:(uint)maxLength;


/*!
 @abstract 正则验证，不区分大小写，不去左右空格
 */
+ (NSString *)validateRegExp:(NSString *)value regExp:(NSString *)regExp invalidMessage:(NSString *)invalidMessage;


/*!
 @abstract取值范围验证，验证时根据值的类型自动处理，如果值为nil或null，则返回验证失败消息。必须保证值和范围值的类型一致
 */
+ (NSString *)validateValueInRange:(id)value minValue:(id)minValue maxValue:(id)maxValue;


/*!
 @abstract 指定取值集合验证
 */
+ (BOOL)validateValueInSet:(id)value valueSet:(NSSet *)valueSet;


/*!
 @abstract 使用验证block
 */
+ (NSString *)validateValue:(id)value withBlock:(BOOL(^)(id))validateBlock invalidMessage:(NSString *)invalidMessage;


/*!
 @abstract 使用预定义验证器
 */
+ (NSString *)validateValue:(id)value withValidator:(Class)validatorClass;


/*!
 @abstract 验证数据
 */
- (NSString *)validateValue:(id)value;

@end




/*!
 @abstract 身份证
 */
@interface JSIDValidator : JSValidator
@end

/*!
 @abstract 座机
 */
@interface JSPhoneValidator : JSValidator
@end

/*!
 @abstract 手机
 */
@interface JSMobileVaidator : JSValidator
@end

/*!
 @abstract 座机／手机
 */
@interface JSPhoneMobileValidator : JSPhoneValidator
@end

/*!
 @abstract 邮政编码
 */
@interface JSPostCodeValidator : JSValidator
@end

/*!
 @abstract http(s)地址
 */
@interface JSHttpUrlValidator : JSValidator
@end

/*!
 @abstract EMail
 */
@interface JSEMailValidator : JSValidator
@end

/*!
 @abstract 日期
 */
@interface JSDateTimeValidator : JSValidator
@end

