//
//  CallOutAnnotationView.h
//
//  Created by lengzj on 16-02-14.
//  Copyright (c) 2016年 lengzj. All rights reserved.
//

#import <MapKit/MapKit.h>

#define  Arror_height 20

@protocol CallOutAnnotationViewDelegate;
@interface CallOutAnnotationView : MKAnnotationView

@property (nonatomic,strong)UIView *contentView;


- (id)initWithAnnotation:(id<MKAnnotation>)annotation
         reuseIdentifier:(NSString *)reuseIdentifier
                delegate:(id<CallOutAnnotationViewDelegate>)delegate;
@end

@protocol CallOutAnnotationViewDelegate <NSObject>

- (void)didSelectAnnotationView:(CallOutAnnotationView *)view;

@end


